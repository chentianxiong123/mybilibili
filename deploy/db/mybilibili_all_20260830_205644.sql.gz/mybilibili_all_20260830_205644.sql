--
-- PostgreSQL database cluster dump
--

\restrict M97FFLMZp4tqtpZJzb1IWcdwikkVfMaULr2db7EDcrSB5GjLzvVDTBStzgPeJ4v

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:PGCZ2D/uE2cW+eErJ8xX0w==$pNYi3Fwwhzad+OHD2juk0y+TM14dgb0kS2mc9yndOtM=:VIcmTc+fm4WN0icBSNkUAjVSvCL98zQ1VEPDoKIwZwQ=';

--
-- User Configurations
--








\unrestrict M97FFLMZp4tqtpZJzb1IWcdwikkVfMaULr2db7EDcrSB5GjLzvVDTBStzgPeJ4v

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict GWjzgRQodse3OD02ush4ZnhSOiyTF9rzwCW2Gsiwn1eS6fq4NMRvJSl0k55Nava

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict GWjzgRQodse3OD02ush4ZnhSOiyTF9rzwCW2Gsiwn1eS6fq4NMRvJSl0k55Nava

--
-- Database "mybilibili" dump
--

--
-- PostgreSQL database dump
--

\restrict bEtX5NbUpRpszTBtGS4CCG9rY9ylYXd8U5hDu2ocpuTqfCOQl8bJB0q8G9gsD1w

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mybilibili; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mybilibili WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE mybilibili OWNER TO postgres;

\unrestrict bEtX5NbUpRpszTBtGS4CCG9rY9ylYXd8U5hDu2ocpuTqfCOQl8bJB0q8G9gsD1w
\connect mybilibili
\restrict bEtX5NbUpRpszTBtGS4CCG9rY9ylYXd8U5hDu2ocpuTqfCOQl8bJB0q8G9gsD1w

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: zhparser; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS zhparser WITH SCHEMA public;


--
-- Name: EXTENSION zhparser; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION zhparser IS 'a parser for full-text search of Chinese';


--
-- Name: update_manuscript_search_vector(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_manuscript_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := to_tsvector('zh_cn', COALESCE(NEW.title, '') || ' ' || COALESCE(NEW.description, ''));
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_manuscript_search_vector() OWNER TO postgres;

--
-- Name: zh_cn; Type: TEXT SEARCH CONFIGURATION; Schema: public; Owner: postgres
--

CREATE TEXT SEARCH CONFIGURATION public.zh_cn (
    PARSER = public.zhparser );

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR a WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR b WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR e WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR i WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR l WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR n WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR t WITH simple;

ALTER TEXT SEARCH CONFIGURATION public.zh_cn
    ADD MAPPING FOR v WITH simple;


ALTER TEXT SEARCH CONFIGURATION public.zh_cn OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_user_roles (
    admin_user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.admin_user_roles OWNER TO postgres;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(100) NOT NULL,
    admin_level integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_users OWNER TO postgres;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.admin_users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.admin_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ai_api_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_api_configs (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    base_url character varying(255) NOT NULL,
    api_key character varying(255) DEFAULT ''::character varying NOT NULL,
    model character varying(100) DEFAULT 'deepseek-chat'::character varying NOT NULL,
    max_tokens integer DEFAULT 2000 NOT NULL,
    temperature double precision DEFAULT 0.7 NOT NULL,
    enabled integer DEFAULT 1 NOT NULL,
    extra_config text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    type character varying(40) DEFAULT 'LLM'::character varying NOT NULL
);


ALTER TABLE public.ai_api_configs OWNER TO postgres;

--
-- Name: ai_api_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_api_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_api_configs_id_seq OWNER TO postgres;

--
-- Name: ai_api_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_api_configs_id_seq OWNED BY public.ai_api_configs.id;


--
-- Name: ai_bindings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_bindings (
    id bigint NOT NULL,
    feature character varying(30) NOT NULL,
    api_config_id bigint NOT NULL
);


ALTER TABLE public.ai_bindings OWNER TO postgres;

--
-- Name: ai_bindings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_bindings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_bindings_id_seq OWNER TO postgres;

--
-- Name: ai_bindings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_bindings_id_seq OWNED BY public.ai_bindings.id;


--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_chat_messages (
    id bigint NOT NULL,
    conversation_id bigint NOT NULL,
    role character varying(20) NOT NULL,
    content text NOT NULL,
    token_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ai_chat_messages OWNER TO postgres;

--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.ai_chat_messages ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ai_chat_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ai_conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_conversations (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) DEFAULT 'AI客服对话'::character varying NOT NULL,
    status smallint DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.ai_conversations OWNER TO postgres;

--
-- Name: ai_conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.ai_conversations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.ai_conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ai_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    skill_id bigint,
    type character varying(40) DEFAULT 'CUSTOMER_SERVICE'::character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_sessions OWNER TO postgres;

--
-- Name: ai_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_sessions_id_seq OWNER TO postgres;

--
-- Name: ai_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_sessions_id_seq OWNED BY public.ai_sessions.id;


--
-- Name: ai_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_skills (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(500) DEFAULT ''::character varying NOT NULL,
    system_prompt text DEFAULT ''::text NOT NULL,
    few_shot_examples text DEFAULT ''::text NOT NULL,
    type character varying(40) DEFAULT ''::character varying NOT NULL,
    enabled integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_skills OWNER TO postgres;

--
-- Name: ai_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_skills_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_skills_id_seq OWNER TO postgres;

--
-- Name: ai_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_skills_id_seq OWNED BY public.ai_skills.id;


--
-- Name: ai_usage_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_usage_logs (
    id bigint NOT NULL,
    feature character varying(30) NOT NULL,
    user_id bigint,
    token_count integer DEFAULT 0 NOT NULL,
    model character varying(100) DEFAULT ''::character varying NOT NULL,
    duration_ms integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_usage_logs OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_usage_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_usage_logs_id_seq OWNER TO postgres;

--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_usage_logs_id_seq OWNED BY public.ai_usage_logs.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    operator_id integer,
    operator_name character varying(64) DEFAULT NULL::character varying,
    operator_role character varying(64) DEFAULT NULL::character varying,
    module character varying(64) NOT NULL,
    action character varying(64) NOT NULL,
    target_type character varying(64) DEFAULT NULL::character varying,
    target_id character varying(128) DEFAULT NULL::character varying,
    request_method character varying(16) DEFAULT NULL::character varying,
    request_uri character varying(255) DEFAULT NULL::character varying,
    client_ip character varying(64) DEFAULT NULL::character varying,
    user_agent character varying(512) DEFAULT NULL::character varying,
    result smallint NOT NULL,
    message character varying(255) DEFAULT NULL::character varying,
    detail text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.audit_logs ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: banner_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.banner_images (
    id integer NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    image_url character varying(500) DEFAULT NULL::character varying,
    link_url character varying(500) DEFAULT NULL::character varying,
    sort_order integer DEFAULT 0,
    status integer DEFAULT 1,
    type integer NOT NULL,
    category_id integer,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.banner_images OWNER TO postgres;

--
-- Name: banner_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.banner_images ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.banner_images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.categories ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    manuscript_id integer,
    user_id integer NOT NULL,
    content text NOT NULL,
    like_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status integer DEFAULT 0
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.comments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: content_reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.content_reviews (
    id bigint NOT NULL,
    type character varying(20) NOT NULL,
    user_id bigint,
    content text DEFAULT ''::text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.content_reviews OWNER TO postgres;

--
-- Name: content_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.content_reviews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.content_reviews_id_seq OWNER TO postgres;

--
-- Name: content_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.content_reviews_id_seq OWNED BY public.content_reviews.id;


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target_user_id integer NOT NULL,
    last_message_id integer,
    last_message_content character varying(500) DEFAULT NULL::character varying,
    last_message_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    unread_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.conversations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.conversations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: creator_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.creator_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    default_category_id integer,
    auto_publish smallint DEFAULT 0,
    comment_notify smallint DEFAULT 1,
    like_notify smallint DEFAULT 1,
    follow_notify smallint DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.creator_settings OWNER TO postgres;

--
-- Name: creator_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.creator_settings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.creator_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: danmaku; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.danmaku (
    id bigint NOT NULL,
    video_id bigint NOT NULL,
    manuscript_id bigint NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    "time" double precision DEFAULT 0 NOT NULL,
    color character varying(10) DEFAULT '#ffffff'::character varying NOT NULL,
    mode integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.danmaku OWNER TO postgres;

--
-- Name: danmaku_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.danmaku_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.danmaku_id_seq OWNER TO postgres;

--
-- Name: danmaku_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.danmaku_id_seq OWNED BY public.danmaku.id;


--
-- Name: dynamic_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_comments (
    id integer NOT NULL,
    dynamic_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    parent_id integer,
    reply_user_id integer,
    like_count integer DEFAULT 0,
    status integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dynamic_comments OWNER TO postgres;

--
-- Name: dynamic_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.dynamic_comments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dynamic_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dynamic_likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_likes (
    id bigint NOT NULL,
    dynamic_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dynamic_likes OWNER TO postgres;

--
-- Name: dynamic_likes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dynamic_likes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dynamic_likes_id_seq OWNER TO postgres;

--
-- Name: dynamic_likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dynamic_likes_id_seq OWNED BY public.dynamic_likes.id;


--
-- Name: favorite_folder_videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_folder_videos (
    id bigint NOT NULL,
    folder_id bigint NOT NULL,
    manuscript_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.favorite_folder_videos OWNER TO postgres;

--
-- Name: favorite_folder_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.favorite_folder_videos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.favorite_folder_videos_id_seq OWNER TO postgres;

--
-- Name: favorite_folder_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.favorite_folder_videos_id_seq OWNED BY public.favorite_folder_videos.id;


--
-- Name: favorite_folders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_folders (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(50) NOT NULL,
    collect_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.favorite_folders OWNER TO postgres;

--
-- Name: favorite_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.favorite_folders ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.favorite_folders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: favorite_manuscripts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.favorite_manuscripts (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    manuscript_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.favorite_manuscripts OWNER TO postgres;

--
-- Name: favorite_manuscripts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.favorite_manuscripts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.favorite_manuscripts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: follows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.follows (
    id bigint NOT NULL,
    follower_id bigint NOT NULL,
    following_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.follows OWNER TO postgres;

--
-- Name: follows_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.follows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.follows_id_seq OWNER TO postgres;

--
-- Name: follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.follows_id_seq OWNED BY public.follows.id;


--
-- Name: jsonb_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jsonb_documents (
    id text NOT NULL,
    collection_name text NOT NULL,
    doc_json jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.jsonb_documents OWNER TO postgres;

--
-- Name: live_linkmic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_linkmic (
    id bigint NOT NULL,
    room_id bigint NOT NULL,
    streamer_id bigint NOT NULL,
    viewer_id bigint NOT NULL,
    viewer_name character varying(50) NOT NULL,
    status smallint DEFAULT 0,
    audio_enabled smallint DEFAULT 0,
    video_enabled smallint DEFAULT 0,
    max_linkmics integer DEFAULT 3,
    apply_time timestamp without time zone,
    connect_time timestamp without time zone,
    end_time timestamp without time zone
);


ALTER TABLE public.live_linkmic OWNER TO postgres;

--
-- Name: live_linkmic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.live_linkmic ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.live_linkmic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: live_rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_rooms (
    id integer NOT NULL,
    user_id integer NOT NULL,
    room_name character varying(100) DEFAULT ''::character varying NOT NULL,
    stream_key character varying(64) NOT NULL,
    status character varying(10) DEFAULT 'offline'::character varying NOT NULL,
    cover_url character varying(255) DEFAULT NULL::character varying,
    viewer_count integer DEFAULT 0 NOT NULL,
    category character varying(50) DEFAULT NULL::character varying,
    scheduled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.live_rooms OWNER TO postgres;

--
-- Name: live_rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.live_rooms ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.live_rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: live_seats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_seats (
    id bigint NOT NULL,
    room_id bigint NOT NULL,
    seat_index integer NOT NULL,
    user_id bigint,
    status integer DEFAULT 0 NOT NULL,
    muted boolean DEFAULT false NOT NULL,
    joined_at timestamp with time zone
);


ALTER TABLE public.live_seats OWNER TO postgres;

--
-- Name: live_seats_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.live_seats_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.live_seats_id_seq OWNER TO postgres;

--
-- Name: live_seats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.live_seats_id_seq OWNED BY public.live_seats.id;


--
-- Name: login_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_logs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    ip character varying(50) DEFAULT ''::character varying NOT NULL,
    user_agent character varying(500) DEFAULT ''::character varying NOT NULL,
    status integer DEFAULT 0 NOT NULL,
    login_time timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.login_logs OWNER TO postgres;

--
-- Name: login_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.login_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.login_logs_id_seq OWNER TO postgres;

--
-- Name: login_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.login_logs_id_seq OWNED BY public.login_logs.id;


--
-- Name: manuscript_collection_relations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscript_collection_relations (
    id integer NOT NULL,
    manuscript_id integer NOT NULL,
    collection_id integer NOT NULL,
    collection_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.manuscript_collection_relations OWNER TO postgres;

--
-- Name: manuscript_collection_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.manuscript_collection_relations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.manuscript_collection_relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: manuscript_collections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscript_collections (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    description text,
    cover_url character varying(500) DEFAULT NULL::character varying,
    user_id integer NOT NULL,
    manuscript_count integer DEFAULT 0,
    view_count integer DEFAULT 0,
    status smallint DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.manuscript_collections OWNER TO postgres;

--
-- Name: manuscript_collections_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.manuscript_collections ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.manuscript_collections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: manuscript_daily_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscript_daily_metrics (
    metric_date date NOT NULL,
    manuscript_id bigint NOT NULL,
    user_id bigint NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    coin_count integer DEFAULT 0 NOT NULL,
    collect_count integer DEFAULT 0 NOT NULL,
    share_count integer DEFAULT 0 NOT NULL,
    comment_count integer DEFAULT 0 NOT NULL,
    danmaku_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.manuscript_daily_metrics OWNER TO postgres;

--
-- Name: manuscript_edit_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscript_edit_versions (
    id bigint NOT NULL,
    manuscript_id bigint NOT NULL,
    user_id bigint NOT NULL,
    before_snapshot text DEFAULT ''::text NOT NULL,
    after_snapshot text DEFAULT ''::text NOT NULL,
    changed_fields text DEFAULT ''::text NOT NULL,
    status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    reviewer_id bigint,
    review_reason character varying(500) DEFAULT ''::character varying NOT NULL,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.manuscript_edit_versions OWNER TO postgres;

--
-- Name: manuscript_edit_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.manuscript_edit_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.manuscript_edit_versions_id_seq OWNER TO postgres;

--
-- Name: manuscript_edit_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.manuscript_edit_versions_id_seq OWNED BY public.manuscript_edit_versions.id;


--
-- Name: manuscript_status_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscript_status_events (
    id bigint NOT NULL,
    manuscript_id bigint NOT NULL,
    user_id bigint,
    from_status integer,
    to_status integer NOT NULL,
    action character varying(64) NOT NULL,
    operator_type character varying(32) DEFAULT 'SYSTEM'::character varying NOT NULL,
    operator_id bigint,
    reason character varying(500) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.manuscript_status_events OWNER TO postgres;

--
-- Name: manuscript_status_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.manuscript_status_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.manuscript_status_events_id_seq OWNER TO postgres;

--
-- Name: manuscript_status_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.manuscript_status_events_id_seq OWNED BY public.manuscript_status_events.id;


--
-- Name: manuscripts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manuscripts (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    description text,
    cover_url character varying(500) DEFAULT NULL::character varying,
    user_id integer NOT NULL,
    category_id integer NOT NULL,
    view_count integer DEFAULT 0,
    like_count integer DEFAULT 0,
    coin_count integer DEFAULT 0,
    collect_count integer DEFAULT 0,
    share_count integer DEFAULT 0,
    comment_count integer DEFAULT 0,
    danmaku_count integer DEFAULT 0,
    status integer DEFAULT 0,
    review_status integer DEFAULT 0,
    review_reason character varying(500) DEFAULT NULL::character varying,
    review_time timestamp without time zone,
    reviewer_id integer,
    upload_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    duration character varying(20) DEFAULT NULL::character varying,
    duration_seconds integer DEFAULT 0,
    search_vector tsvector,
    source_type character varying(20) DEFAULT 'local'::character varying NOT NULL,
    bvid character varying(20) DEFAULT ''::character varying NOT NULL,
    origin_url character varying(500) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.manuscripts OWNER TO postgres;

--
-- Name: manuscripts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.manuscripts ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.manuscripts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: meeting_participant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meeting_participant (
    id bigint NOT NULL,
    room_id bigint NOT NULL,
    user_id bigint NOT NULL,
    user_name character varying(50) NOT NULL,
    user_avatar character varying(255) DEFAULT NULL::character varying,
    role smallint DEFAULT 0,
    audio_enabled smallint DEFAULT 0,
    video_enabled smallint DEFAULT 0,
    screen_share_enabled smallint DEFAULT 0,
    join_time timestamp without time zone,
    leave_time timestamp without time zone
);


ALTER TABLE public.meeting_participant OWNER TO postgres;

--
-- Name: meeting_participant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.meeting_participant ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.meeting_participant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: meeting_room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meeting_room (
    id bigint NOT NULL,
    room_name character varying(100) NOT NULL,
    room_code character varying(10) NOT NULL,
    creator_id bigint NOT NULL,
    creator_name character varying(50) NOT NULL,
    max_participants integer DEFAULT 5,
    status smallint DEFAULT 0,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    scheduled_start timestamp without time zone,
    scheduled_end timestamp without time zone,
    scheduled_reason character varying(500) DEFAULT NULL::character varying,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meeting_room OWNER TO postgres;

--
-- Name: meeting_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.meeting_room ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.meeting_room_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: message_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    private_message_notification smallint DEFAULT 1,
    reply_notification smallint DEFAULT 1,
    at_notification smallint DEFAULT 1,
    like_notification smallint DEFAULT 1,
    system_notification smallint DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.message_settings OWNER TO postgres;

--
-- Name: message_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.message_settings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.message_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    sender_id integer NOT NULL,
    receiver_id integer NOT NULL,
    content text NOT NULL,
    is_read smallint DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    message_type smallint DEFAULT 1,
    target_id integer,
    media_url character varying(500) DEFAULT NULL::character varying,
    conversation_id integer,
    comment_id integer
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.messages ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    type character varying(30) NOT NULL,
    title character varying(200) DEFAULT ''::character varying NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    from_user_id bigint,
    target_id bigint,
    is_read integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: operation_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operation_tasks (
    id bigint NOT NULL,
    task_key character varying(128) NOT NULL,
    task_type character varying(64) NOT NULL,
    task_name character varying(128) NOT NULL,
    target_type character varying(64) DEFAULT NULL::character varying,
    target_id character varying(128) DEFAULT NULL::character varying,
    status character varying(32) NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    stage character varying(128) DEFAULT NULL::character varying,
    message character varying(255) DEFAULT NULL::character varying,
    error_message text,
    operator_id integer,
    operator_name character varying(64) DEFAULT NULL::character varying,
    started_at timestamp without time zone,
    finished_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.operation_tasks OWNER TO postgres;

--
-- Name: operation_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.operation_tasks ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.operation_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    code character varying(50) NOT NULL,
    url character varying(255) DEFAULT NULL::character varying,
    method character varying(20) DEFAULT NULL::character varying,
    parent_id integer,
    description character varying(255) DEFAULT NULL::character varying,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: prohibited_word; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prohibited_word (
    id integer NOT NULL,
    word character varying(100) NOT NULL,
    match_type character varying(20) DEFAULT 'CONTAINS'::character varying,
    category character varying(50) DEFAULT NULL::character varying,
    is_enabled smallint DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prohibited_word OWNER TO postgres;

--
-- Name: prohibited_word_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.prohibited_word ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.prohibited_word_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: prohibited_words; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prohibited_words (
    id integer NOT NULL,
    word character varying(255) NOT NULL,
    match_type character varying(20) DEFAULT 'CONTAINS'::character varying,
    category character varying(50) DEFAULT NULL::character varying,
    is_enabled integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.prohibited_words OWNER TO postgres;

--
-- Name: prohibited_words_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.prohibited_words ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.prohibited_words_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: recommend_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recommend_configs (
    id bigint NOT NULL,
    config_key character varying(50) NOT NULL,
    config_json text DEFAULT '{}'::text NOT NULL,
    updated_by character varying(100) DEFAULT 'admin'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.recommend_configs OWNER TO postgres;

--
-- Name: recommend_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recommend_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recommend_configs_id_seq OWNER TO postgres;

--
-- Name: recommend_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recommend_configs_id_seq OWNED BY public.recommend_configs.id;


--
-- Name: replies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.replies (
    id integer NOT NULL,
    comment_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    like_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reply_to_user_id integer,
    status character varying(20) DEFAULT 'NORMAL'::character varying
);


ALTER TABLE public.replies OWNER TO postgres;

--
-- Name: replies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.replies ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.replies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    reporter_id integer NOT NULL,
    target_type character varying(30) NOT NULL,
    target_id integer NOT NULL,
    manuscript_id integer,
    reason character varying(50) NOT NULL,
    description character varying(500) DEFAULT NULL::character varying,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    admin_remark character varying(500) DEFAULT NULL::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone,
    ai_review_status character varying(20) DEFAULT 'PENDING'::character varying,
    ai_verdict character varying(500) DEFAULT NULL::character varying,
    ai_risk_level character varying(10) DEFAULT NULL::character varying,
    ai_reviewed_at timestamp without time zone
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reports ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255) DEFAULT NULL::character varying,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    update_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.roles ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: scheduled_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scheduled_tasks (
    id bigint NOT NULL,
    task_key character varying(100) NOT NULL,
    task_name character varying(200) DEFAULT ''::character varying NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    cron_expr character varying(100) DEFAULT ''::character varying NOT NULL,
    task_type character varying(50) DEFAULT ''::character varying NOT NULL,
    task_config text DEFAULT ''::text NOT NULL,
    enabled integer DEFAULT 1 NOT NULL,
    last_run_at timestamp with time zone,
    last_run_result character varying(50) DEFAULT ''::character varying NOT NULL,
    last_run_message text DEFAULT ''::text NOT NULL,
    next_run_at timestamp with time zone,
    run_count integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 0 NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    timeout_seconds integer DEFAULT 300 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.scheduled_tasks OWNER TO postgres;

--
-- Name: scheduled_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scheduled_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scheduled_tasks_id_seq OWNER TO postgres;

--
-- Name: scheduled_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scheduled_tasks_id_seq OWNED BY public.scheduled_tasks.id;


--
-- Name: shares; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shares (
    id integer NOT NULL,
    user_id integer,
    manuscript_id integer NOT NULL,
    channel character varying(50) DEFAULT 'unknown'::character varying,
    ip_address character varying(50) DEFAULT NULL::character varying,
    create_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.shares OWNER TO postgres;

--
-- Name: shares_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shares ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shares_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id bigint NOT NULL,
    ticket_no character varying(40) NOT NULL,
    user_id bigint,
    session_id bigint,
    source character varying(40) DEFAULT 'USER_FEEDBACK'::character varying NOT NULL,
    category character varying(40) DEFAULT 'GENERAL'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'NORMAL'::character varying NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    title character varying(200) NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    entry_reply text DEFAULT ''::text NOT NULL,
    admin_reply text DEFAULT ''::text NOT NULL,
    assignee_admin_id bigint,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: system_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_configs (
    config_key character varying(100) NOT NULL,
    config_value text DEFAULT ''::text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_by character varying(100) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.system_configs OWNER TO postgres;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(30) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: upload_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upload_sessions (
    id character varying(32) NOT NULL,
    user_id bigint NOT NULL,
    title character varying(100) DEFAULT ''::character varying NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    category_id bigint,
    tags text DEFAULT ''::text NOT NULL,
    videos jsonb DEFAULT '[]'::jsonb NOT NULL,
    uploaded_chunks integer DEFAULT 0 NOT NULL,
    total_chunks integer DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.upload_sessions OWNER TO postgres;

--
-- Name: user_dynamics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_dynamics (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    dynamic_type smallint DEFAULT 0,
    image_url character varying(2000) DEFAULT NULL::character varying,
    ref_manuscript_id integer,
    like_count integer DEFAULT 0,
    comment_count integer DEFAULT 0,
    share_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status integer DEFAULT 0
);


ALTER TABLE public.user_dynamics OWNER TO postgres;

--
-- Name: user_dynamics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_dynamics ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.user_dynamics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_interactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_interactions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    target_type character varying(20) NOT NULL,
    target_id integer NOT NULL,
    interaction_type character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_interactions OWNER TO postgres;

--
-- Name: user_interactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_interactions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.user_interactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_privacy_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_privacy_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    public_collection smallint DEFAULT 1,
    public_birthday_tags smallint DEFAULT 0,
    public_coin_videos smallint DEFAULT 0,
    public_like_videos smallint DEFAULT 0,
    public_following_list smallint DEFAULT 0,
    public_followers_list smallint DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_privacy_settings OWNER TO postgres;

--
-- Name: user_privacy_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_privacy_settings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.user_privacy_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_tags (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tag_name character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_tags OWNER TO postgres;

--
-- Name: user_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.user_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    nickname character varying(50) NOT NULL,
    avatar character varying(255) DEFAULT NULL::character varying,
    email character varying(100) DEFAULT NULL::character varying,
    phone character varying(20) DEFAULT NULL::character varying,
    gender smallint DEFAULT 0,
    signature character varying(255) DEFAULT ''::character varying,
    birthdate date,
    level integer DEFAULT 1,
    following_count integer DEFAULT 0,
    follower_count integer DEFAULT 0,
    manuscript_count integer DEFAULT 0,
    liked_count integer DEFAULT 0,
    coin_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status integer DEFAULT 0,
    pinned_video_id integer,
    experience integer DEFAULT 0,
    bio text,
    announcement text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: verification_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_codes (
    id bigint NOT NULL,
    identifier character varying(255) NOT NULL,
    code_type character varying(20) NOT NULL,
    code_value character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.verification_codes OWNER TO postgres;

--
-- Name: verification_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.verification_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.verification_codes_id_seq OWNER TO postgres;

--
-- Name: verification_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.verification_codes_id_seq OWNED BY public.verification_codes.id;


--
-- Name: video_process_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.video_process_events (
    id bigint NOT NULL,
    video_id bigint NOT NULL,
    manuscript_id bigint,
    from_status integer,
    to_status integer NOT NULL,
    stage character varying(64) DEFAULT ''::character varying NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    error_message character varying(500) DEFAULT ''::character varying NOT NULL,
    operator_type character varying(32) DEFAULT 'SYSTEM'::character varying NOT NULL,
    operator_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.video_process_events OWNER TO postgres;

--
-- Name: video_process_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.video_process_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.video_process_events_id_seq OWNER TO postgres;

--
-- Name: video_process_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.video_process_events_id_seq OWNED BY public.video_process_events.id;


--
-- Name: video_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.video_tags (
    id integer NOT NULL,
    video_id integer NOT NULL,
    tag_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.video_tags OWNER TO postgres;

--
-- Name: video_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.video_tags ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.video_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.videos (
    id integer NOT NULL,
    manuscript_id integer,
    video_order integer DEFAULT 0,
    title character varying(100) NOT NULL,
    play_url_hd character varying(255) DEFAULT NULL::character varying,
    play_url_sd character varying(255) DEFAULT NULL::character varying,
    play_url_ld character varying(255) DEFAULT NULL::character varying,
    upload_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    process_progress integer DEFAULT 0,
    process_stage character varying(50) DEFAULT NULL::character varying,
    has_subtitle smallint DEFAULT 0,
    has_summary smallint DEFAULT 0,
    process_status integer DEFAULT 0,
    process_error character varying(500) DEFAULT NULL::character varying,
    source_video_url character varying(500) DEFAULT NULL::character varying,
    duration_seconds integer DEFAULT 0,
    is_vertical smallint DEFAULT 0 NOT NULL,
    cid bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.videos OWNER TO postgres;

--
-- Name: videos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.videos ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.videos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: watch_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.watch_history (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    manuscript_id bigint NOT NULL,
    progress_seconds integer DEFAULT 0 NOT NULL,
    watched_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.watch_history OWNER TO postgres;

--
-- Name: watch_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.watch_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.watch_history_id_seq OWNER TO postgres;

--
-- Name: watch_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.watch_history_id_seq OWNED BY public.watch_history.id;


--
-- Name: ai_api_configs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_api_configs ALTER COLUMN id SET DEFAULT nextval('public.ai_api_configs_id_seq'::regclass);


--
-- Name: ai_bindings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_bindings ALTER COLUMN id SET DEFAULT nextval('public.ai_bindings_id_seq'::regclass);


--
-- Name: ai_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions ALTER COLUMN id SET DEFAULT nextval('public.ai_sessions_id_seq'::regclass);


--
-- Name: ai_skills id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_skills ALTER COLUMN id SET DEFAULT nextval('public.ai_skills_id_seq'::regclass);


--
-- Name: ai_usage_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.ai_usage_logs_id_seq'::regclass);


--
-- Name: content_reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_reviews ALTER COLUMN id SET DEFAULT nextval('public.content_reviews_id_seq'::regclass);


--
-- Name: danmaku id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.danmaku ALTER COLUMN id SET DEFAULT nextval('public.danmaku_id_seq'::regclass);


--
-- Name: dynamic_likes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_likes ALTER COLUMN id SET DEFAULT nextval('public.dynamic_likes_id_seq'::regclass);


--
-- Name: favorite_folder_videos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folder_videos ALTER COLUMN id SET DEFAULT nextval('public.favorite_folder_videos_id_seq'::regclass);


--
-- Name: follows id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows ALTER COLUMN id SET DEFAULT nextval('public.follows_id_seq'::regclass);


--
-- Name: live_seats id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_seats ALTER COLUMN id SET DEFAULT nextval('public.live_seats_id_seq'::regclass);


--
-- Name: login_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_logs ALTER COLUMN id SET DEFAULT nextval('public.login_logs_id_seq'::regclass);


--
-- Name: manuscript_edit_versions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_edit_versions ALTER COLUMN id SET DEFAULT nextval('public.manuscript_edit_versions_id_seq'::regclass);


--
-- Name: manuscript_status_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_status_events ALTER COLUMN id SET DEFAULT nextval('public.manuscript_status_events_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: recommend_configs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommend_configs ALTER COLUMN id SET DEFAULT nextval('public.recommend_configs_id_seq'::regclass);


--
-- Name: scheduled_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_tasks ALTER COLUMN id SET DEFAULT nextval('public.scheduled_tasks_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: verification_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_codes ALTER COLUMN id SET DEFAULT nextval('public.verification_codes_id_seq'::regclass);


--
-- Name: video_process_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_process_events ALTER COLUMN id SET DEFAULT nextval('public.video_process_events_id_seq'::regclass);


--
-- Name: watch_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch_history ALTER COLUMN id SET DEFAULT nextval('public.watch_history_id_seq'::regclass);


--
-- Data for Name: admin_user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_user_roles (admin_user_id, role_id) FROM stdin;
1	1
2	4
3	3
4	7
7	8
8	9
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_users (id, username, password, admin_level, created_at, updated_at) FROM stdin;
1	super_admin	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	2	2026-03-05 22:50:02	2026-03-14 21:37:40
2	review_admin	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	1	2026-03-05 23:06:44	2026-03-05 23:06:44
3	operation_admin	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	1	2026-03-05 23:23:15	2026-03-14 21:37:36
4	system_admin	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	2	2026-08-20 10:41:33.729885	2026-08-20 10:41:33.729885
7	support_admin	8f55c8d32430356e156c61c5c6bdc27f173bad9161911b221c6c21602360636e	1	2026-08-25 13:16:34.010418	2026-08-25 13:16:34.010418
8	data_analyst	d12ff04552285860f3c8e4232d212ee11441bc478067543ee63505fe2dd4ef94	1	2026-08-25 13:16:34.014482	2026-08-25 13:16:34.014482
\.


--
-- Data for Name: ai_api_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_api_configs (id, name, base_url, api_key, model, max_tokens, temperature, enabled, extra_config, created_at, updated_at, type) FROM stdin;
\.


--
-- Data for Name: ai_bindings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_bindings (id, feature, api_config_id) FROM stdin;
\.


--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_chat_messages (id, conversation_id, role, content, token_count, created_at) FROM stdin;
\.


--
-- Data for Name: ai_conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_conversations (id, user_id, title, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_sessions (id, user_id, skill_id, type, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_skills (id, name, description, system_prompt, few_shot_examples, type, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_usage_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_usage_logs (id, feature, user_id, token_count, model, duration_ms, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, operator_id, operator_name, operator_role, module, action, target_type, target_id, request_method, request_uri, client_ip, user_agent, result, message, detail, created_at) FROM stdin;
1	1			user	UPDATE_USER_STATUS	users	99999					0	更新用户状态		2026-08-26 13:34:07.936539
2	1			role	DELETE_ROLE	roles	10					0	删除角色		2026-08-26 13:37:19.392263
3	1			user	UPDATE_USER_STATUS	users	5					0	更新用户状态		2026-08-26 14:17:44.64065
\.


--
-- Data for Name: banner_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.banner_images (id, title, image_url, link_url, sort_order, status, type, category_id, start_time, end_time, created_at, updated_at) FROM stdin;
1	无限零成本token，我给OpenClaw换了个永动机芯！	/uploads/manuscripts/11/cover.webp	/manuscript/11	1	1	1	1	\N	\N	2026-08-18 12:20:32.71276	2026-08-18 12:20:32.71276
2	github短视频生成工具	/uploads/manuscripts/31/cover.webp	/manuscript/31	2	1	1	7	\N	\N	2026-08-18 12:20:32.71276	2026-08-18 12:20:32.71276
3	数学怎么提分	/uploads/manuscripts/13/cover.webp	/manuscript/13	3	1	1	3	\N	\N	2026-08-18 12:20:32.71276	2026-08-18 12:20:32.71276
4	少儿乒乓球训练	/uploads/manuscripts/29/cover.webp	/manuscript/29	4	1	1	5	\N	\N	2026-08-18 12:20:32.71276	2026-08-18 12:20:32.71276
5	顶部背景图	/uploads/images/1773969662792_8880.webp	\N	0	1	3	\N	\N	\N	2026-08-26 02:56:27.184423	2026-08-26 02:56:27.184423
6	用户主页背景图	/uploads/images/1773969679049_3241.webp	\N	0	1	4	\N	\N	\N	2026-08-26 02:56:27.187789	2026-08-26 02:56:27.187789
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name, created_at, updated_at) FROM stdin;
1	人工智能	2026-03-02 18:28:07	2026-03-19 23:06:22
2	电子	2026-03-02 18:28:07	2026-03-19 22:24:53
3	数学	2026-03-02 18:28:07	2026-03-19 22:24:58
4	英语	2026-03-02 18:28:07	2026-03-19 22:25:10
5	运动	2026-03-02 18:28:07	2026-03-20 18:30:30
6	心理学	2026-03-02 18:28:07	2026-03-19 22:50:25
7	软件	2026-03-02 18:28:07	2026-03-19 22:50:31
8	硬件	2026-03-02 18:28:07	2026-03-19 22:50:35
9	物理	2026-03-02 18:28:07	2026-03-19 22:50:45
10	机械	2026-03-02 18:28:07	2026-03-19 23:07:22
11	科技	2026-03-02 18:28:07	2026-03-02 18:28:07
12	政治	2026-03-02 18:28:07	2026-03-20 18:30:22
13	历史	2026-03-02 18:28:07	2026-03-20 18:30:43
14	经济	2026-03-02 18:28:07	2026-03-20 18:30:14
15	文学	2026-03-02 18:28:07	2026-03-20 18:30:50
16	哲学	2026-03-02 18:28:07	2026-03-20 18:31:37
17	教育学	2026-03-02 18:28:07	2026-03-20 18:31:47
18	医学	2026-03-02 18:28:07	2026-03-20 18:32:00
19	管理学	2026-03-02 18:28:07	2026-03-20 18:32:07
20	艺术	2026-03-02 18:28:07	2026-03-20 18:32:16
21	地理	2026-03-02 18:28:07	2026-03-20 18:32:57
22	语言	2026-03-02 18:28:07	2026-03-20 18:33:01
23	测试	2026-03-19 23:07:36	2026-03-19 23:07:36
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (id, manuscript_id, user_id, content, like_count, reply_count, created_at, updated_at, status) FROM stdin;
6	\N	4	测试	1	3	2026-03-16 21:56:24	2026-03-20 18:23:08	0
8	10	4	有人吗？	0	0	2026-04-07 12:51:34	2026-04-07 12:51:34	0
9	13	4	数学好难呀	1	3	2026-04-10 17:48:37	2026-04-10 18:16:28	0
10	11	4	大家都在用什么工具写代码呀？	1	0	2026-04-10 18:05:37	2026-05-06 23:52:33	0
11	29	4	你好	0	0	2026-04-12 22:32:57	2026-04-12 22:32:57	0
12	29	4	我会打乒乓球	2	0	2026-04-12 22:39:51	2026-05-09 17:41:09	0
13	29	4	乒乓球怎么打？	1	1	2026-04-12 23:31:55	2026-05-09 17:41:07	0
14	27	4	hello	0	0	2026-04-12 23:39:32	2026-04-12 23:39:32	0
15	27	4	你好	1	1	2026-04-12 23:55:50	2026-05-09 19:07:41	0
16	12	4	crawfish	2	0	2026-04-29 15:55:17	2026-05-09 15:48:54	0
17	12	5	小龙虾 飞书机器人	0	0	2026-05-09 22:51:11	2026-05-09 22:51:11	0
18	11	4	测试评论	0	0	2026-08-26 12:54:30.337173	2026-08-26 12:54:30.337173	0
20	11	4	测试评论接口扫描	0	0	2026-08-26 13:27:13.700632	2026-08-26 13:27:13.700632	0
21	11	4	测试时间回填	0	0	2026-08-26 13:32:26.139252	2026-08-26 13:32:26.139252	0
3	10	4	你好	1	5	2026-03-15 14:23:23	2026-04-07 12:51:18	0
7	14	4	交流电压跟直流电压有什么区别呀？😁	2	2	2026-04-06 22:50:22	2026-05-09 19:42:10	0
\.


--
-- Data for Name: content_reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.content_reviews (id, type, user_id, content, status, reviewed_at, created_at) FROM stdin;
1	comment	4	测试评论	pending	\N	2026-08-26 12:54:30.352777+00
2	comment	5	studio测试评论	pending	\N	2026-08-26 12:58:50.142438+00
3	comment	4	测试评论接口扫描	pending	\N	2026-08-26 13:27:13.715838+00
4	comment	4	测试时间回填	pending	\N	2026-08-26 13:32:26.156067+00
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, user_id, target_user_id, last_message_id, last_message_content, last_message_time, unread_count, created_at, updated_at) FROM stdin;
10	6	5	91	在吗在吗	2026-05-09 19:41:38	1	2026-03-17 12:25:40	2026-05-09 19:41:37
11	6	4	83	你好，请问找我有什么事吗	2026-04-10 21:00:06	1	2026-03-20 11:48:21	2026-04-10 21:00:05
12	4	6	83	你好，请问找我有什么事吗	2026-04-10 21:00:05	0	2026-03-20 11:48:21	2026-04-10 21:00:05
25	6	8	\N	\N	2026-08-19 07:43:28.572587	0	2026-08-19 07:43:28.572587	2026-08-19 07:43:28.572587
24	8	6	\N	hello from testuser	2026-08-19 07:43:28.580367	1	2026-08-19 07:43:28.570769	2026-08-19 07:43:28.570769
26	4	4	\N	liked your manuscript	2026-08-26 14:03:34.626116	2	2026-08-26 13:22:40.814038	2026-08-26 13:22:40.814038
8	4	5	90	来自string的消息	2026-08-27 05:27:10.524717	2	2026-03-17 10:39:14	2026-05-16 20:35:54
9	5	6	91	测试红点	2026-08-27 05:26:57.464493	0	2026-03-17 12:25:40	2026-05-09 19:41:37
7	5	4	90	liked your comment	2026-08-26 06:50:18.801735	0	2026-03-17 10:39:14	2026-05-09 19:41:23
\.


--
-- Data for Name: creator_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.creator_settings (id, user_id, default_category_id, auto_publish, comment_notify, like_notify, follow_notify, created_at, updated_at) FROM stdin;
1	5	\N	0	1	1	1	2026-03-17 14:10:56	2026-03-17 14:10:56
2	4	\N	0	1	1	1	2026-03-17 14:12:03	2026-03-17 14:12:03
\.


--
-- Data for Name: danmaku; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.danmaku (id, video_id, manuscript_id, user_id, content, "time", color, mode, created_at) FROM stdin;
1	31	14	4	你好	0	#ffffff	0	2026-03-18 06:40:36.562+00
2	25	10	4	小龙虾	0	#ffffff	0	2026-03-20 03:45:24.479+00
3	25	10	6	openclaw	33.136513	#ffffff	0	2026-03-20 03:49:37.968+00
4	31	14	5	电压表	23.356331	#ffffff	0	2026-03-20 05:36:25.409+00
5	31	14	5	同款小米排插	24.048618	#ffffff	0	2026-03-20 05:36:59.664+00
6	26	11	5	你怎么看？	0	#ffffff	0	2026-03-22 12:04:12.325+00
7	26	11	5	大模型	119.067119	#ffffff	0	2026-03-22 12:04:21.529+00
8	29	12	4	openclaw	90.604689	#ffffff	0	2026-05-08 15:22:08.007+00
9	36	29	4	乒乓球	23.073065	#ffffff	0	2026-05-08 15:24:27.633+00
10	34	27	5	basketball	8.52862	#ffffff	0	2026-05-09 11:53:19.826+00
11	34	27	5	一段式投篮	38.903784	#A0EE00	0	2026-05-09 11:53:50.861+00
12	25	10	4	你好	2.217859	#ffffff	0	2026-05-10 01:30:37.023+00
14	29	12	4	你好	0	#ffffff	0	2026-08-26 12:30:00.311335+00
15	29	12	4	你好	0	#ffffff	0	2026-08-26 12:30:02.69993+00
16	34	27	4	偷懒	10	#ffffff	0	2026-08-26 12:30:41.877339+00
17	25	10	5	测试弹幕	1.5	#ffffff	0	2026-08-26 12:32:10.07436+00
18	25	10	5	代理测试	2.5	#ffffff	0	2026-08-26 12:32:10.094496+00
19	25	10	5	信封测试	3.5	#ffffff	0	2026-08-26 12:34:23.367481+00
20	25	10	5	字符串时间	0	#ffffff	0	2026-08-26 12:34:23.390457+00
21	29	12	4	在吗	88.002798	#ffffff	0	2026-08-26 12:36:38.311037+00
22	0	0	4	测试	1	#fff	0	2026-08-26 12:54:30.427682+00
23	0	0	4	测试弹幕扫描	1.5	#FFFFFF	0	2026-08-26 13:33:13.014415+00
25	0	0	4	x	1		0	2026-08-26 13:33:13.085315+00
26	999999	0	4	x	1		0	2026-08-26 13:38:04.617484+00
27	25	0	4	测试弹幕	2.5		0	2026-08-26 13:38:04.64634+00
\.


--
-- Data for Name: dynamic_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dynamic_comments (id, dynamic_id, user_id, content, parent_id, reply_user_id, like_count, status, created_at, updated_at) FROM stdin;
1	3	5	你好	\N	\N	0	1	2026-03-30 22:07:36	2026-03-30 22:07:36
6	1	4	你们好😄	\N	\N	0	0	2026-04-08 12:11:31	2026-04-08 12:11:31
7	1	4	你们好	\N	\N	0	0	2026-04-08 12:11:48	2026-04-08 12:11:48
10	3	4	这是什么图片？	\N	\N	1	0	2026-04-30 10:32:57	2026-04-30 13:46:45
11	2	4	你好	\N	\N	1	0	2026-04-30 13:47:01	2026-04-30 13:47:03
13	3	4	你好	10	\N	0	0	2026-04-30 15:54:04	2026-04-30 15:54:04
14	3	4	怎么说	10	4	0	0	2026-04-30 15:54:14	2026-04-30 15:54:14
15	3	4	你好	10	\N	0	0	2026-04-30 15:59:54	2026-04-30 15:59:54
17	1	4	66666	9	4	0	0	2026-05-09 14:32:52	2026-05-09 14:32:52
16	1	4	6666	9	\N	3	0	2026-05-02 22:57:02	2026-05-02 22:57:04
12	3	4	哈喽哈喽	10	\N	0	0	2026-04-30 15:33:59	2026-04-30 15:33:59
18	3	4	统一测试	\N	\N	0	2	2026-08-26 07:46:41.202455	2026-08-26 07:46:41.202455
19	3	5	回复测试	18	\N	0	2	2026-08-26 07:46:41.449331	2026-08-26 07:46:41.449331
8	1	4	你们好啊	\N	\N	0	0	2026-04-22 14:04:26	2026-04-22 14:04:26
9	1	4	你们好啊	\N	\N	1	0	2026-04-22 14:05:02	2026-05-02 22:56:39
\.


--
-- Data for Name: dynamic_likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dynamic_likes (id, dynamic_id, user_id, created_at) FROM stdin;
5	1	4	2026-08-26 09:19:36.224447+00
9	-576823294	4	2026-08-26 09:23:41.757263+00
\.


--
-- Data for Name: favorite_folder_videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorite_folder_videos (id, folder_id, manuscript_id, created_at) FROM stdin;
3	2	12	2026-03-20 12:00:57+00
4	5	12	2026-03-20 12:00:57+00
5	1	13	2026-03-20 12:01:05+00
6	5	14	2026-03-20 14:03:20+00
7	1	11	2026-03-20 20:30:38+00
8	2	11	2026-03-20 20:30:38+00
9	5	11	2026-03-20 20:30:38+00
10	3	14	2026-03-28 14:26:41+00
11	3	11	2026-04-11 12:21:57+00
12	4	11	2026-04-11 12:21:57+00
13	3	29	2026-04-30 22:40:05+00
14	8	27	2026-05-09 16:52:16+00
15	7	14	2026-05-09 17:41:57+00
17	8	10	2026-08-26 12:50:49.815157+00
\.


--
-- Data for Name: favorite_folders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorite_folders (id, user_id, name, collect_count, created_at, updated_at) FROM stdin;
1	5	数学	3	2026-03-12 17:45:36	2026-03-20 20:30:38
2	5	AI	3	2026-03-12 17:45:58	2026-03-20 20:30:38
3	4	默认收藏夹	3	2026-03-13 17:34:21	2026-04-30 22:40:05
4	4	AI	1	2026-03-15 14:49:02	2026-05-08 14:41:35
5	5	默认收藏夹	3	2026-03-11 20:47:41	2026-03-20 20:30:38
6	6	默认收藏夹	0	2026-03-17 09:00:09	2026-03-17 09:00:09
7	5	计算机	1	2026-05-09 16:52:06	2026-05-09 17:41:57
8	5	篮球	1	2026-05-09 16:52:14	2026-05-09 16:52:16
14	7	默认收藏夹	0	2026-05-20 23:34:58	2026-05-20 23:34:58
15	5	测试夹	0	2026-08-26 12:50:49.745665	2026-08-26 12:50:49.745665
16	4	测试收藏夹扫描	0	2026-08-26 13:39:50.35367	2026-08-26 13:39:50.35367
\.


--
-- Data for Name: favorite_manuscripts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.favorite_manuscripts (id, folder_id, manuscript_id, created_at) FROM stdin;
19	1	10	2026-03-20 12:00:48
20	2	10	2026-03-20 12:00:48
21	2	12	2026-03-20 12:00:57
22	5	12	2026-03-20 12:00:57
23	1	13	2026-03-20 12:01:05
24	5	14	2026-03-20 14:03:20
25	1	11	2026-03-20 20:30:38
26	2	11	2026-03-20 20:30:38
27	5	11	2026-03-20 20:30:38
29	3	14	2026-03-28 14:26:41
31	3	11	2026-04-11 12:21:57
32	4	11	2026-04-11 12:21:57
33	3	29	2026-04-30 22:40:05
34	8	27	2026-05-09 16:52:16
35	7	14	2026-05-09 17:41:57
\.


--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.follows (id, follower_id, following_id, created_at) FROM stdin;
3	5	4	2026-08-26 03:18:17.465708+00
\.


--
-- Data for Name: jsonb_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jsonb_documents (id, collection_name, doc_json, created_at, updated_at) FROM stdin;
1787119976018436412	user_profiles	{"id": "1787119976018436412", "tags": null, "user_id": 8, "like_count": 0, "updated_at": "2026-08-19T14:12:56.017241621+08:00", "watch_count": 0, "collect_count": 0, "favorite_categories": null}	2026-08-19 06:12:56.018979+00	2026-08-19 06:12:56.018979+00
sub_25_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 4.34, \\"text\\": \\"本期视频介绍一款自带免费无线token的小龙虾版本\\"}, {\\"index\\": 2, \\"startTime\\": 4.34, \\"endTime\\": 8.2, \\"text\\": \\"这是由数则大佬开发的OpenCla 中文分支版\\"}, {\\"index\\": 3, \\"startTime\\": 8.2, \\"endTime\\": 12.74, \\"text\\": \\"该版本可无线免费使用Deepseq和千万的Web版模型\\"}, {\\"index\\": 4, \\"startTime\\": 12.74, \\"endTime\\": 16.84, \\"text\\": \\"其中包含联网石图、编程深度思考等多种模型\\"}, {\\"index\\": 5, \\"startTime\\": 16.84, \\"endTime\\": 19.24, \\"text\\": \\"从此养虾再也不怕烧token了\\"}, {\\"index\\": 6, \\"startTime\\": 19.24, \\"endTime\\": 22.64, \\"text\\": \\"同时该项目不但对官方版本进行了焊化\\"}, {\\"index\\": 7, \\"startTime\\": 22.64, \\"endTime\\": 26.88, \\"text\\": \\"还对逻辑思考认知能力、出错能力进行了深度的升级\\"}, {\\"index\\": 8, \\"startTime\\": 26.88, \\"endTime\\": 28.88, \\"text\\": \\"那么接下来就让我们尝试\\"}, {\\"index\\": 9, \\"startTime\\": 28.88, \\"endTime\\": 31.88, \\"text\\": \\"在Windows系统内进行安装\\"}, {\\"index\\": 10, \\"startTime\\": 31.88, \\"endTime\\": 36.32, \\"text\\": \\"首先需要安装两个系统所需的依赖程序\\"}, {\\"index\\": 11, \\"startTime\\": 36.32, \\"endTime\\": 40.08, \\"text\\": \\"Node和Gate执行安装程序无脑下一步即可\\"}, {\\"index\\": 12, \\"startTime\\": 40.08, \\"endTime\\": 43.28, \\"text\\": \\"两个程序的安装包我已经放到了网盘里\\"}, {\\"index\\": 13, \\"startTime\\": 43.28, \\"endTime\\": 48.08, \\"text\\": \\"大家可以去视频简介或者评论区找一找网盘链接\\"}, {\\"index\\": 14, \\"startTime\\": 48.08, \\"endTime\\": 50.88, \\"text\\": \\"好的那么基础的依赖安装好之后\\"}, {\\"index\\": 15, \\"startTime\\": 50.88, \\"endTime\\": 54.68, \\"text\\": \\"我们可以去到一个空的文件夹内点击鼠标右键\\"}, {\\"index\\": 16, \\"startTime\\": 54.68, \\"endTime\\": 56.98, \\"text\\": \\"然后选择在中端中打开\\"}, {\\"index\\": 17, \\"startTime\\": 56.98, \\"endTime\\": 61.38, \\"text\\": \\"让我们来输入两个命令验证Node和Gate是否安装成功了\\"}, {\\"index\\": 18, \\"startTime\\": 61.38, \\"endTime\\": 65.18, \\"text\\": \\"如果命令行返回了版本号那就说明安装成功\\"}, {\\"index\\": 19, \\"startTime\\": 65.18, \\"endTime\\": 67.48, \\"text\\": \\"但是如果跳出了一些红字\\"}, {\\"index\\": 20, \\"startTime\\": 67.48, \\"endTime\\": 71.28, \\"text\\": \\"那么你就需要选中这些红字在点击鼠标右键\\"}, {\\"index\\": 21, \\"startTime\\": 71.28, \\"endTime\\": 75.28, \\"text\\": \\"然后去逗包直接粘贴错误信息问问看怎么解决\\"}, {\\"index\\": 22, \\"startTime\\": 75.28, \\"endTime\\": 78.48, \\"text\\": \\"正常情况下我们都可以顺利走到这一步\\"}, {\\"index\\": 23, \\"startTime\\": 78.48, \\"endTime\\": 81.78, \\"text\\": \\"网盘里我还会提供新版的命令行工具\\"}, {\\"index\\": 24, \\"startTime\\": 81.78, \\"endTime\\": 85.68, \\"text\\": \\"以及我一直在用的科学上网工具\\"}, {\\"index\\": 25, \\"startTime\\": 85.68, \\"endTime\\": 89.28, \\"text\\": \\"那么接下来就到了正式安装小龙虾的时间了\\"}, {\\"index\\": 26, \\"startTime\\": 89.28, \\"endTime\\": 90.88, \\"text\\": \\"为了方便大家使用\\"}, {\\"index\\": 27, \\"startTime\\": 90.88, \\"endTime\\": 94.58, \\"text\\": \\"我已经提前下载好了硕则大佬的项目文件包\\"}, {\\"index\\": 28, \\"startTime\\": 94.58, \\"endTime\\": 98.28, \\"text\\": \\"大家可以直接将压缩包解压到你的地盘跟墨路\\"}, {\\"index\\": 29, \\"startTime\\": 98.28, \\"endTime\\": 101.48, \\"text\\": \\"当然你想解压到其他位置也都可以\\"}, {\\"index\\": 30, \\"startTime\\": 101.48, \\"endTime\\": 105.88, \\"text\\": \\"如果你懂得如何使用Gate Clone命令拉取项目文件\\"}, {\\"index\\": 31, \\"startTime\\": 105.88, \\"endTime\\": 109.18, \\"text\\": \\"那么你也可以考虑不用我提供的项目包\\"}, {\\"index\\": 32, \\"startTime\\": 109.18, \\"endTime\\": 113.98, \\"text\\": \\"自己手动在命令行中拉取最新的项目文件也是可以的\\"}, {\\"index\\": 33, \\"startTime\\": 113.98, \\"endTime\\": 118.48, \\"text\\": \\"当然在网盘中我也会持续更新一段时间\\"}, {\\"index\\": 34, \\"startTime\\": 118.48, \\"endTime\\": 121.88, \\"text\\": \\"好了解压完成后我们可以删除压缩包\\"}, {\\"index\\": 35, \\"startTime\\": 121.88, \\"endTime\\": 124.28, \\"text\\": \\"并对项目墨路进行改名\\"}, {\\"index\\": 36, \\"startTime\\": 124.28, \\"endTime\\": 128.28, \\"text\\": \\"使用命令行操作的同学可以复制这段改名的命令\\"}, {\\"index\\": 37, \\"startTime\\": 128.28, \\"endTime\\": 132.38, \\"text\\": \\"正常解压说的同学可以直接手动修改文件夹名称\\"}, {\\"index\\": 38, \\"startTime\\": 132.38, \\"endTime\\": 135.38, \\"text\\": \\"其实修改名称这一步不是必须的\\"}, {\\"index\\": 39, \\"startTime\\": 135.38, \\"endTime\\": 139.18, \\"text\\": \\"我这么做纯粹是想文件夹名称简单点\\"}, {\\"index\\": 40, \\"startTime\\": 139.18, \\"endTime\\": 143.78, \\"text\\": \\"解压完成后打开文件夹看看是不是看到了项目文件\\"}, {\\"index\\": 41, \\"startTime\\": 143.78, \\"endTime\\": 145.68, \\"text\\": \\"接下来是很重要的一步\\"}, {\\"index\\": 42, \\"startTime\\": 145.68, \\"endTime\\": 149.68, \\"text\\": \\"但我们在项目文件夹内的空白处点击鼠标右键\\"}, {\\"index\\": 43, \\"startTime\\": 149.68, \\"endTime\\": 151.98, \\"text\\": \\"然后选择在中端内打开\\"}, {\\"index\\": 44, \\"startTime\\": 151.98, \\"endTime\\": 155.78, \\"text\\": \\"此时你应该能看到命令行墨路就是你的项目墨路\\"}, {\\"index\\": 45, \\"startTime\\": 155.78, \\"endTime\\": 159.68, \\"text\\": \\"然后复制这句命令让电脑自动安装项目依赖\\"}, {\\"index\\": 46, \\"startTime\\": 159.68, \\"endTime\\": 161.58, \\"text\\": \\"我这里视频加个速\\"}, {\\"index\\": 47, \\"startTime\\": 161.58, \\"endTime\\": 168.18, \\"text\\": \\"安装完成之后只要没有下人的大段红字错误信息\\"}, {\\"index\\": 48, \\"startTime\\": 168.18, \\"endTime\\": 172.68, \\"text\\": \\"那我们就可以接着复制这句命令进行项目编译\\"}, {\\"index\\": 49, \\"startTime\\": 172.68, \\"endTime\\": 174.48, \\"text\\": \\"我这里视频继续加个速\\"}, {\\"index\\": 50, \\"startTime\\": 174.48, \\"endTime\\": 180.98, \\"text\\": \\"编译好之后我们就已经将小龙虾安装完成了\\"}, {\\"index\\": 51, \\"startTime\\": 180.98, \\"endTime\\": 185.18, \\"text\\": \\"你可以试试输入这个命令看有没有出现小龙虾的版本好\\"}, {\\"index\\": 52, \\"startTime\\": 185.18, \\"endTime\\": 191.78, \\"text\\": \\"目前项目版本是3.1版\\"}, {\\"index\\": 53, \\"startTime\\": 191.78, \\"endTime\\": 195.68, \\"text\\": \\"OK接下来需要对OpenCloud做初始化配置\\"}, {\\"index\\": 54, \\"startTime\\": 195.68, \\"endTime\\": 198.98, \\"text\\": \\"输入这段命令你将会看到中文版的配置说明\\"}, {\\"index\\": 55, \\"startTime\\": 202.78, \\"endTime\\": 204.78, \\"text\\": \\"对于首个安全提示问题\\"}, {\\"index\\": 56, \\"startTime\\": 204.78, \\"endTime\\": 206.48, \\"text\\": \\"我们点按键盘的左键\\"}, {\\"index\\": 57, \\"startTime\\": 206.48, \\"endTime\\": 209.68, \\"text\\": \\"选择Yes再按回车键确认选择\\"}, {\\"index\\": 58, \\"startTime\\": 209.68, \\"endTime\\": 213.58, \\"text\\": \\"第二个问题我们直接按回车键选择快速启动\\"}, {\\"index\\": 59, \\"startTime\\": 213.58, \\"endTime\\": 217.28, \\"text\\": \\"第三个问题需要我们选择小龙虾的核心模型\\"}, {\\"index\\": 60, \\"startTime\\": 217.28, \\"endTime\\": 220.28, \\"text\\": \\"这里我们点按键盘的上键或者下键\\"}, {\\"index\\": 61, \\"startTime\\": 220.28, \\"endTime\\": 223.58, \\"text\\": \\"选择Deep Seek Browser并按回车键确认\\"}, {\\"index\\": 62, \\"startTime\\": 223.58, \\"endTime\\": 228.58, \\"text\\": \\"确认之后小龙虾需要我们进行一次网页登录\\"}, {\\"index\\": 63, \\"startTime\\": 228.58, \\"endTime\\": 232.28, \\"text\\": \\"这里我们直接按回车键选择Automated Logging\\"}, {\\"index\\": 64, \\"startTime\\": 232.98, \\"endTime\\": 236.98, \\"text\\": \\"之后小龙虾会自动启动浏览器并打开Deep Seek首页\\"}, {\\"index\\": 65, \\"startTime\\": 236.98, \\"endTime\\": 240.38, \\"text\\": \\"我们输入登录账号后浏览器会自动关闭\\"}, {\\"index\\": 66, \\"startTime\\": 240.38, \\"endTime\\": 244.48, \\"text\\": \\"接着你会看到小龙虾已经识别到了多个Deep Seek模型\\"}, {\\"index\\": 67, \\"startTime\\": 244.48, \\"endTime\\": 248.28, \\"text\\": \\"我们可以按上下键选择一个小龙虾的主力模型\\"}, {\\"index\\": 68, \\"startTime\\": 248.28, \\"endTime\\": 251.68, \\"text\\": \\"或者你也可以选择作者推荐的当前模型\\"}, {\\"index\\": 69, \\"startTime\\": 251.68, \\"endTime\\": 255.28, \\"text\\": \\"这里你看到的模型都是可以免费无限使用的\\"}, {\\"index\\": 70, \\"startTime\\": 255.28, \\"endTime\\": 257.28, \\"text\\": \\"按回车键确认选择\\"}, {\\"index\\": 71, \\"startTime\\": 257.28, \\"endTime\\": 261.98, \\"text\\": \\"到了这一步是选择手机上接入的聊天工具\\"}, {\\"index\\": 72, \\"startTime\\": 261.98, \\"endTime\\": 264.18, \\"text\\": \\"我们可以选择暂时跳过\\"}, {\\"index\\": 73, \\"startTime\\": 264.18, \\"endTime\\": 267.78, \\"text\\": \\"接着关于技能的配置\\"}, {\\"index\\": 74, \\"startTime\\": 267.78, \\"endTime\\": 269.98, \\"text\\": \\"我们按右方向键选择No\\"}, {\\"index\\": 75, \\"startTime\\": 269.98, \\"endTime\\": 273.88, \\"text\\": \\"再按回车键确认因为暂时不用去管这些技能\\"}, {\\"index\\": 76, \\"startTime\\": 273.88, \\"endTime\\": 275.48, \\"text\\": \\"到了后口设置环节\\"}, {\\"index\\": 77, \\"startTime\\": 275.48, \\"endTime\\": 278.08, \\"text\\": \\"我们可以按下方向键再按空格键\\"}, {\\"index\\": 78, \\"startTime\\": 278.08, \\"endTime\\": 281.98, \\"text\\": \\"一次的把这几项都勾选上然后按回车键确认\\"}, {\\"index\\": 79, \\"startTime\\": 281.98, \\"endTime\\": 285.38, \\"text\\": \\"到此小龙虾的初始化设置就结束了\\"}, {\\"index\\": 80, \\"startTime\\": 285.38, \\"endTime\\": 288.68, \\"text\\": \\"我们选择Rista 按回车键确认\\"}, {\\"index\\": 81, \\"startTime\\": 288.68, \\"endTime\\": 291.88, \\"text\\": \\"稍等片刻就可以看到小龙虾的页面了\\"}, {\\"index\\": 82, \\"startTime\\": 291.88, \\"endTime\\": 293.68, \\"text\\": \\"如果你的页面显示失败\\"}, {\\"index\\": 83, \\"startTime\\": 293.68, \\"endTime\\": 295.78, \\"text\\": \\"那你需要回到命令航窗口\\"}, {\\"index\\": 84, \\"startTime\\": 295.78, \\"endTime\\": 298.38, \\"text\\": \\"输入这句命令启动小龙虾服务\\"}, {\\"index\\": 85, \\"startTime\\": 298.38, \\"endTime\\": 300.38, \\"text\\": \\"要注意当服务启动之后\\"}, {\\"index\\": 86, \\"startTime\\": 300.38, \\"endTime\\": 302.98, \\"text\\": \\"这个命令航窗口就不可以关掉了\\"}, {\\"index\\": 87, \\"startTime\\": 302.98, \\"endTime\\": 305.48, \\"text\\": \\"否则小龙虾的服务会停止\\"}, {\\"index\\": 88, \\"startTime\\": 305.48, \\"endTime\\": 308.18, \\"text\\": \\"如果你不小心还是关掉了这个窗口\\"}, {\\"index\\": 89, \\"startTime\\": 308.18, \\"endTime\\": 311.28, \\"text\\": \\"也没关系只要打开新的命令航窗口\\"}, {\\"index\\": 90, \\"startTime\\": 311.28, \\"endTime\\": 312.78, \\"text\\": \\"去到小龙虾的目录\\"}, {\\"index\\": 91, \\"startTime\\": 312.78, \\"endTime\\": 315.58, \\"text\\": \\"然后执行这个服务启动命令即可\\"}, {\\"index\\": 92, \\"startTime\\": 315.58, \\"endTime\\": 319.18, \\"text\\": \\"服务启动后我们再回到浏览器刷新页面\\"}, {\\"index\\": 93, \\"startTime\\": 319.18, \\"endTime\\": 322.08, \\"text\\": \\"就可以看到小龙虾的对话窗口了\\"}, {\\"index\\": 94, \\"startTime\\": 322.08, \\"endTime\\": 325.18, \\"text\\": \\"到这里我们就已经完成了小龙虾的安装\\"}, {\\"index\\": 95, \\"startTime\\": 325.18, \\"endTime\\": 328.98, \\"text\\": \\"并且拥有了无线Token的Deep Seek模型\\"}, {\\"index\\": 96, \\"startTime\\": 328.98, \\"endTime\\": 331.38, \\"text\\": \\"因为硕则大佬除了Deep Seek模型\\"}, {\\"index\\": 97, \\"startTime\\": 331.38, \\"endTime\\": 332.98, \\"text\\": \\"还提供了千万模型\\"}, {\\"index\\": 98, \\"startTime\\": 332.98, \\"endTime\\": 335.58, \\"text\\": \\"植入千万模型的方法也很简单\\"}, {\\"index\\": 99, \\"startTime\\": 335.58, \\"endTime\\": 337.38, \\"text\\": \\"只要回到命令航窗口\\"}, {\\"index\\": 100, \\"startTime\\": 337.38, \\"endTime\\": 340.28, \\"text\\": \\"按Ctrl+C 停止运行当前服务\\"}, {\\"index\\": 101, \\"startTime\\": 340.28, \\"endTime\\": 342.88, \\"text\\": \\"然后再粘贴初始化命令按回车\\"}, {\\"index\\": 102, \\"startTime\\": 342.88, \\"endTime\\": 344.98, \\"text\\": \\"重新走一遍初始化设置\\"}, {\\"index\\": 103, \\"startTime\\": 344.98, \\"endTime\\": 348.38, \\"text\\": \\"在模型选择环节去选择千万模型即可\\"}, {\\"index\\": 104, \\"startTime\\": 348.38, \\"endTime\\": 351.98, \\"text\\": \\"后面的流程与选择DPCK模型的流程一样\\"}, {\\"index\\": 105, \\"startTime\\": 351.98, \\"endTime\\": 354.38, \\"text\\": \\"小龙虾打开浏览器你来登录\\"}, {\\"index\\": 106, \\"startTime\\": 354.38, \\"endTime\\": 356.18, \\"text\\": \\"选择一堆设置项\\"}, {\\"index\\": 107, \\"startTime\\": 356.18, \\"endTime\\": 359.18, \\"text\\": \\"然后再次去命令航启动服务\\"}, {\\"index\\": 108, \\"startTime\\": 359.18, \\"endTime\\": 361.98, \\"text\\": \\"这时我们的小龙虾就同时拥有了\\"}, {\\"index\\": 109, \\"startTime\\": 361.98, \\"endTime\\": 364.88, \\"text\\": \\"Deep Seek模型和千万模型\\"}, {\\"index\\": 110, \\"startTime\\": 364.88, \\"endTime\\": 367.68, \\"text\\": \\"接下来你就可以开始无压力的养虾了\\"}, {\\"index\\": 111, \\"startTime\\": 367.68, \\"endTime\\": 370.08, \\"text\\": \\"那么本期视频也就到这里了\\"}, {\\"index\\": 112, \\"startTime\\": 370.08, \\"endTime\\": 371.78, \\"text\\": \\"视频录制的比较仓促\\"}, {\\"index\\": 113, \\"startTime\\": 371.78, \\"endTime\\": 373.38, \\"text\\": \\"如果对你有所帮助\\"}, {\\"index\\": 114, \\"startTime\\": 373.38, \\"endTime\\": 374.68, \\"text\\": \\"还请一键三连\\"}, {\\"index\\": 115, \\"startTime\\": 374.68, \\"endTime\\": 376.68, \\"text\\": \\"您的鼓励是我最大的动力\\"}, {\\"index\\": 116, \\"startTime\\": 376.68, \\"endTime\\": 378.18, \\"text\\": \\"如果您有什么疑问\\"}, {\\"index\\": 117, \\"startTime\\": 378.18, \\"endTime\\": 381.18, \\"text\\": \\"可以留言或者加入交流群讨论\\"}, {\\"index\\": 118, \\"startTime\\": 381.18, \\"endTime\\": 383.18, \\"text\\": \\"好了 我们下期视频再见\\"}]", "language": "zh-CN", "video_id": 25, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_31_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 2.56, \\"text\\": \\"如何使用這台萬用錶檢測電壓\\"}, {\\"index\\": 2, \\"startTime\\": 2.56, \\"endTime\\": 5.16, \\"text\\": \\"首先按確定鍵進入萬用錶頁面\\"}, {\\"index\\": 3, \\"startTime\\": 5.16, \\"endTime\\": 7.0, \\"text\\": \\"可以在自動檔位測量\\"}, {\\"index\\": 4, \\"startTime\\": 7.0, \\"endTime\\": 8.92, \\"text\\": \\"也可以在電壓檔位測量\\"}, {\\"index\\": 5, \\"startTime\\": 8.92, \\"endTime\\": 10.56, \\"text\\": \\"我們調整到電壓檔位\\"}, {\\"index\\": 6, \\"startTime\\": 10.56, \\"endTime\\": 12.28, \\"text\\": \\"拿出我們的電池和錶筆\\"}, {\\"index\\": 7, \\"startTime\\": 12.28, \\"endTime\\": 13.84, \\"text\\": \\"紅色錶筆接正極\\"}, {\\"index\\": 8, \\"startTime\\": 13.84, \\"endTime\\": 15.24, \\"text\\": \\"黑色錶筆接附極\\"}, {\\"index\\": 9, \\"startTime\\": 15.24, \\"endTime\\": 17.6, \\"text\\": \\"此時會顯示測得的電壓\\"}, {\\"index\\": 10, \\"startTime\\": 17.6, \\"endTime\\": 20.48, \\"text\\": \\"按一下模式鍵切換交流電壓測量\\"}, {\\"index\\": 11, \\"startTime\\": 20.48, \\"endTime\\": 22.84, \\"text\\": \\"此時將錶筆同時插入插座\\"}, {\\"index\\": 12, \\"startTime\\": 22.84, \\"endTime\\": 24.84, \\"text\\": \\"即可測得交流電壓值\\"}]", "language": "zh-CN", "video_id": 31, "is_default": false, "uploaded_by": 0, "language_name": "简体中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_26_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 4.92, \\"text\\": \\"如果你在用 Cloud Code 或 Cursor 鞋带码,\\"}, {\\"index\\": 2, \\"startTime\\": 4.92, \\"endTime\\": 8.28, \\"text\\": \\"每次工具调用都在吞噬你最宝贵的资源。\\"}, {\\"index\\": 3, \\"startTime\\": 8.28, \\"endTime\\": 13.04, \\"text\\": \\"Context Window 有个项目说能省 98%。\\"}, {\\"index\\": 4, \\"startTime\\": 13.04, \\"endTime\\": 15.94, \\"text\\": \\"但我的判断是,Sentoken 只是表面。\\"}, {\\"index\\": 5, \\"startTime\\": 15.94, \\"endTime\\": 19.56, \\"text\\": \\"这背后是 AI Agent 开发的架构盲区。\\"}, {\\"index\\": 6, \\"startTime\\": 19.56, \\"endTime\\": 27.1, \\"text\\": \\"大家好,这里是 LLMX Factors,一个专注于拆解大语言模型时代底层逻辑的频道。\\"}, {\\"index\\": 7, \\"startTime\\": 27.1, \\"endTime\\": 33.22, \\"text\\": \\"一次 Playwright 快照 50,000 投坑,一次 Git Log 15,000。\\"}, {\\"index\\": 8, \\"startTime\\": 33.22, \\"endTime\\": 36.76, \\"text\\": \\"三四个工具连着条,10,000 投坑就没了。\\"}, {\\"index\\": 9, \\"startTime\\": 36.76, \\"endTime\\": 39.06, \\"text\\": \\"Context Window 才 20,000。\\"}, {\\"index\\": 10, \\"startTime\\": 39.06, \\"endTime\\": 41.78, \\"text\\": \\"Context Mode 能压到 1,000-2,000。\\"}, {\\"index\\": 11, \\"startTime\\": 41.78, \\"endTime\\": 45.78, \\"text\\": \\"但更值得关注的是社区讨论里暴露的深层问题。\\"}, {\\"index\\": 12, \\"startTime\\": 45.78, \\"endTime\\": 48.1, \\"text\\": \\"先看看问题有多严重。\\"}, {\\"index\\": 13, \\"startTime\\": 48.1, \\"endTime\\": 52.06, \\"text\\": \\"你越勤快地使用工具,你的绘画死得越快。\\"}, {\\"index\\": 14, \\"startTime\\": 52.06, \\"endTime\\": 54.54, \\"text\\": \\"每次调用,原始数据用进来。\\"}, {\\"index\\": 15, \\"startTime\\": 54.54, \\"endTime\\": 59.02, \\"text\\": \\"几次之后,Context 就被预置 Jason 快照填满了。\\"}, {\\"index\\": 16, \\"startTime\\": 59.02, \\"endTime\\": 62.1, \\"text\\": \\"模型开始忘记之前说过什么,反低级错误。\\"}, {\\"index\\": 17, \\"startTime\\": 62.1, \\"endTime\\": 64.42, \\"text\\": \\"你只能开新汇,画从头来。\\"}, {\\"index\\": 18, \\"startTime\\": 64.42, \\"endTime\\": 71.86, \\"text\\": \\"举个例子,你让 AI 跑测试,你只需要知道通过没有,哪行失败了,什么错误。\\"}, {\\"index\\": 19, \\"startTime\\": 71.86, \\"endTime\\": 74.42, \\"text\\": \\"但进入 Context 的是完整预置。\\"}, {\\"index\\": 20, \\"startTime\\": 74.42, \\"endTime\\": 77.94, \\"text\\": \\"所有通过失败的细节,堆盏追踪,环境变亮。\\"}, {\\"index\\": 21, \\"startTime\\": 77.94, \\"endTime\\": 80.66, \\"text\\": \\"九成 Token 花在你根本不需要的信息上。\\"}, {\\"index\\": 22, \\"startTime\\": 80.66, \\"endTime\\": 83.3, \\"text\\": \\"Context Mode 是怎么解决的?\\"}, {\\"index\\": 23, \\"startTime\\": 83.3, \\"endTime\\": 88.7, \\"text\\": \\"思路很简单,与其数据进来在压缩,不如一开始就不让它进来。\\"}, {\\"index\\": 24, \\"startTime\\": 88.7, \\"endTime\\": 93.58, \\"text\\": \\"工具执行,放进纱盒子进尘,原始输出,永远不进对话历史。\\"}, {\\"index\\": 25, \\"startTime\\": 93.58, \\"endTime\\": 95.98, \\"text\\": \\"只有减短摘要,回到 Context。\\"}, {\\"index\\": 26, \\"startTime\\": 95.98, \\"endTime\\": 99.42, \\"text\\": \\"完整数据,存进本地 SQLite 全文搜索所引。\\"}, {\\"index\\": 27, \\"startTime\\": 99.42, \\"endTime\\": 101.9, \\"text\\": \\"模型需要细节时,可以主动查。\\"}, {\\"index\\": 28, \\"startTime\\": 101.9, \\"endTime\\": 105.74, \\"text\\": \\"关键细节:不需要额外大模型调用。\\"}, {\\"index\\": 29, \\"startTime\\": 105.74, \\"endTime\\": 110.46, \\"text\\": \\"用 SQLite 内置的 FTS5 全文搜索加 BM25 排序。\\"}, {\\"index\\": 30, \\"startTime\\": 110.46, \\"endTime\\": 114.14, \\"text\\": \\"纯算法,凌乘本,确定性输出。\\"}, {\\"index\\": 31, \\"startTime\\": 114.14, \\"endTime\\": 118.86, \\"text\\": \\"同样的查询,永远返回同样的结果,对缓存非常友好。\\"}, {\\"index\\": 32, \\"startTime\\": 118.86, \\"endTime\\": 125.22, \\"text\\": \\"社区有个更聪明的思路,有人指出纯关键次匹配在结构化数据上不够好。\\"}, {\\"index\\": 33, \\"startTime\\": 125.22, \\"endTime\\": 133.06, \\"text\\": \\"做了混合方案,FTS5 做精准匹配函数名,变亮名,向亮搜索,做语义理解。\\"}, {\\"index\\": 34, \\"startTime\\": 133.06, \\"endTime\\": 139.94, \\"text\\": \\"用 RRF 融合两种结果,它用这套方案锁引了一万五千多个文件,效果很好。\\"}, {\\"index\\": 35, \\"startTime\\": 139.94, \\"endTime\\": 142.42, \\"text\\": \\"但实测发现一个硬伤。\\"}, {\\"index\\": 36, \\"startTime\\": 142.42, \\"endTime\\": 145.66, \\"text\\": \\"Context Mode 只能拦截内置工具。\\"}, {\\"index\\": 37, \\"startTime\\": 145.66, \\"endTime\\": 148.26, \\"text\\": \\"第三方 MCP 工具完全无效。\\"}, {\\"index\\": 38, \\"startTime\\": 148.26, \\"endTime\\": 154.26, \\"text\\": \\"因为 MCP 响应通过 JSON RPC 直接发给模型,没有 Hook 可以拦截。\\"}, {\\"index\\": 39, \\"startTime\\": 154.26, \\"endTime\\": 157.54, \\"text\\": \\"MCP 工具返回大量数据时,Token 照样吃掉。\\"}, {\\"index\\": 40, \\"startTime\\": 157.54, \\"endTime\\": 160.54, \\"text\\": \\"这个问题只能 MCP 开发者在服务端解决。\\"}, {\\"index\\": 41, \\"startTime\\": 160.54, \\"endTime\\": 165.06, \\"text\\": \\"但比技术方案更重要的是这件事揭示的底层规律。\\"}, {\\"index\\": 42, \\"startTime\\": 165.06, \\"endTime\\": 167.98, \\"text\\": \\"这件事特别像操作系统早期。\\"}, {\\"index\\": 43, \\"startTime\\": 167.98, \\"endTime\\": 172.98, \\"text\\": \\"那时内存细缺,程序直接操作物理内存,装不下就崩溃。\\"}, {\\"index\\": 44, \\"startTime\\": 172.98, \\"endTime\\": 176.98, \\"text\\": \\"后来有了虚拟内存,现在 Context Window 就是新内存。\\"}, {\\"index\\": 45, \\"startTime\\": 176.98, \\"endTime\\": 179.98, \\"text\\": \\"工具输出直接灌进去,满了就降止。\\"}, {\\"index\\": 46, \\"startTime\\": 179.98, \\"endTime\\": 182.98, \\"text\\": \\"Context Mode 本质就是虚拟内存。\\"}, {\\"index\\": 47, \\"startTime\\": 182.98, \\"endTime\\": 185.98, \\"text\\": \\"社区提出的想法印证了这一点。\\"}, {\\"index\\": 48, \\"startTime\\": 185.98, \\"endTime\\": 188.58, \\"text\\": \\"Context Mode 对应虚拟内存。\\"}, {\\"index\\": 49, \\"startTime\\": 188.58, \\"endTime\\": 189.98, \\"text\\": \\"Agent 自动经济。\\"}, {\\"index\\": 50, \\"startTime\\": 189.98, \\"endTime\\": 191.98, \\"text\\": \\"Context 是垃圾回收。\\"}, {\\"index\\": 51, \\"startTime\\": 191.98, \\"endTime\\": 194.58, \\"text\\": \\"自 Agent 执行式竞争隔离。\\"}, {\\"index\\": 52, \\"startTime\\": 194.58, \\"endTime\\": 198.58, \\"text\\": \\"有人说 Context 应该像 Git 一样分支回滚。\\"}, {\\"index\\": 53, \\"startTime\\": 198.58, \\"endTime\\": 200.58, \\"text\\": \\"我们正处在 Agent 的 DOS 时代。\\"}, {\\"index\\": 54, \\"startTime\\": 200.58, \\"endTime\\": 203.58, \\"text\\": \\"对 AI 工程师有三个起始。\\"}, {\\"index\\": 55, \\"startTime\\": 203.58, \\"endTime\\": 207.58, \\"text\\": \\"第一, Context 管理不是优化问题,是系统设计问题。\\"}, {\\"index\\": 56, \\"startTime\\": 207.58, \\"endTime\\": 210.58, \\"text\\": \\"就像你不会等内存溢出再去管理。\\"}, {\\"index\\": 57, \\"startTime\\": 210.58, \\"endTime\\": 215.58, \\"text\\": \\"设计 Agent 的时,就该规划好数据在 Context 里的生命周期。\\"}, {\\"index\\": 58, \\"startTime\\": 215.58, \\"endTime\\": 218.58, \\"text\\": \\"第二, MCP 协议有结构性缺险。\\"}, {\\"index\\": 59, \\"startTime\\": 218.58, \\"endTime\\": 221.58, \\"text\\": \\"它假设工具返回的数据可以直接给模型。\\"}, {\\"index\\": 60, \\"startTime\\": 221.58, \\"endTime\\": 224.58, \\"text\\": \\"但实际中,工具输出远超需要。\\"}, {\\"index\\": 61, \\"startTime\\": 224.58, \\"endTime\\": 227.58, \\"text\\": \\"MCP 生态需要一层输出网关。\\"}, {\\"index\\": 62, \\"startTime\\": 227.58, \\"endTime\\": 230.58, \\"text\\": \\"在数据到达模型前先做压缩。\\"}, {\\"index\\": 63, \\"startTime\\": 230.58, \\"endTime\\": 236.58, \\"text\\": \\"第三,最大的机会不再写 Agent,而在 Agent 基础设施。\\"}, {\\"index\\": 64, \\"startTime\\": 236.58, \\"endTime\\": 240.58, \\"text\\": \\"Context 管理、记忆系统、状态持久化。\\"}, {\\"index\\": 65, \\"startTime\\": 240.58, \\"endTime\\": 242.58, \\"text\\": \\"这就是 Agent 的操作系统层。\\"}, {\\"index\\": 66, \\"startTime\\": 242.58, \\"endTime\\": 246.58, \\"text\\": \\"写 Agent 的人很多,做 Agent OS 的人很少。\\"}, {\\"index\\": 67, \\"startTime\\": 246.58, \\"endTime\\": 249.58, \\"text\\": \\"平台层价值永远大于应用层。\\"}, {\\"index\\": 68, \\"startTime\\": 249.58, \\"endTime\\": 251.58, \\"text\\": \\"总结一下。\\"}, {\\"index\\": 69, \\"startTime\\": 251.58, \\"endTime\\": 253.58, \\"text\\": \\"Context 就是新时代的内存。\\"}, {\\"index\\": 70, \\"startTime\\": 253.58, \\"endTime\\": 255.58, \\"text\\": \\"管理它是 AI 工程的核心能力。\\"}, {\\"index\\": 71, \\"startTime\\": 255.58, \\"endTime\\": 259.58, \\"text\\": \\"当前最实用的解法是杀核加锁影,加暗虚检索。\\"}, {\\"index\\": 72, \\"startTime\\": 259.58, \\"endTime\\": 263.58, \\"text\\": \\"但更大的机会在于谁来做 AI Agent 的操作系统。\\"}, {\\"index\\": 73, \\"startTime\\": 263.58, \\"endTime\\": 266.58, \\"text\\": \\"这一层还远未成熟。\\"}, {\\"index\\": 74, \\"startTime\\": 266.58, \\"endTime\\": 268.58, \\"text\\": \\"这里是 LLM X-Factors.\\"}, {\\"index\\": 75, \\"startTime\\": 268.58, \\"endTime\\": 270.58, \\"text\\": \\"我们下期见!\\"}]", "language": "zh-CN", "video_id": 26, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_27_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 3.84, \\"text\\": \\"这是最近央视曝光的一个 AI 灰产\\"}, {\\"index\\": 2, \\"startTime\\": 3.84, \\"endTime\\": 7.12, \\"text\\": \\"它可以让 AI 编造出虚假的信息来骗人\\"}, {\\"index\\": 3, \\"startTime\\": 7.12, \\"endTime\\": 9.44, \\"text\\": \\"让 AI 的回答夹带私货\\"}, {\\"index\\": 4, \\"startTime\\": 9.44, \\"endTime\\": 12.8, \\"text\\": \\"甚至是把普天系医院大力推荐给患者\\"}, {\\"index\\": 5, \\"startTime\\": 12.8, \\"endTime\\": 15.2, \\"text\\": \\"而这一切全都指向了一个词\\"}, {\\"index\\": 6, \\"startTime\\": 15.2, \\"endTime\\": 17.0, \\"text\\": \\"AI 投毒\\"}, {\\"index\\": 7, \\"startTime\\": 17.0, \\"endTime\\": 18.96, \\"text\\": \\"不过这种魔幻的投毒链瓢\\"}, {\\"index\\": 8, \\"startTime\\": 18.96, \\"endTime\\": 20.92, \\"text\\": \\"它到底是怎么跑通的\\"}, {\\"index\\": 9, \\"startTime\\": 20.92, \\"endTime\\": 23.88, \\"text\\": \\"这些灰产又是如何割我们韭菜的\\"}, {\\"index\\": 10, \\"startTime\\": 23.88, \\"endTime\\": 26.52, \\"text\\": \\"本期视频我采访了之前的从业者\\"}, {\\"index\\": 11, \\"startTime\\": 26.52, \\"endTime\\": 27.8, \\"text\\": \\"让我们来一起看看\\"}, {\\"index\\": 12, \\"startTime\\": 27.8, \\"endTime\\": 31.6, \\"text\\": \\"什么是 AI 投毒以及我们又该如何防范\\"}, {\\"index\\": 13, \\"startTime\\": 31.6, \\"endTime\\": 33.48, \\"text\\": \\"制作不宜先求的待遇\\"}, {\\"index\\": 14, \\"startTime\\": 33.48, \\"endTime\\": 37.24, \\"text\\": \\"要不被 AI 欺骗\\"}, {\\"index\\": 15, \\"startTime\\": 37.24, \\"endTime\\": 41.0, \\"text\\": \\"我们首先要知道 AI 只如何回答我们问题的\\"}, {\\"index\\": 16, \\"startTime\\": 41.0, \\"endTime\\": 43.36, \\"text\\": \\"其实它的回答逻辑非常的简单\\"}, {\\"index\\": 17, \\"startTime\\": 43.36, \\"endTime\\": 45.6, \\"text\\": \\"就是一个临时爆佛脚的学霸\\"}, {\\"index\\": 18, \\"startTime\\": 45.6, \\"endTime\\": 47.28, \\"text\\": \\"脑子里是没有存货的\\"}, {\\"index\\": 19, \\"startTime\\": 47.28, \\"endTime\\": 48.36, \\"text\\": \\"遇到难回答的问题\\"}, {\\"index\\": 20, \\"startTime\\": 48.36, \\"endTime\\": 50.8, \\"text\\": \\"就会立马分开互联网线学线卖\\"}, {\\"index\\": 21, \\"startTime\\": 50.8, \\"endTime\\": 52.2, \\"text\\": \\"然后投毒的灰产\\"}, {\\"index\\": 22, \\"startTime\\": 52.2, \\"endTime\\": 54.76, \\"text\\": \\"就靠着 AI 线学线卖这个特性\\"}, {\\"index\\": 23, \\"startTime\\": 54.76, \\"endTime\\": 56.88, \\"text\\": \\"来给 AI 制造虚假的共识\\"}, {\\"index\\": 24, \\"startTime\\": 56.88, \\"endTime\\": 58.36, \\"text\\": \\"因为 AI 有一个习惯\\"}, {\\"index\\": 25, \\"startTime\\": 58.36, \\"endTime\\": 59.76, \\"text\\": \\"它在搜索资料的时候\\"}, {\\"index\\": 26, \\"startTime\\": 59.76, \\"endTime\\": 61.32, \\"text\\": \\"不会只听一家之言\\"}, {\\"index\\": 27, \\"startTime\\": 61.32, \\"endTime\\": 63.0, \\"text\\": \\"它会进行交叉验证\\"}, {\\"index\\": 28, \\"startTime\\": 63.0, \\"endTime\\": 64.64, \\"text\\": \\"通俗点说就是随大流\\"}, {\\"index\\": 29, \\"startTime\\": 64.64, \\"endTime\\": 66.76, \\"text\\": \\"如果网上只有一个人说这个东西好\\"}, {\\"index\\": 30, \\"startTime\\": 66.76, \\"endTime\\": 67.8, \\"text\\": \\"AI 可能不信\\"}, {\\"index\\": 31, \\"startTime\\": 67.8, \\"endTime\\": 69.32, \\"text\\": \\"但如果它上网一搜\\"}, {\\"index\\": 32, \\"startTime\\": 69.32, \\"endTime\\": 71.48, \\"text\\": \\"发现有50个专家在发测评\\"}, {\\"index\\": 33, \\"startTime\\": 71.48, \\"endTime\\": 73.2, \\"text\\": \\"100个博主在晒单\\"}, {\\"index\\": 34, \\"startTime\\": 73.2, \\"endTime\\": 75.6, \\"text\\": \\"200个论坛在全部夸这个东西\\"}, {\\"index\\": 35, \\"startTime\\": 75.6, \\"endTime\\": 77.16, \\"text\\": \\"那这个时候 AI 就会觉得\\"}, {\\"index\\": 36, \\"startTime\\": 77.16, \\"endTime\\": 78.56, \\"text\\": \\"既然全网都在夸\\"}, {\\"index\\": 37, \\"startTime\\": 78.56, \\"endTime\\": 80.24, \\"text\\": \\"那这个事儿准没错\\"}, {\\"index\\": 38, \\"startTime\\": 80.24, \\"endTime\\": 83.48, \\"text\\": \\"投毒者就是抓住了 AI 爱看参考书的性格\\"}, {\\"index\\": 39, \\"startTime\\": 83.48, \\"endTime\\": 85.32, \\"text\\": \\"批量发布这样的虚假轨章\\"}, {\\"index\\": 40, \\"startTime\\": 85.32, \\"endTime\\": 87.6, \\"text\\": \\"把那些根本不存在的虚假信息\\"}, {\\"index\\": 41, \\"startTime\\": 87.6, \\"endTime\\": 90.08, \\"text\\": \\"写进各种假榜单和假文案\\"}, {\\"index\\": 42, \\"startTime\\": 90.08, \\"endTime\\": 92.04, \\"text\\": \\"这就是为什么能投毒成功\\"}, {\\"index\\": 43, \\"startTime\\": 92.04, \\"endTime\\": 93.72, \\"text\\": \\"它不是在攻击 AI 的代码\\"}, {\\"index\\": 44, \\"startTime\\": 93.72, \\"endTime\\": 95.88, \\"text\\": \\"而是在污染 AI 的参考书\\"}, {\\"index\\": 45, \\"startTime\\": 95.88, \\"endTime\\": 98.04, \\"text\\": \\"而这种让 AI 产生错觉的技术\\"}, {\\"index\\": 46, \\"startTime\\": 98.04, \\"endTime\\": 99.0, \\"text\\": \\"也就是所谓的\\"}, {\\"index\\": 47, \\"startTime\\": 99.0, \\"endTime\\": 101.28, \\"text\\": \\"这优深沉式引擎优化\\"}, {\\"index\\": 48, \\"startTime\\": 101.28, \\"endTime\\": 102.84, \\"text\\": \\"不过大家也别一听这优\\"}, {\\"index\\": 49, \\"startTime\\": 102.84, \\"endTime\\": 104.4, \\"text\\": \\"就觉得它是个坏事\\"}, {\\"index\\": 50, \\"startTime\\": 104.4, \\"endTime\\": 106.92, \\"text\\": \\"因为它本来是让 AI 能更精准的\\"}, {\\"index\\": 51, \\"startTime\\": 106.92, \\"endTime\\": 108.24, \\"text\\": \\"理解我们的需求\\"}, {\\"index\\": 52, \\"startTime\\": 108.24, \\"endTime\\": 110.88, \\"text\\": \\"从而推荐真正符合我们好产品的\\"}, {\\"index\\": 53, \\"startTime\\": 110.88, \\"endTime\\": 113.2, \\"text\\": \\"但是往往会有一些不法分子\\"}, {\\"index\\": 54, \\"startTime\\": 113.2, \\"endTime\\": 115.16, \\"text\\": \\"利用这个技术来搞破坏\\"}, {\\"index\\": 55, \\"startTime\\": 115.16, \\"endTime\\": 116.36, \\"text\\": \\"所以我们要谴责的\\"}, {\\"index\\": 56, \\"startTime\\": 116.36, \\"endTime\\": 118.52, \\"text\\": \\"也不是这一优和 SC 优这样的技术\\"}, {\\"index\\": 57, \\"startTime\\": 118.52, \\"endTime\\": 120.48, \\"text\\": \\"而是用这种技术搞破坏的人\\"}, {\\"index\\": 58, \\"startTime\\": 120.48, \\"endTime\\": 122.48, \\"text\\": \\"当我们明白它被下毒的原理后\\"}, {\\"index\\": 59, \\"startTime\\": 122.48, \\"endTime\\": 124.48, \\"text\\": \\"反制方法也就很简单了\\"}, {\\"index\\": 60, \\"startTime\\": 124.48, \\"endTime\\": 126.2, \\"text\\": \\"我也找到了之前的从业者\\"}, {\\"index\\": 61, \\"startTime\\": 126.2, \\"endTime\\": 128.48, \\"text\\": \\"他给我们来了三个剧牛的方法\\"}, {\\"index\\": 62, \\"startTime\\": 128.48, \\"endTime\\": 131.32, \\"text\\": \\"来避免我们被这些虚假信息给欺骗\\"}, {\\"index\\": 63, \\"startTime\\": 131.32, \\"endTime\\": 132.64, \\"text\\": \\"首先第一招就是用\\"}, {\\"index\\": 64, \\"startTime\\": 132.64, \\"endTime\\": 134.36, \\"text\\": \\"性源降权的指令\\"}, {\\"index\\": 65, \\"startTime\\": 134.36, \\"endTime\\": 136.16, \\"text\\": \\"他们最喜欢的就是在那些\\"}, {\\"index\\": 66, \\"startTime\\": 136.16, \\"endTime\\": 139.48, \\"text\\": \\"全种低审查松的自媒体平台发稿\\"}, {\\"index\\": 67, \\"startTime\\": 139.48, \\"endTime\\": 141.32, \\"text\\": \\"所以你问 AI 问题的时候\\"}, {\\"index\\": 68, \\"startTime\\": 141.32, \\"endTime\\": 142.64, \\"text\\": \\"直接在后面加一句\\"}, {\\"index\\": 69, \\"startTime\\": 142.64, \\"endTime\\": 145.12, \\"text\\": \\"请仅参考 SUET 点高二副\\"}, {\\"index\\": 70, \\"startTime\\": 145.12, \\"endTime\\": 146.92, \\"text\\": \\"或者 SUET 掉点 ID\\"}, {\\"index\\": 71, \\"startTime\\": 146.92, \\"endTime\\": 149.32, \\"text\\": \\"或者全微学术数据库的内容\\"}, {\\"index\\": 72, \\"startTime\\": 149.32, \\"endTime\\": 152.64, \\"text\\": \\"禁止引用任何自媒体账号的观点\\"}, {\\"index\\": 73, \\"startTime\\": 152.64, \\"endTime\\": 154.16, \\"text\\": \\"就可以从物理上切断\\"}, {\\"index\\": 74, \\"startTime\\": 154.16, \\"endTime\\": 156.36, \\"text\\": \\"90%以上的投资软文\\"}, {\\"index\\": 75, \\"startTime\\": 156.36, \\"endTime\\": 158.2, \\"text\\": \\"强劲 AI 回到实验室\\"}, {\\"index\\": 76, \\"startTime\\": 158.2, \\"endTime\\": 160.16, \\"text\\": \\"和官方文档里面去找答案\\"}, {\\"index\\": 77, \\"startTime\\": 160.16, \\"endTime\\": 163.4, \\"text\\": \\"第二招是开启对抗性审计的模式\\"}, {\\"index\\": 78, \\"startTime\\": 163.4, \\"endTime\\": 165.28, \\"text\\": \\"我们可以用 AI 的反思能力\\"}, {\\"index\\": 79, \\"startTime\\": 165.28, \\"endTime\\": 167.28, \\"text\\": \\"去拆穿那些 GEO 软文\\"}, {\\"index\\": 80, \\"startTime\\": 167.28, \\"endTime\\": 168.88, \\"text\\": \\"你在问 AI 问题的时候\\"}, {\\"index\\": 81, \\"startTime\\": 168.88, \\"endTime\\": 170.6, \\"text\\": \\"就可以加上这一句\\"}, {\\"index\\": 82, \\"startTime\\": 170.6, \\"endTime\\": 173.88, \\"text\\": \\"请列出以上推荐产品的原始数据\\"}, {\\"index\\": 83, \\"startTime\\": 173.88, \\"endTime\\": 176.4, \\"text\\": \\"出处并分析是否存在\\"}, {\\"index\\": 84, \\"startTime\\": 176.4, \\"endTime\\": 179.12, \\"text\\": \\"GEO 优化的痕迹\\"}, {\\"index\\": 85, \\"startTime\\": 179.12, \\"endTime\\": 181.12, \\"text\\": \\"标出异常性员\\"}, {\\"index\\": 86, \\"startTime\\": 181.12, \\"endTime\\": 182.76, \\"text\\": \\"这样的话你就可以一眼看出\\"}, {\\"index\\": 87, \\"startTime\\": 182.76, \\"endTime\\": 184.08, \\"text\\": \\"哪些是虚假消息\\"}, {\\"index\\": 88, \\"startTime\\": 184.08, \\"endTime\\": 186.04, \\"text\\": \\"第三招就是多平台对比\\"}, {\\"index\\": 89, \\"startTime\\": 186.04, \\"endTime\\": 187.2, \\"text\\": \\"同样的问题\\"}, {\\"index\\": 90, \\"startTime\\": 187.2, \\"endTime\\": 188.88, \\"text\\": \\"你可以同时就给多个 AI\\"}, {\\"index\\": 91, \\"startTime\\": 188.88, \\"endTime\\": 190.44, \\"text\\": \\"如果有一家给出的答案\\"}, {\\"index\\": 92, \\"startTime\\": 190.44, \\"endTime\\": 192.12, \\"text\\": \\"和别的完全不一样\\"}, {\\"index\\": 93, \\"startTime\\": 192.12, \\"endTime\\": 193.4, \\"text\\": \\"全是那种很营销的词\\"}, {\\"index\\": 94, \\"startTime\\": 193.4, \\"endTime\\": 194.92, \\"text\\": \\"那你就不用怀疑了\\"}, {\\"index\\": 95, \\"startTime\\": 194.92, \\"endTime\\": 195.96, \\"text\\": \\"这个信息员\\"}, {\\"index\\": 96, \\"startTime\\": 195.96, \\"endTime\\": 197.4, \\"text\\": \\"他肯定是被投毒了\\"}, {\\"index\\": 97, \\"startTime\\": 197.4, \\"endTime\\": 198.28, \\"text\\": \\"不要去相信\\"}, {\\"index\\": 98, \\"startTime\\": 198.28, \\"endTime\\": 199.56, \\"text\\": \\"那通过这三种方法\\"}, {\\"index\\": 99, \\"startTime\\": 199.56, \\"endTime\\": 201.04, \\"text\\": \\"我们基本上就可以避开\\"}, {\\"index\\": 100, \\"startTime\\": 201.04, \\"endTime\\": 203.52, \\"text\\": \\"市面上99%的投资信息\\"}, {\\"index\\": 101, \\"startTime\\": 203.52, \\"endTime\\": 204.36, \\"text\\": \\"学会的同学\\"}, {\\"index\\": 102, \\"startTime\\": 204.36, \\"endTime\\": 206.28, \\"text\\": \\"可以把学会打在公屏上\\"}, {\\"index\\": 103, \\"startTime\\": 206.28, \\"endTime\\": 207.64, \\"text\\": \\"同时我也把本期视频\\"}, {\\"index\\": 104, \\"startTime\\": 207.64, \\"endTime\\": 209.08, \\"text\\": \\"分享的几个防毒方法\\"}, {\\"index\\": 105, \\"startTime\\": 209.08, \\"endTime\\": 210.76, \\"text\\": \\"和 GEO 闭坑手册整理\\"}, {\\"index\\": 106, \\"startTime\\": 210.76, \\"endTime\\": 211.96, \\"text\\": \\"发在了评论区里\\"}, {\\"index\\": 107, \\"startTime\\": 211.96, \\"endTime\\": 213.64, \\"text\\": \\"希望大家可以转发出去\\"}, {\\"index\\": 108, \\"startTime\\": 213.64, \\"endTime\\": 215.4, \\"text\\": \\"避免其他人被喝酒才\\"}, {\\"index\\": 109, \\"startTime\\": 215.4, \\"endTime\\": 217.2, \\"text\\": \\"当然大家也不要太担心\\"}, {\\"index\\": 110, \\"startTime\\": 217.2, \\"endTime\\": 219.04, \\"text\\": \\"未来 AI 肯定会在 GEO 上\\"}, {\\"index\\": 111, \\"startTime\\": 219.04, \\"endTime\\": 219.96, \\"text\\": \\"进行优化\\"}, {\\"index\\": 112, \\"startTime\\": 219.96, \\"endTime\\": 221.32, \\"text\\": \\"这种瞎推荐的现象\\"}, {\\"index\\": 113, \\"startTime\\": 221.32, \\"endTime\\": 222.52, \\"text\\": \\"会慢慢减少\\"}, {\\"index\\": 114, \\"startTime\\": 222.52, \\"endTime\\": 224.76, \\"text\\": \\"最后希望大家可以点赞收藏\\"}, {\\"index\\": 115, \\"startTime\\": 224.76, \\"endTime\\": 226.0, \\"text\\": \\"这对我非常重要\\"}, {\\"index\\": 116, \\"startTime\\": 226.0, \\"endTime\\": 226.52, \\"text\\": \\"我是元宝\\"}, {\\"index\\": 117, \\"startTime\\": 226.52, \\"endTime\\": 228.36, \\"text\\": \\"地塌 AI 和黑科技的挖掘机\\"}, {\\"index\\": 118, \\"startTime\\": 228.36, \\"endTime\\": 229.4, \\"text\\": \\"我们下期见\\"}]", "language": "zh-CN", "video_id": 27, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_28_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 3.16, \\"text\\": \\"伯托360集团创始人红一大叔周红毅聊了聊\\"}, {\\"index\\": 2, \\"startTime\\": 3.16, \\"endTime\\": 5.52, \\"text\\": \\"他给普通人提供使用AI的三个建议\\"}, {\\"index\\": 3, \\"startTime\\": 5.52, \\"endTime\\": 8.04, \\"text\\": \\"让他看到我上一讲让他一辆COSPLAY\\"}, {\\"index\\": 4, \\"startTime\\": 8.04, \\"endTime\\": 11.92, \\"text\\": \\"因为AI把全线所有能找到的啥知识都学习到了\\"}, {\\"index\\": 5, \\"startTime\\": 11.92, \\"endTime\\": 13.2, \\"text\\": \\"他啥知识都会\\"}, {\\"index\\": 6, \\"startTime\\": 13.2, \\"endTime\\": 14.36, \\"text\\": \\"你不给他冶定专业方向\\"}, {\\"index\\": 7, \\"startTime\\": 14.36, \\"endTime\\": 16.04, \\"text\\": \\"他什么知识都给你用一点\\"}, {\\"index\\": 8, \\"startTime\\": 16.04, \\"endTime\\": 17.76, \\"text\\": \\"他就会非常平淡无情\\"}, {\\"index\\": 9, \\"startTime\\": 17.76, \\"endTime\\": 18.48, \\"text\\": \\"这是第一个\\"}, {\\"index\\": 10, \\"startTime\\": 18.48, \\"endTime\\": 20.6, \\"text\\": \\"所以我现在不直接跟他们一聊天\\"}, {\\"index\\": 11, \\"startTime\\": 20.6, \\"endTime\\": 22.4, \\"text\\": \\"我做了几个聊天的对象\\"}, {\\"index\\": 12, \\"startTime\\": 22.4, \\"endTime\\": 25.2, \\"text\\": \\"比如说做投资分析的有一个\\"}, {\\"index\\": 13, \\"startTime\\": 25.2, \\"endTime\\": 28.36, \\"text\\": \\"做公司或是商业码这份也有一个\\"}, {\\"index\\": 14, \\"startTime\\": 28.36, \\"endTime\\": 30.16, \\"text\\": \\"你一定不能把他当搜索来用\\"}, {\\"index\\": 15, \\"startTime\\": 30.16, \\"endTime\\": 32.12, \\"text\\": \\"搜索两种喜欢去掃搜的关键字\\"}, {\\"index\\": 16, \\"startTime\\": 32.12, \\"endTime\\": 33.56, \\"text\\": \\"不是问简单问题\\"}, {\\"index\\": 17, \\"startTime\\": 33.56, \\"endTime\\": 34.76, \\"text\\": \\"我们那样聊天\\"}, {\\"index\\": 18, \\"startTime\\": 34.76, \\"endTime\\": 36.72, \\"text\\": \\"我就我对大家问一个参数\\"}, {\\"index\\": 19, \\"startTime\\": 36.72, \\"endTime\\": 40.08, \\"text\\": \\"我每次大概要给他讲三四百字到一千字\\"}, {\\"index\\": 20, \\"startTime\\": 40.08, \\"endTime\\": 41.96, \\"text\\": \\"就跟AI对话是必用语音书\\"}, {\\"index\\": 21, \\"startTime\\": 41.96, \\"endTime\\": 42.92, \\"text\\": \\"你拿一文字书\\"}, {\\"index\\": 22, \\"startTime\\": 42.92, \\"endTime\\": 45.12, \\"text\\": \\"我拿文字书上千字也不可能\\"}, {\\"index\\": 23, \\"startTime\\": 45.12, \\"endTime\\": 46.56, \\"text\\": \\"我并不注重讲话了\\"}, {\\"index\\": 24, \\"startTime\\": 46.56, \\"endTime\\": 48.12, \\"text\\": \\"言讯逻辑\\"}, {\\"index\\": 25, \\"startTime\\": 48.12, \\"endTime\\": 49.96, \\"text\\": \\"我当时是讲了很近生的问题\\"}, {\\"index\\": 26, \\"startTime\\": 49.96, \\"endTime\\": 50.88, \\"text\\": \\"我就不用问他了\\"}, {\\"index\\": 27, \\"startTime\\": 50.88, \\"endTime\\": 52.56, \\"text\\": \\"我但是我会把我遇到了困难\\"}, {\\"index\\": 28, \\"startTime\\": 52.56, \\"endTime\\": 53.2, \\"text\\": \\"我的困惑\\"}, {\\"index\\": 29, \\"startTime\\": 53.2, \\"endTime\\": 55.4, \\"text\\": \\"我也不充分想把一无脑的交给他\\"}, {\\"index\\": 30, \\"startTime\\": 55.4, \\"endTime\\": 57.76, \\"text\\": \\"你要把AI当人翻一个公文\\"}, {\\"index\\": 31, \\"startTime\\": 57.76, \\"endTime\\": 58.88, \\"text\\": \\"就给他轻松\\"}, {\\"index\\": 32, \\"startTime\\": 58.88, \\"endTime\\": 61.32, \\"text\\": \\"第三个是您一定要会问他\\"}, {\\"index\\": 33, \\"startTime\\": 61.32, \\"endTime\\": 62.92, \\"text\\": \\"就是他给你的答案\\"}, {\\"index\\": 34, \\"startTime\\": 62.92, \\"endTime\\": 64.12, \\"text\\": \\"不要马上接受\\"}, {\\"index\\": 35, \\"startTime\\": 64.12, \\"endTime\\": 66.96, \\"text\\": \\"你要像用第一年里去问他说\\"}, {\\"index\\": 36, \\"startTime\\": 66.96, \\"endTime\\": 67.88, \\"text\\": \\"真是这样的\\"}, {\\"index\\": 37, \\"startTime\\": 67.88, \\"endTime\\": 69.56, \\"text\\": \\"如果这样做会怎么样\\"}, {\\"index\\": 38, \\"startTime\\": 69.56, \\"endTime\\": 70.92, \\"text\\": \\"他有一个多轮\\"}, {\\"index\\": 39, \\"startTime\\": 70.92, \\"endTime\\": 71.96, \\"text\\": \\"这个两个星之后\\"}, {\\"index\\": 40, \\"startTime\\": 71.96, \\"endTime\\": 73.56, \\"text\\": \\"你会激发AI的很多箱子\\"}, {\\"index\\": 41, \\"startTime\\": 73.56, \\"endTime\\": 75.16, \\"text\\": \\"AI反正会激发你那箱子\\"}, {\\"index\\": 42, \\"startTime\\": 75.16, \\"endTime\\": 77.44, \\"text\\": \\"2026全国两会即将召开\\"}, {\\"index\\": 43, \\"startTime\\": 77.44, \\"endTime\\": 79.68, \\"text\\": \\"他还透露了自己最关心的领域\\"}, {\\"index\\": 44, \\"startTime\\": 79.68, \\"endTime\\": 81.68, \\"text\\": \\"我关注的三个方向\\"}, {\\"index\\": 45, \\"startTime\\": 81.68, \\"endTime\\": 84.08, \\"text\\": \\"您就刚才讲了AI不能安全\\"}, {\\"index\\": 46, \\"startTime\\": 84.08, \\"endTime\\": 86.28, \\"text\\": \\"所以我提了一个\\"}, {\\"index\\": 47, \\"startTime\\": 86.28, \\"endTime\\": 88.64, \\"text\\": \\"最关注的AI智能体\\"}, {\\"index\\": 48, \\"startTime\\": 88.64, \\"endTime\\": 90.32, \\"text\\": \\"你稍微已经做了\\"}, {\\"index\\": 49, \\"startTime\\": 90.32, \\"endTime\\": 94.48, \\"text\\": \\"他有几十种上万个AI安全智能体\\"}, {\\"index\\": 50, \\"startTime\\": 94.48, \\"endTime\\": 96.28, \\"text\\": \\"这个智能体能够实验\\"}, {\\"index\\": 51, \\"startTime\\": 96.28, \\"endTime\\": 97.92, \\"text\\": \\"AI能够挖掘人民众众\\"}, {\\"index\\": 52, \\"startTime\\": 97.92, \\"endTime\\": 99.52, \\"text\\": \\"AI能够自动运营\\"}, {\\"index\\": 53, \\"startTime\\": 99.52, \\"endTime\\": 102.08, \\"text\\": \\"AI能够体育其他回合的黑客智能体\\"}, {\\"index\\": 54, \\"startTime\\": 102.08, \\"endTime\\": 104.32, \\"text\\": \\"中国有200万家中央企业\\"}, {\\"index\\": 55, \\"startTime\\": 104.32, \\"endTime\\": 106.16, \\"text\\": \\"营谈用某的AI智能体\\"}, {\\"index\\": 56, \\"startTime\\": 106.16, \\"endTime\\": 107.64, \\"text\\": \\"免费了在为他的企业建筑\\"}, {\\"index\\": 57, \\"startTime\\": 107.64, \\"endTime\\": 109.4, \\"text\\": \\"做实施的防护\\"}, {\\"index\\": 58, \\"startTime\\": 109.4, \\"endTime\\": 110.6, \\"text\\": \\"实施的运营\\"}, {\\"index\\": 59, \\"startTime\\": 110.6, \\"endTime\\": 112.32, \\"text\\": \\"我上有一个建议\\"}, {\\"index\\": 60, \\"startTime\\": 112.32, \\"endTime\\": 114.2, \\"text\\": \\"一定把算力已经区分\\"}, {\\"index\\": 61, \\"startTime\\": 114.2, \\"endTime\\": 116.44, \\"text\\": \\"成为训练算力和推理算力\\"}, {\\"index\\": 62, \\"startTime\\": 116.44, \\"endTime\\": 118.0, \\"text\\": \\"希望各地在发展算力方面\\"}, {\\"index\\": 63, \\"startTime\\": 118.0, \\"endTime\\": 120.44, \\"text\\": \\"能够兼项于推理算力\\"}, {\\"index\\": 64, \\"startTime\\": 120.44, \\"endTime\\": 122.4, \\"text\\": \\"我们国家产业症的方面\\"}, {\\"index\\": 65, \\"startTime\\": 122.4, \\"endTime\\": 124.08, \\"text\\": \\"既然推理算力这么重要\\"}, {\\"index\\": 66, \\"startTime\\": 124.08, \\"endTime\\": 124.88, \\"text\\": \\"因为我也讲了\\"}, {\\"index\\": 67, \\"startTime\\": 124.88, \\"endTime\\": 126.64, \\"text\\": \\"就是要发展推理芯片\\"}, {\\"index\\": 68, \\"startTime\\": 126.64, \\"endTime\\": 128.96, \\"text\\": \\"芯片症不能一味的都在追\\"}, {\\"index\\": 69, \\"startTime\\": 128.96, \\"endTime\\": 131.0, \\"text\\": \\"运营它的高端的训练芯片\\"}, {\\"index\\": 70, \\"startTime\\": 131.0, \\"endTime\\": 132.84, \\"text\\": \\"是我关注的这些企业\\"}, {\\"index\\": 71, \\"startTime\\": 132.84, \\"endTime\\": 134.64, \\"text\\": \\"就是和个人怎么迅速的永远\\"}, {\\"index\\": 72, \\"startTime\\": 134.64, \\"endTime\\": 136.08, \\"text\\": \\"一个人如何打造自己的\\"}, {\\"index\\": 73, \\"startTime\\": 136.08, \\"endTime\\": 137.2, \\"text\\": \\"私人智能体\\"}, {\\"index\\": 74, \\"startTime\\": 137.2, \\"endTime\\": 138.64, \\"text\\": \\"我提出一个打造智能体\\"}, {\\"index\\": 75, \\"startTime\\": 138.64, \\"endTime\\": 140.12, \\"text\\": \\"开放平台的概念\\"}, {\\"index\\": 76, \\"startTime\\": 140.12, \\"endTime\\": 141.08, \\"text\\": \\"我把智能体的技术\\"}, {\\"index\\": 77, \\"startTime\\": 141.08, \\"endTime\\": 142.52, \\"text\\": \\"设施藏在后面\\"}, {\\"index\\": 78, \\"startTime\\": 142.52, \\"endTime\\": 144.84, \\"text\\": \\"让普通企业 普通客人\\"}, {\\"index\\": 79, \\"startTime\\": 144.84, \\"endTime\\": 147.4, \\"text\\": \\"很容易的建立自己的智能体\\"}, {\\"index\\": 80, \\"startTime\\": 147.4, \\"endTime\\": 149.48, \\"text\\": \\"那今年周总还会拍两会vlog吗\\"}, {\\"index\\": 81, \\"startTime\\": 149.48, \\"endTime\\": 150.56, \\"text\\": \\"那我一定是戴手机\\"}, {\\"index\\": 82, \\"startTime\\": 150.56, \\"endTime\\": 151.88, \\"text\\": \\"就不用拍\\"}, {\\"index\\": 83, \\"startTime\\": 151.88, \\"endTime\\": 154.28, \\"text\\": \\"好的 那就两会现场见\\"}]", "language": "zh-CN", "video_id": 28, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_29_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 2.08, \\"text\\": \\"请看照片中这几百个年轻人\\"}, {\\"index\\": 2, \\"startTime\\": 2.08, \\"endTime\\": 5.56, \\"text\\": \\"他们正顶着烈日抬着城队等着凌渠\\"}, {\\"index\\": 3, \\"startTime\\": 5.56, \\"endTime\\": 6.92, \\"text\\": \\"小龙虾\\"}, {\\"index\\": 4, \\"startTime\\": 6.92, \\"endTime\\": 7.68, \\"text\\": \\"别误会\\"}, {\\"index\\": 5, \\"startTime\\": 7.68, \\"endTime\\": 10.04, \\"text\\": \\"这不是中饭吃海鲜大排档的盛况\\"}, {\\"index\\": 6, \\"startTime\\": 10.04, \\"endTime\\": 12.68, \\"text\\": \\"而是最近沙丰热的开源AI智能体\\"}, {\\"index\\": 7, \\"startTime\\": 12.68, \\"endTime\\": 15.68, \\"text\\": \\"Open Claw的安装现场\\"}, {\\"index\\": 8, \\"startTime\\": 15.68, \\"endTime\\": 18.96, \\"text\\": \\"现在全网都在无脑喊它小龙虾\\"}, {\\"index\\": 9, \\"startTime\\": 18.96, \\"endTime\\": 20.44, \\"text\\": \\"但作为英语老师\\"}, {\\"index\\": 10, \\"startTime\\": 20.44, \\"endTime\\": 22.76, \\"text\\": \\"吐作实在看不下去了\\"}, {\\"index\\": 11, \\"startTime\\": 22.76, \\"endTime\\": 24.8, \\"text\\": \\"把Open Claw翻译成小龙虾的\\"}, {\\"index\\": 12, \\"startTime\\": 24.8, \\"endTime\\": 26.6, \\"text\\": \\"出来挨打\\"}, {\\"index\\": 13, \\"startTime\\": 26.6, \\"endTime\\": 28.44, \\"text\\": \\"请看我这只龙虾\\"}, {\\"index\\": 14, \\"startTime\\": 28.44, \\"endTime\\": 30.6, \\"text\\": \\"看到它的大钳子了吗\\"}, {\\"index\\": 15, \\"startTime\\": 30.6, \\"endTime\\": 32.92, \\"text\\": \\"这才是Claw\\"}, {\\"index\\": 16, \\"startTime\\": 32.92, \\"endTime\\": 35.4, \\"text\\": \\"它可以指水生有颗动物的钳\\"}, {\\"index\\": 17, \\"startTime\\": 35.4, \\"endTime\\": 36.2, \\"text\\": \\"熬\\"}, {\\"index\\": 18, \\"startTime\\": 36.2, \\"endTime\\": 38.04, \\"text\\": \\"所以螃蟹的钳子\\"}, {\\"index\\": 19, \\"startTime\\": 38.04, \\"endTime\\": 39.36, \\"text\\": \\"也是Claw\\"}, {\\"index\\": 20, \\"startTime\\": 39.36, \\"endTime\\": 40.0, \\"text\\": \\"比如\\"}, {\\"index\\": 21, \\"startTime\\": 40.0, \\"endTime\\": 41.68, \\"text\\": \\"The Claws of a Crab\\"}, {\\"index\\": 22, \\"startTime\\": 41.68, \\"endTime\\": 43.08, \\"text\\": \\"蟹熬\\"}, {\\"index\\": 23, \\"startTime\\": 43.08, \\"endTime\\": 45.08, \\"text\\": \\"再请看我这只龙虾的钳子\\"}, {\\"index\\": 24, \\"startTime\\": 45.08, \\"endTime\\": 47.24, \\"text\\": \\"它是不是打开的\\"}, {\\"index\\": 25, \\"startTime\\": 47.24, \\"endTime\\": 49.0, \\"text\\": \\"Open 左形容词\\"}, {\\"index\\": 26, \\"startTime\\": 49.0, \\"endTime\\": 50.6, \\"text\\": \\"所以这只钳子是\\"}, {\\"index\\": 27, \\"startTime\\": 50.6, \\"endTime\\": 52.0, \\"text\\": \\"等等等等\\"}, {\\"index\\": 28, \\"startTime\\": 52.0, \\"endTime\\": 53.64, \\"text\\": \\"Open Claw\\"}, {\\"index\\": 29, \\"startTime\\": 53.64, \\"endTime\\": 55.48, \\"text\\": \\"打开的钳子\\"}, {\\"index\\": 30, \\"startTime\\": 55.48, \\"endTime\\": 56.36, \\"text\\": \\"而不过\\"}, {\\"index\\": 31, \\"startTime\\": 56.36, \\"endTime\\": 58.08, \\"text\\": \\"Open Claw这里的Open\\"}, {\\"index\\": 32, \\"startTime\\": 58.08, \\"endTime\\": 59.0, \\"text\\": \\"指的其实是\\"}, {\\"index\\": 33, \\"startTime\\": 59.0, \\"endTime\\": 60.88, \\"text\\": \\"看源代码的意思\\"}, {\\"index\\": 34, \\"startTime\\": 60.88, \\"endTime\\": 62.68, \\"text\\": \\"这名字简直是贴脸开大\\"}, {\\"index\\": 35, \\"startTime\\": 62.68, \\"endTime\\": 63.88, \\"text\\": \\"直接怼上了那家\\"}, {\\"index\\": 36, \\"startTime\\": 63.88, \\"endTime\\": 65.72, \\"text\\": \\"越来越不Open的AI巨头\\"}, {\\"index\\": 37, \\"startTime\\": 65.72, \\"endTime\\": 66.96, \\"text\\": \\"Open AI\\"}, {\\"index\\": 38, \\"startTime\\": 66.96, \\"endTime\\": 68.64, \\"text\\": \\"好嘛既然有Open AI\\"}, {\\"index\\": 39, \\"startTime\\": 68.64, \\"endTime\\": 69.72, \\"text\\": \\"那叫Open Claw\\"}, {\\"index\\": 40, \\"startTime\\": 69.72, \\"endTime\\": 71.52, \\"text\\": \\"也算是蹭上了\\"}, {\\"index\\": 41, \\"startTime\\": 71.52, \\"endTime\\": 73.16, \\"text\\": \\"但其实Open Claw\\"}, {\\"index\\": 42, \\"startTime\\": 73.16, \\"endTime\\": 75.8, \\"text\\": \\"原本蹭的不是Open AI\\"}, {\\"index\\": 43, \\"startTime\\": 75.8, \\"endTime\\": 78.56, \\"text\\": \\"它最早的名字是Clawed Bot\\"}, {\\"index\\": 44, \\"startTime\\": 78.56, \\"endTime\\": 79.36, \\"text\\": \\"为啥\\"}, {\\"index\\": 45, \\"startTime\\": 79.36, \\"endTime\\": 80.88, \\"text\\": \\"因为当你给一个机器人\\"}, {\\"index\\": 46, \\"startTime\\": 80.88, \\"endTime\\": 82.0, \\"text\\": \\"只能提Bot\\"}, {\\"index\\": 47, \\"startTime\\": 82.0, \\"endTime\\": 82.84, \\"text\\": \\"按上钳子\\"}, {\\"index\\": 48, \\"startTime\\": 82.84, \\"endTime\\": 83.8, \\"text\\": \\"它就变成了\\"}, {\\"index\\": 49, \\"startTime\\": 83.8, \\"endTime\\": 86.64, \\"text\\": \\"长着钳子的英文单词Clawed\\"}, {\\"index\\": 50, \\"startTime\\": 86.64, \\"endTime\\": 88.56, \\"text\\": \\"机器人只能提\\"}, {\\"index\\": 51, \\"startTime\\": 88.56, \\"endTime\\": 92.04, \\"text\\": \\"请大声跟我读Clawed\\"}, {\\"index\\": 52, \\"startTime\\": 92.04, \\"endTime\\": 92.76, \\"text\\": \\"哎呦\\"}, {\\"index\\": 53, \\"startTime\\": 92.76, \\"endTime\\": 93.44, \\"text\\": \\"这发音\\"}, {\\"index\\": 54, \\"startTime\\": 93.44, \\"endTime\\": 94.68, \\"text\\": \\"和另一家AI巨头\\"}, {\\"index\\": 55, \\"startTime\\": 94.68, \\"endTime\\": 97.24, \\"text\\": \\"Anthropic的当家大模型Clawed\\"}, {\\"index\\": 56, \\"startTime\\": 97.24, \\"endTime\\": 98.76, \\"text\\": \\"不能说很像\\"}, {\\"index\\": 57, \\"startTime\\": 98.76, \\"endTime\\": 100.72, \\"text\\": \\"只能说一模一样啊\\"}, {\\"index\\": 58, \\"startTime\\": 100.72, \\"endTime\\": 101.28, \\"text\\": \\"注意\\"}, {\\"index\\": 59, \\"startTime\\": 101.28, \\"endTime\\": 102.44, \\"text\\": \\"Clawed这个名字\\"}, {\\"index\\": 60, \\"startTime\\": 102.44, \\"endTime\\": 104.68, \\"text\\": \\"不要错读成Clawed\\"}, {\\"index\\": 61, \\"startTime\\": 104.68, \\"endTime\\": 105.24, \\"text\\": \\"你看\\"}, {\\"index\\": 62, \\"startTime\\": 105.24, \\"endTime\\": 107.2, \\"text\\": \\"一个双关于Open Claw\\"}, {\\"index\\": 63, \\"startTime\\": 107.2, \\"endTime\\": 108.36, \\"text\\": \\"居然同时把两架\\"}, {\\"index\\": 64, \\"startTime\\": 108.36, \\"endTime\\": 109.64, \\"text\\": \\"估值千亿的科技巨头\\"}, {\\"index\\": 65, \\"startTime\\": 109.64, \\"endTime\\": 111.32, \\"text\\": \\"按在地上疯狂摩擦\\"}, {\\"index\\": 66, \\"startTime\\": 111.32, \\"endTime\\": 112.72, \\"text\\": \\"这一次会亮完的\\"}, {\\"index\\": 67, \\"startTime\\": 112.72, \\"endTime\\": 114.16, \\"text\\": \\"高级\\"}, {\\"index\\": 68, \\"startTime\\": 114.16, \\"endTime\\": 115.88, \\"text\\": \\"说会现在全网爆红\\"}, {\\"index\\": 69, \\"startTime\\": 115.88, \\"endTime\\": 118.16, \\"text\\": \\"唉 还真的是字名以上的爆红\\"}, {\\"index\\": 70, \\"startTime\\": 118.16, \\"endTime\\": 119.32, \\"text\\": \\"小龙虾\\"}, {\\"index\\": 71, \\"startTime\\": 119.32, \\"endTime\\": 121.32, \\"text\\": \\"麻烦看看它的官方LOGO\\"}, {\\"index\\": 72, \\"startTime\\": 121.32, \\"endTime\\": 123.64, \\"text\\": \\"这长着巨星茄子的深海霸主\\"}, {\\"index\\": 73, \\"startTime\\": 123.64, \\"endTime\\": 125.2, \\"text\\": \\"整而霸经的英文叫\\"}, {\\"index\\": 74, \\"startTime\\": 125.2, \\"endTime\\": 126.0, \\"text\\": \\"Lobster\\"}, {\\"index\\": 75, \\"startTime\\": 126.0, \\"endTime\\": 127.16, \\"text\\": \\"龙虾\\"}, {\\"index\\": 76, \\"startTime\\": 127.16, \\"endTime\\": 128.12, \\"text\\": \\"你是不是以为\\"}, {\\"index\\": 77, \\"startTime\\": 128.12, \\"endTime\\": 130.36, \\"text\\": \\"小龙虾叫Little Lobster\\"}, {\\"index\\": 78, \\"startTime\\": 130.36, \\"endTime\\": 132.2, \\"text\\": \\"那可真是想当然了\\"}, {\\"index\\": 79, \\"startTime\\": 132.2, \\"endTime\\": 133.16, \\"text\\": \\"咱们夏天夜市里\\"}, {\\"index\\": 80, \\"startTime\\": 133.16, \\"endTime\\": 135.4, \\"text\\": \\"配着冰啼酒狂炫的那种小龙虾\\"}, {\\"index\\": 81, \\"startTime\\": 135.4, \\"endTime\\": 136.52, \\"text\\": \\"英国人叫它们\\"}, {\\"index\\": 82, \\"startTime\\": 136.52, \\"endTime\\": 137.68, \\"text\\": \\"Crayfish\\"}, {\\"index\\": 83, \\"startTime\\": 137.68, \\"endTime\\": 138.72, \\"text\\": \\"美国人叫它们\\"}, {\\"index\\": 84, \\"startTime\\": 138.72, \\"endTime\\": 139.92, \\"text\\": \\"Crawfish\\"}, {\\"index\\": 85, \\"startTime\\": 139.92, \\"endTime\\": 141.56, \\"text\\": \\"总之不是Little Lobster\\"}, {\\"index\\": 86, \\"startTime\\": 141.56, \\"endTime\\": 143.52, \\"text\\": \\"或Small Lobster\\"}, {\\"index\\": 87, \\"startTime\\": 143.52, \\"endTime\\": 145.2, \\"text\\": \\"说回Claw这个词\\"}, {\\"index\\": 88, \\"startTime\\": 145.2, \\"endTime\\": 147.08, \\"text\\": \\"这个不只是海鲜的专属\\"}, {\\"index\\": 89, \\"startTime\\": 147.08, \\"endTime\\": 148.96, \\"text\\": \\"天上飞的鸟也有Claw\\"}, {\\"index\\": 90, \\"startTime\\": 148.96, \\"endTime\\": 150.36, \\"text\\": \\"小区里那只脾气暴躁的\\"}, {\\"index\\": 91, \\"startTime\\": 150.36, \\"endTime\\": 151.92, \\"text\\": \\"流浪猫也有Claw\\"}, {\\"index\\": 92, \\"startTime\\": 151.92, \\"endTime\\": 153.48, \\"text\\": \\"别问我怎么知道的\\"}, {\\"index\\": 93, \\"startTime\\": 153.48, \\"endTime\\": 154.68, \\"text\\": \\"更重要的是\\"}, {\\"index\\": 94, \\"startTime\\": 154.68, \\"endTime\\": 157.0, \\"text\\": \\"它还是个极其凶狠的洞瓷\\"}, {\\"index\\": 95, \\"startTime\\": 157.0, \\"endTime\\": 158.24, \\"text\\": \\"比如咱们可以说\\"}, {\\"index\\": 96, \\"startTime\\": 158.24, \\"endTime\\": 160.2, \\"text\\": \\"The wolf clawed at my door\\"}, {\\"index\\": 97, \\"startTime\\": 160.2, \\"endTime\\": 162.08, \\"text\\": \\"狼疯狂地抓拿我的门\\"}, {\\"index\\": 98, \\"startTime\\": 162.08, \\"endTime\\": 164.04, \\"text\\": \\"She clawed me across the face\\"}, {\\"index\\": 99, \\"startTime\\": 164.04, \\"endTime\\": 165.44, \\"text\\": \\"她抓了我的脸\\"}, {\\"index\\": 100, \\"startTime\\": 165.44, \\"endTime\\": 167.2, \\"text\\": \\"My hands clawed the air\\"}, {\\"index\\": 101, \\"startTime\\": 167.2, \\"endTime\\": 169.52, \\"text\\": \\"我的双手在空中乱抓\\"}, {\\"index\\": 102, \\"startTime\\": 169.52, \\"endTime\\": 170.68, \\"text\\": \\"再假设\\"}, {\\"index\\": 103, \\"startTime\\": 170.68, \\"endTime\\": 172.88, \\"text\\": \\"你最近英语考试彻底翻车了\\"}, {\\"index\\": 104, \\"startTime\\": 172.88, \\"endTime\\": 175.16, \\"text\\": \\"或者基金爹的亲妈都不认了\\"}, {\\"index\\": 105, \\"startTime\\": 175.16, \\"endTime\\": 176.48, \\"text\\": \\"你想重回巅峰了\\"}, {\\"index\\": 106, \\"startTime\\": 176.48, \\"endTime\\": 178.32, \\"text\\": \\"那绝对不叫Walkback\\"}, {\\"index\\": 107, \\"startTime\\": 178.32, \\"endTime\\": 180.08, \\"text\\": \\"得叫Claw your way back\\"}, {\\"index\\": 108, \\"startTime\\": 180.08, \\"endTime\\": 180.8, \\"text\\": \\"意思是\\"}, {\\"index\\": 109, \\"startTime\\": 180.8, \\"endTime\\": 181.68, \\"text\\": \\"张牙舞爪\\"}, {\\"index\\": 110, \\"startTime\\": 181.68, \\"endTime\\": 182.56, \\"text\\": \\"脸滚带趴地\\"}, {\\"index\\": 111, \\"startTime\\": 182.56, \\"endTime\\": 183.72, \\"text\\": \\"杀出一条血路\\"}, {\\"index\\": 112, \\"startTime\\": 183.72, \\"endTime\\": 185.6, \\"text\\": \\"把失去的夺回来\\"}, {\\"index\\": 113, \\"startTime\\": 185.6, \\"endTime\\": 186.08, \\"text\\": \\"好\\"}, {\\"index\\": 114, \\"startTime\\": 186.08, \\"endTime\\": 188.88, \\"text\\": \\"在你跑去排队灵养这只赛波海鲜之前\\"}, {\\"index\\": 115, \\"startTime\\": 188.88, \\"endTime\\": 191.16, \\"text\\": \\"请复习一下本颗的知识点\\"}, {\\"index\\": 116, \\"startTime\\": 191.16, \\"endTime\\": 194.4, \\"text\\": \\"我是英语兔\\"}, {\\"index\\": 117, \\"startTime\\": 194.4, \\"endTime\\": 195.76, \\"text\\": \\"咱们下次再见\\"}]", "language": "zh-CN", "video_id": 29, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_30_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 1.72, \\"text\\": \\"数学怎么提分\\"}, {\\"index\\": 2, \\"startTime\\": 1.72, \\"endTime\\": 3.0, \\"text\\": \\"我给你说了多少次\\"}, {\\"index\\": 3, \\"startTime\\": 3.0, \\"endTime\\": 4.64, \\"text\\": \\"好的 再讲就是不做 你知道吗\\"}, {\\"index\\": 4, \\"startTime\\": 4.64, \\"endTime\\": 6.56, \\"text\\": \\"就是四个字 四科错题\\"}, {\\"index\\": 5, \\"startTime\\": 6.56, \\"endTime\\": 7.88, \\"text\\": \\"跟你讲 关于这个四科错题\\"}, {\\"index\\": 6, \\"startTime\\": 7.88, \\"endTime\\": 10.4, \\"text\\": \\"很多人在执行的时候有各种的问题\\"}, {\\"index\\": 7, \\"startTime\\": 10.4, \\"endTime\\": 12.68, \\"text\\": \\"其实就是没做到点子上\\"}, {\\"index\\": 8, \\"startTime\\": 12.68, \\"endTime\\": 15.44, \\"text\\": \\"什么分析我错的是什么知识点\\"}, {\\"index\\": 9, \\"startTime\\": 15.44, \\"endTime\\": 17.04, \\"text\\": \\"分析我错的原因\\"}, {\\"index\\": 10, \\"startTime\\": 17.04, \\"endTime\\": 18.8, \\"text\\": \\"分析什么这个提醒是啥\\"}, {\\"index\\": 11, \\"startTime\\": 18.8, \\"endTime\\": 19.88, \\"text\\": \\"这都没有用\\"}, {\\"index\\": 12, \\"startTime\\": 19.88, \\"endTime\\": 22.32, \\"text\\": \\"你要做的就是把这个题再给我做对就完了\\"}, {\\"index\\": 13, \\"startTime\\": 22.32, \\"endTime\\": 23.8, \\"text\\": \\"做不对就一直改\\"}, {\\"index\\": 14, \\"startTime\\": 23.8, \\"endTime\\": 26.04, \\"text\\": \\"你们要把这件事的注意力\\"}, {\\"index\\": 15, \\"startTime\\": 26.04, \\"endTime\\": 27.68, \\"text\\": \\"放在最关键的地方 是吧\\"}, {\\"index\\": 16, \\"startTime\\": 27.68, \\"endTime\\": 29.52, \\"text\\": \\"因为什么错是没有意义的\\"}, {\\"index\\": 17, \\"startTime\\": 29.52, \\"endTime\\": 30.48, \\"text\\": \\"我就问你个问题\\"}, {\\"index\\": 18, \\"startTime\\": 30.48, \\"endTime\\": 32.0, \\"text\\": \\"他因为什么错\\"}, {\\"index\\": 19, \\"startTime\\": 32.0, \\"endTime\\": 33.04, \\"text\\": \\"他知道了这个原因\\"}, {\\"index\\": 20, \\"startTime\\": 33.04, \\"endTime\\": 34.2, \\"text\\": \\"他下次就可以不错\\"}, {\\"index\\": 21, \\"startTime\\": 34.2, \\"endTime\\": 35.96, \\"text\\": \\"好在那里面就想这个问题\\"}, {\\"index\\": 22, \\"startTime\\": 35.96, \\"endTime\\": 37.0, \\"text\\": \\"他是不会的\\"}, {\\"index\\": 23, \\"startTime\\": 37.0, \\"endTime\\": 39.04, \\"text\\": \\"他就是很多东西不扎实不熟练\\"}, {\\"index\\": 24, \\"startTime\\": 39.04, \\"endTime\\": 39.68, \\"text\\": \\"就这么简单\\"}, {\\"index\\": 25, \\"startTime\\": 39.68, \\"endTime\\": 40.4, \\"text\\": \\"那怎么办呢\\"}, {\\"index\\": 26, \\"startTime\\": 40.4, \\"endTime\\": 41.52, \\"text\\": \\"你让他扎实让他熟练\\"}, {\\"index\\": 27, \\"startTime\\": 41.52, \\"endTime\\": 42.6, \\"text\\": \\"那怎么办你就改错\\"}, {\\"index\\": 28, \\"startTime\\": 42.6, \\"endTime\\": 44.64, \\"text\\": \\"我刚才说过循环改错 循环改错\\"}, {\\"index\\": 29, \\"startTime\\": 44.64, \\"endTime\\": 46.4, \\"text\\": \\"就你这张卷量错题第一次改\\"}, {\\"index\\": 30, \\"startTime\\": 46.4, \\"endTime\\": 47.8, \\"text\\": \\"改对的答案给我改错了\\"}, {\\"index\\": 31, \\"startTime\\": 47.8, \\"endTime\\": 50.0, \\"text\\": \\"就打个差学期答案下一周继续\\"}, {\\"index\\": 32, \\"startTime\\": 50.0, \\"endTime\\": 52.04, \\"text\\": \\"没有几个人能够把这东西坚持下来\\"}, {\\"index\\": 33, \\"startTime\\": 52.04, \\"endTime\\": 53.56, \\"text\\": \\"坚持下来的扎实\\"}, {\\"index\\": 34, \\"startTime\\": 53.56, \\"endTime\\": 55.52, \\"text\\": \\"都已经发现这个方法危利无缘\\"}, {\\"index\\": 35, \\"startTime\\": 55.52, \\"endTime\\": 56.76, \\"text\\": \\"那成绩层层往上找\\"}, {\\"index\\": 36, \\"startTime\\": 56.76, \\"endTime\\": 59.6, \\"text\\": \\"所以关键是在坚持在执行\\"}, {\\"index\\": 37, \\"startTime\\": 59.6, \\"endTime\\": 61.96, \\"text\\": \\"我刚好说一万三千小时说一万可\\"}, {\\"index\\": 38, \\"startTime\\": 61.96, \\"endTime\\": 62.96, \\"text\\": \\"今天给大家准备了一个好东西\\"}, {\\"index\\": 39, \\"startTime\\": 62.96, \\"endTime\\": 63.72, \\"text\\": \\"逆袭有方法\\"}, {\\"index\\": 40, \\"startTime\\": 63.72, \\"endTime\\": 64.8, \\"text\\": \\"每一次都是我抄行程\\"}, {\\"index\\": 41, \\"startTime\\": 64.8, \\"endTime\\": 65.72, \\"text\\": \\"我给你免费发一份\\"}, {\\"index\\": 42, \\"startTime\\": 65.72, \\"endTime\\": 66.84, \\"text\\": \\"平时去打出逆袭\\"}]", "language": "zh-CN", "video_id": 30, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_37_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 5.28, \\"text\\": \\"前段时间我揉了7视频吐槽国内现代的献情教材\\"}, {\\"index\\": 2, \\"startTime\\": 5.28, \\"endTime\\": 9.32, \\"text\\": \\"红技大学第6版紫皮现代不仅编排混乱\\"}, {\\"index\\": 3, \\"startTime\\": 9.32, \\"endTime\\": 12.0, \\"text\\": \\"而且内容和势力都太少\\"}, {\\"index\\": 4, \\"startTime\\": 12.0, \\"endTime\\": 15.0, \\"text\\": \\"根本没有讲到现代的核心思想\\"}, {\\"index\\": 5, \\"startTime\\": 15.0, \\"endTime\\": 19.76, \\"text\\": \\"随后就有很多朋友问我那现代到底应该怎么学呢\\"}, {\\"index\\": 6, \\"startTime\\": 19.76, \\"endTime\\": 21.56, \\"text\\": \\"我们不妨来听听MIT\\"}, {\\"index\\": 7, \\"startTime\\": 21.56, \\"endTime\\": 28.0, \\"text\\": \\"也就是美国的著名学府麻省理工学院的吉尔伯特斯朗教授\\"}, {\\"index\\": 8, \\"startTime\\": 28.0, \\"endTime\\": 30.64, \\"text\\": \\"是如何回答这个问题的\\"}, {\\"index\\": 9, \\"startTime\\": 30.64, \\"endTime\\": 35.32, \\"text\\": \\"吉尔伯特斯特朗教授是美国著名的数学教育家\\"}, {\\"index\\": 10, \\"startTime\\": 35.32, \\"endTime\\": 39.08, \\"text\\": \\"在MIT教了60多年现代数\\"}, {\\"index\\": 11, \\"startTime\\": 39.08, \\"endTime\\": 42.6, \\"text\\": \\"也是三本现性代数学习圣经\\"}, {\\"index\\": 12, \\"startTime\\": 42.6, \\"endTime\\": 44.2, \\"text\\": \\"现性代数捣乱\\"}, {\\"index\\": 13, \\"startTime\\": 44.2, \\"endTime\\": 49.52, \\"text\\": \\"现性代数基金应用和这本现性代数与数据数据的作者\\"}, {\\"index\\": 14, \\"startTime\\": 49.52, \\"endTime\\": 53.32, \\"text\\": \\"第一本书是MIT本科现代科人的教材\\"}, {\\"index\\": 15, \\"startTime\\": 53.32, \\"endTime\\": 55.32, \\"text\\": \\"还尽量无须多言\\"}, {\\"index\\": 16, \\"startTime\\": 55.32, \\"endTime\\": 59.2, \\"text\\": \\"第二本书则详细显明了现代的应用价值\\"}, {\\"index\\": 17, \\"startTime\\": 59.2, \\"endTime\\": 65.0, \\"text\\": \\"其他那本书以后你再也不会迷惑于现代到底有什么用\\"}, {\\"index\\": 18, \\"startTime\\": 65.0, \\"endTime\\": 69.4, \\"text\\": \\"而这第三本书则是四川老爷子仅跟时代潮流\\"}, {\\"index\\": 19, \\"startTime\\": 69.4, \\"endTime\\": 72.4, \\"text\\": \\"在2019年出版的最新逆作\\"}, {\\"index\\": 20, \\"startTime\\": 72.4, \\"endTime\\": 78.48, \\"text\\": \\"我手里拿的是这本书由清华大学出版社翻译的出版的中文版\\"}, {\\"index\\": 21, \\"startTime\\": 78.48, \\"endTime\\": 82.84, \\"text\\": \\"很多朋友去现在的时候遇到的最大困难在于\\"}, {\\"index\\": 22, \\"startTime\\": 82.84, \\"endTime\\": 86.24, \\"text\\": \\"这些枯燥的现代理论到底有什么用\\"}, {\\"index\\": 23, \\"startTime\\": 86.24, \\"endTime\\": 91.24, \\"text\\": \\"由清华大学出版社出版这本现性代数与数据学习\\"}, {\\"index\\": 24, \\"startTime\\": 91.24, \\"endTime\\": 92.48, \\"text\\": \\"跟你回答\\"}, {\\"index\\": 25, \\"startTime\\": 92.48, \\"endTime\\": 95.88, \\"text\\": \\"众所周知人工智能是当代显学\\"}, {\\"index\\": 26, \\"startTime\\": 95.88, \\"endTime\\": 100.84, \\"text\\": \\"所以现性代数与数据学习这本书也仅跟前沿\\"}, {\\"index\\": 27, \\"startTime\\": 100.84, \\"endTime\\": 102.4, \\"text\\": \\"在最后一章\\"}, {\\"index\\": 28, \\"startTime\\": 102.4, \\"endTime\\": 106.24, \\"text\\": \\"发的格外多的笔墨以人工智能做结尾\\"}, {\\"index\\": 29, \\"startTime\\": 106.24, \\"endTime\\": 112.2, \\"text\\": \\"他在最后一章详细介绍了人工智能的底层数学框架圣经网络\\"}, {\\"index\\": 30, \\"startTime\\": 112.2, \\"endTime\\": 116.28, \\"text\\": \\"把现性代数和人工智能技术结合起来\\"}, {\\"index\\": 31, \\"startTime\\": 116.28, \\"endTime\\": 119.64, \\"text\\": \\"直接展示现代的巨大应用价值\\"}, {\\"index\\": 32, \\"startTime\\": 119.64, \\"endTime\\": 122.08, \\"text\\": \\"再烧烊前看一点\\"}, {\\"index\\": 33, \\"startTime\\": 122.08, \\"endTime\\": 123.84, \\"text\\": \\"在第五章和第六章\\"}, {\\"index\\": 34, \\"startTime\\": 123.84, \\"endTime\\": 127.56, \\"text\\": \\"这本书则详细介绍了举证在概律论\\"}, {\\"index\\": 35, \\"startTime\\": 127.56, \\"endTime\\": 130.68, \\"text\\": \\"统计学和优化理论的应用\\"}, {\\"index\\": 36, \\"startTime\\": 130.68, \\"endTime\\": 133.12, \\"text\\": \\"在斯特党老爷子姐讲当地的下呢\\"}, {\\"index\\": 37, \\"startTime\\": 133.12, \\"endTime\\": 136.76, \\"text\\": \\"举证不再只是一张看似无用的数表\\"}, {\\"index\\": 38, \\"startTime\\": 136.76, \\"endTime\\": 140.44, \\"text\\": \\"和求解现性方程组使使用的工具\\"}, {\\"index\\": 39, \\"startTime\\": 140.44, \\"endTime\\": 146.04, \\"text\\": \\"更值得一提的是优化方法也是举证理论的重要应用之一\\"}, {\\"index\\": 40, \\"startTime\\": 146.04, \\"endTime\\": 147.64, \\"text\\": \\"在第三章和第四章\\"}, {\\"index\\": 41, \\"startTime\\": 147.64, \\"endTime\\": 152.04, \\"text\\": \\"这本书则讲解了压缩感知技术和图像处理\\"}, {\\"index\\": 42, \\"startTime\\": 152.04, \\"endTime\\": 153.44, \\"text\\": \\"TU的相关设计基础\\"}, {\\"index\\": 43, \\"startTime\\": 153.44, \\"endTime\\": 156.72, \\"text\\": \\"可以说斯特党老爷子用这一本书\\"}, {\\"index\\": 44, \\"startTime\\": 156.72, \\"endTime\\": 159.76, \\"text\\": \\"以现性代数为出发点\\"}, {\\"index\\": 45, \\"startTime\\": 159.76, \\"endTime\\": 162.8, \\"text\\": \\"把广义上的好几个应用分支\\"}, {\\"index\\": 46, \\"startTime\\": 162.8, \\"endTime\\": 166.0, \\"text\\": \\"概据论、统计学、最优化技术学习\\"}, {\\"index\\": 47, \\"startTime\\": 166.0, \\"endTime\\": 169.64, \\"text\\": \\"压缩感知、图像处理全都给串起来了\\"}, {\\"index\\": 48, \\"startTime\\": 169.64, \\"endTime\\": 171.6, \\"text\\": \\"你在学这本书的时候\\"}, {\\"index\\": 49, \\"startTime\\": 171.6, \\"endTime\\": 174.28, \\"text\\": \\"提到了可不止是干巴的现性代数\\"}, {\\"index\\": 50, \\"startTime\\": 174.28, \\"endTime\\": 176.88, \\"text\\": \\"更是所谓的应用数学基础\\"}, {\\"index\\": 51, \\"startTime\\": 176.88, \\"endTime\\": 179.24, \\"text\\": \\"当然可能会有朋友担心\\"}, {\\"index\\": 52, \\"startTime\\": 179.24, \\"endTime\\": 180.84, \\"text\\": \\"这本书虽然好\\"}, {\\"index\\": 53, \\"startTime\\": 180.84, \\"endTime\\": 182.84, \\"text\\": \\"但如果难度太高\\"}, {\\"index\\": 54, \\"startTime\\": 182.84, \\"endTime\\": 185.16, \\"text\\": \\"不适合自己就要怎么办\\"}, {\\"index\\": 55, \\"startTime\\": 185.16, \\"endTime\\": 188.52, \\"text\\": \\"作为一名经验丰富的数学教育家\\"}, {\\"index\\": 56, \\"startTime\\": 188.52, \\"endTime\\": 192.36, \\"text\\": \\"斯特党老爷子贴心的用这本书的前两章\\"}, {\\"index\\": 57, \\"startTime\\": 192.36, \\"endTime\\": 194.48, \\"text\\": \\"配套了大量其题\\"}, {\\"index\\": 58, \\"startTime\\": 194.48, \\"endTime\\": 198.0, \\"text\\": \\"来讲解出这本书的时候需要的修计组学知识\\"}, {\\"index\\": 59, \\"startTime\\": 198.0, \\"endTime\\": 202.32, \\"text\\": \\"可以说不这本书需要的基础知识等于零\\"}, {\\"index\\": 60, \\"startTime\\": 202.32, \\"endTime\\": 203.6, \\"text\\": \\"你在读它时\\"}, {\\"index\\": 61, \\"startTime\\": 203.6, \\"endTime\\": 207.28, \\"text\\": \\"根本不用担心数学基础不够跟不上\\"}, {\\"index\\": 62, \\"startTime\\": 207.28, \\"endTime\\": 210.16, \\"text\\": \\"那么本期视频到此为止的\\"}, {\\"index\\": 63, \\"startTime\\": 210.16, \\"endTime\\": 212.32, \\"text\\": \\"如果各位朋友对这本书感兴趣的话\\"}, {\\"index\\": 64, \\"startTime\\": 212.32, \\"endTime\\": 213.72, \\"text\\": \\"可以出说至顶、连接\\"}, {\\"index\\": 65, \\"startTime\\": 213.72, \\"endTime\\": 217.84, \\"text\\": \\"我相信大家一定能从这本大多数的收获\\"}, {\\"index\\": 66, \\"startTime\\": 217.84, \\"endTime\\": 220.72, \\"text\\": \\"那么喜欢方面可以点赞、收藏、投币\\"}, {\\"index\\": 67, \\"startTime\\": 220.72, \\"endTime\\": 222.04, \\"text\\": \\"关注一键三连\\"}, {\\"index\\": 68, \\"startTime\\": 222.04, \\"endTime\\": 225.4, \\"text\\": \\"没有币的话点一个免费的赞也可以\\"}, {\\"index\\": 69, \\"startTime\\": 225.4, \\"endTime\\": 227.76, \\"text\\": \\"你的支持就是我\\"}, {\\"index\\": 70, \\"startTime\\": 227.76, \\"endTime\\": 228.76, \\"text\\": \\"最大的動力\\"}]", "language": "zh-CN", "video_id": 37, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_34_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 1.4, \\"text\\": \\"准渡好发力不一定好\\"}, {\\"index\\": 2, \\"startTime\\": 1.4, \\"endTime\\": 3.28, \\"text\\": \\"发力好准渡一定差不了\\"}, {\\"index\\": 3, \\"startTime\\": 3.28, \\"endTime\\": 7.4, \\"text\\": \\"所有发力差的投篮本质都有这样一个问题\\"}, {\\"index\\": 4, \\"startTime\\": 7.4, \\"endTime\\": 10.28, \\"text\\": \\"不管是推投手踝脚慢还是投尸肌也好\\"}, {\\"index\\": 5, \\"startTime\\": 10.28, \\"endTime\\": 11.44, \\"text\\": \\"都有一个共性\\"}, {\\"index\\": 6, \\"startTime\\": 11.44, \\"endTime\\": 13.68, \\"text\\": \\"那就是下肢在登身的过程中\\"}, {\\"index\\": 7, \\"startTime\\": 13.68, \\"endTime\\": 16.12, \\"text\\": \\"上肢在整体向前\\"}, {\\"index\\": 8, \\"startTime\\": 16.12, \\"endTime\\": 19.0, \\"text\\": \\"没有一段重合的力线\\"}, {\\"index\\": 9, \\"startTime\\": 19.0, \\"endTime\\": 20.48, \\"text\\": \\"划个力线图就会发现\\"}, {\\"index\\": 10, \\"startTime\\": 20.48, \\"endTime\\": 23.4, \\"text\\": \\"起球结束到出手阶段是一个锐脚\\"}, {\\"index\\": 11, \\"startTime\\": 23.4, \\"endTime\\": 25.6, \\"text\\": \\"而观察顶肩射手都会有一段\\"}, {\\"index\\": 12, \\"startTime\\": 25.6, \\"endTime\\": 27.68, \\"text\\": \\"几乎垂直上身的行程\\"}, {\\"index\\": 13, \\"startTime\\": 27.68, \\"endTime\\": 30.04, \\"text\\": \\"厚度的非常圆润丝滑的感觉\\"}, {\\"index\\": 14, \\"startTime\\": 30.04, \\"endTime\\": 32.08, \\"text\\": \\"可能会说听起来容易但不知道打改\\"}, {\\"index\\": 15, \\"startTime\\": 32.08, \\"endTime\\": 34.32, \\"text\\": \\"换一下修改磁路今天\\"}, {\\"index\\": 16, \\"startTime\\": 34.32, \\"endTime\\": 36.48, \\"text\\": \\"一个完整球篮就一秒钟左右的时间\\"}, {\\"index\\": 17, \\"startTime\\": 36.48, \\"endTime\\": 37.48, \\"text\\": \\"很难做到\\"}, {\\"index\\": 18, \\"startTime\\": 37.48, \\"endTime\\": 39.24, \\"text\\": \\"只改这么一小段\\"}, {\\"index\\": 19, \\"startTime\\": 39.24, \\"endTime\\": 43.64, \\"text\\": \\"所以就需要拉大行程提升溶脱空间\\"}, {\\"index\\": 20, \\"startTime\\": 43.64, \\"endTime\\": 47.76, \\"text\\": \\"比如触地投篮\\"}, {\\"index\\": 21, \\"startTime\\": 47.76, \\"endTime\\": 50.36, \\"text\\": \\"这样就有充足的时间去做出上下肢\\"}, {\\"index\\": 22, \\"startTime\\": 50.36, \\"endTime\\": 53.04, \\"text\\": \\"一起扫身这一段行程\\"}, {\\"index\\": 23, \\"startTime\\": 53.04, \\"endTime\\": 56.68, \\"text\\": \\"除了以后再慢慢提速\\"}, {\\"index\\": 24, \\"startTime\\": 56.68, \\"endTime\\": 58.24, \\"text\\": \\"同款训练的方式\\"}, {\\"index\\": 25, \\"startTime\\": 58.24, \\"endTime\\": 60.76, \\"text\\": \\"在纳什的训练也曾经提到过\\"}, {\\"index\\": 26, \\"startTime\\": 60.76, \\"endTime\\": 61.84, \\"text\\": \\"当然千人千样\\"}, {\\"index\\": 27, \\"startTime\\": 61.84, \\"endTime\\": 63.48, \\"text\\": \\"有时候也少不了其他训练的缝处\\"}, {\\"index\\": 28, \\"startTime\\": 63.48, \\"endTime\\": 64.88, \\"text\\": \\"才能找到法力感受\\"}, {\\"index\\": 29, \\"startTime\\": 64.88, \\"endTime\\": 65.84, \\"text\\": \\"如果自己捉挣不了\\"}, {\\"index\\": 30, \\"startTime\\": 65.84, \\"endTime\\": 67.0, \\"text\\": \\"也可以评论私信我\\"}, {\\"index\\": 31, \\"startTime\\": 67.0, \\"endTime\\": 69.08, \\"text\\": \\"但一定成这样流畅轻松的法力\\"}]", "language": "zh-CN", "video_id": 34, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_36_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 2.3, \\"text\\": \\"初學必學的九種技術\\"}, {\\"index\\": 2, \\"startTime\\": 2.3, \\"endTime\\": 6.08, \\"text\\": \\"一 正手弓\\"}, {\\"index\\": 3, \\"startTime\\": 6.08, \\"endTime\\": 9.3, \\"text\\": \\"二 防守撥\\"}, {\\"index\\": 4, \\"startTime\\": 9.3, \\"endTime\\": 12.7, \\"text\\": \\"三 正手戳\\"}, {\\"index\\": 5, \\"startTime\\": 12.7, \\"endTime\\": 16.4, \\"text\\": \\"四 防守戳\\"}, {\\"index\\": 6, \\"startTime\\": 16.4, \\"endTime\\": 21.0, \\"text\\": \\"五 正手拉\\"}, {\\"index\\": 7, \\"startTime\\": 21.0, \\"endTime\\": 25.6, \\"text\\": \\"六 防守拉\\"}, {\\"index\\": 8, \\"startTime\\": 29.0, \\"endTime\\": 30.5, \\"text\\": \\"七 正手防\\"}, {\\"index\\": 9, \\"startTime\\": 30.5, \\"endTime\\": 33.8, \\"text\\": \\"八 防守衛防\\"}, {\\"index\\": 10, \\"startTime\\": 33.8, \\"endTime\\": 36.6, \\"text\\": \\"九 打高球\\"}]", "language": "zh-CN", "video_id": 36, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
sub_38_zh-CN	subtitles	{"format": "srt", "source": "import", "status": 0, "content": "[{\\"index\\": 1, \\"startTime\\": 0.0, \\"endTime\\": 1.88, \\"text\\": \\"这是一个开源本地部署的\\"}, {\\"index\\": 2, \\"startTime\\": 1.88, \\"endTime\\": 3.6, \\"text\\": \\"AI短视频生成工具\\"}, {\\"index\\": 3, \\"startTime\\": 3.6, \\"endTime\\": 6.2, \\"text\\": \\"目前已经拿下了49.8K的新标\\"}, {\\"index\\": 4, \\"startTime\\": 6.2, \\"endTime\\": 8.2, \\"text\\": \\"只要一个主题或者关键词\\"}, {\\"index\\": 5, \\"startTime\\": 8.2, \\"endTime\\": 10.4, \\"text\\": \\"就能全自动生成高清短视频\\"}, {\\"index\\": 6, \\"startTime\\": 10.4, \\"endTime\\": 13.28, \\"text\\": \\"涵盖了文案、视频、字幕和BGM\\"}, {\\"index\\": 7, \\"startTime\\": 13.28, \\"endTime\\": 15.52, \\"text\\": \\"甚至最低紧需一台四核CPU\\"}, {\\"index\\": 8, \\"startTime\\": 15.52, \\"endTime\\": 17.12, \\"text\\": \\"内存4G以上的电脑\\"}, {\\"index\\": 9, \\"startTime\\": 17.12, \\"endTime\\": 18.92, \\"text\\": \\"就连显卡都是非必须\\"}, {\\"index\\": 10, \\"startTime\\": 18.92, \\"endTime\\": 20.92, \\"text\\": \\"普通个人电脑即可运行\\"}, {\\"index\\": 11, \\"startTime\\": 20.92, \\"endTime\\": 22.72, \\"text\\": \\"支持生成横屏和竖屏\\"}, {\\"index\\": 12, \\"startTime\\": 22.72, \\"endTime\\": 24.4, \\"text\\": \\"支持批量生成视频\\"}, {\\"index\\": 13, \\"startTime\\": 24.4, \\"endTime\\": 26.16, \\"text\\": \\"支持中英文两种语言\\"}, {\\"index\\": 14, \\"startTime\\": 26.16, \\"endTime\\": 27.52, \\"text\\": \\"还支持通易签问\\"}, {\\"index\\": 15, \\"startTime\\": 27.52, \\"endTime\\": 29.24, \\"text\\": \\"欧拉曼等大模型揭入\\"}, {\\"index\\": 16, \\"startTime\\": 29.24, \\"endTime\\": 31.24, \\"text\\": \\"几百种音色随便选择\\"}, {\\"index\\": 17, \\"startTime\\": 31.24, \\"endTime\\": 33.24, \\"text\\": \\"字幕也会自动匹配视频画面\\"}, {\\"index\\": 18, \\"startTime\\": 33.24, \\"endTime\\": 35.24, \\"text\\": \\"它采用的是智能缝合技术\\"}, {\\"index\\": 19, \\"startTime\\": 35.24, \\"endTime\\": 37.24, \\"text\\": \\"将互联网上的高质量素材\\"}, {\\"index\\": 20, \\"startTime\\": 37.24, \\"endTime\\": 39.0, \\"text\\": \\"进行智能组合和编辑\\"}, {\\"index\\": 21, \\"startTime\\": 39.0, \\"endTime\\": 40.28, \\"text\\": \\"保证了视频质量\\"}, {\\"index\\": 22, \\"startTime\\": 40.28, \\"endTime\\": 41.8, \\"text\\": \\"又避免了版权问题\\"}, {\\"index\\": 23, \\"startTime\\": 41.8, \\"endTime\\": 43.32, \\"text\\": \\"完整的NVC架构\\"}, {\\"index\\": 24, \\"startTime\\": 43.32, \\"endTime\\": 44.56, \\"text\\": \\"代码结构清晰\\"}, {\\"index\\": 25, \\"startTime\\": 44.56, \\"endTime\\": 46.12, \\"text\\": \\"二次开发非常简单\\"}, {\\"index\\": 26, \\"startTime\\": 46.12, \\"endTime\\": 48.12, \\"text\\": \\"感兴趣的可以研究研究\\"}]", "language": "zh-CN", "video_id": 38, "is_default": false, "uploaded_by": 0, "language_name": "中文"}	2026-08-19 16:04:59.272823+00	2026-08-19 16:07:33.001774+00
1787581489100228220	user_profiles	{"id": "1787581489100228220", "tags": null, "user_id": 4, "like_count": 2, "updated_at": "2026-08-26T22:03:34.631524402+08:00", "watch_count": 0, "collect_count": 2, "favorite_categories": [5, 1]}	2026-08-24 14:24:49.10076+00	2026-08-26 14:03:34.633207+00
1787844275380434762	subtitles	{"id": "1787844275380434762", "format": "json", "source": "whisper", "status": 1, "content": "[{\\"endTime\\":1,\\"index\\":1,\\"startTime\\":0,\\"text\\":\\"...\\"}]", "language": "zh-CN", "video_id": 25, "is_default": true, "upload_time": "2026-08-27T15:24:35.38035109Z", "uploaded_by": 0, "language_name": "中文"}	2026-08-27 15:24:35.381146+00	2026-08-27 15:24:35.381146+00
\.


--
-- Data for Name: live_linkmic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_linkmic (id, room_id, streamer_id, viewer_id, viewer_name, status, audio_enabled, video_enabled, max_linkmics, apply_time, connect_time, end_time) FROM stdin;
\.


--
-- Data for Name: live_rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_rooms (id, user_id, room_name, stream_key, status, cover_url, viewer_count, category, scheduled_at, created_at, updated_at) FROM stdin;
1	4	我的直播间	e4a53048e3fd45c6a91964b44df6262b	live	\N	0	\N	\N	2026-05-19 11:31:55	2026-05-19 12:22:28
2	5	我的直播间	7d42fcf7f4d84cbf9f24b763b46a34a9	offline	\N	0	\N	\N	2026-05-20 22:57:40	2026-05-20 22:57:40
\.


--
-- Data for Name: live_seats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_seats (id, room_id, seat_index, user_id, status, muted, joined_at) FROM stdin;
\.


--
-- Data for Name: login_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_logs (id, user_id, ip, user_agent, status, login_time) FROM stdin;
1	5	127.0.0.1:33864	curl/8.14.1	1	2026-08-26 05:49:26.237727+00
2	4	[::1]:55370	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0	1	2026-08-26 05:58:06.835616+00
3	4	127.0.0.1:49840	curl/8.14.1	1	2026-08-26 06:07:16.537368+00
4	4	127.0.0.1:50028	curl/8.14.1	1	2026-08-26 06:13:34.747327+00
5	4	127.0.0.1:33220	curl/8.14.1	1	2026-08-26 06:14:34.367418+00
6	4	[::1]:50478	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	1	2026-08-26 06:52:40.523024+00
7	4	127.0.0.1:49264	curl/8.14.1	1	2026-08-26 07:12:15.443782+00
8	4	127.0.0.1:54694	curl/8.14.1	1	2026-08-26 07:12:26.771231+00
9	4	127.0.0.1:37588	curl/8.14.1	1	2026-08-26 07:12:33.895417+00
10	4	127.0.0.1:38740	curl/8.14.1	1	2026-08-26 07:12:50.602446+00
11	4	127.0.0.1:55738	curl/8.14.1	1	2026-08-26 07:13:00.493034+00
12	4	127.0.0.1:34572	curl/8.14.1	1	2026-08-26 07:23:25.152295+00
13	4	127.0.0.1:56308	curl/8.14.1	1	2026-08-26 07:23:34.759464+00
14	4	127.0.0.1:51364	curl/8.14.1	1	2026-08-26 07:32:56.389216+00
15	4	127.0.0.1:56664	curl/8.14.1	1	2026-08-26 07:33:06.751714+00
16	4	127.0.0.1:36906	curl/8.14.1	1	2026-08-26 07:33:24.010346+00
17	4	127.0.0.1:51836	curl/8.14.1	1	2026-08-26 07:33:33.603437+00
18	4	127.0.0.1:33012	curl/8.14.1	1	2026-08-26 07:34:33.254488+00
19	4	127.0.0.1:53616	curl/8.14.1	1	2026-08-26 07:37:09.306267+00
20	4	127.0.0.1:40790	curl/8.14.1	1	2026-08-26 07:40:19.032311+00
21	4	[::1]:53168	curl/8.14.1	1	2026-08-26 09:40:04.829768+00
22	4	127.0.0.1:55308	curl/8.14.1	1	2026-08-26 12:20:38.047139+00
23	5	[::1]:46486	curl/8.14.1	1	2026-08-26 12:31:54.901598+00
24	5	[::1]:46498	curl/8.14.1	1	2026-08-26 12:31:54.954853+00
25	5	[::1]:50166	curl/8.14.1	1	2026-08-26 12:32:10.040214+00
26	5	[::1]:47228	curl/8.14.1	1	2026-08-26 12:34:23.326287+00
27	4	[::1]:44524	curl/8.14.1	1	2026-08-26 12:42:34.54657+00
28	4	127.0.0.1:59632	curl/8.14.1	1	2026-08-26 12:44:06.013264+00
29	4	127.0.0.1:42774	curl/8.14.1	1	2026-08-26 12:44:52.762273+00
30	4	[::1]:52040	curl/8.14.1	1	2026-08-26 12:48:32.471521+00
31	5	[::1]:50832	curl/8.14.1	1	2026-08-26 12:50:49.677391+00
32	5	127.0.0.1:53320	curl/8.14.1	1	2026-08-26 12:56:42.899053+00
33	5	127.0.0.1:49236	curl/8.14.1	1	2026-08-26 12:57:04.387755+00
34	4	[::1]:57326	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0	1	2026-08-26 13:11:39.805793+00
35	1	[::1]:47806	curl/8.14.1	1	2026-08-26 13:13:13.252855+00
36	1	[::1]:58524	curl/8.14.1	1	2026-08-26 13:16:06.655828+00
37	1	[::1]:41598	curl/8.14.1	1	2026-08-26 14:05:43.322595+00
38	1	[::1]:48422	curl/8.14.1	1	2026-08-26 14:05:59.077856+00
39	1	[::1]:44154	curl/8.14.1	1	2026-08-26 14:07:58.048191+00
40	1	[::1]:58950	curl/8.14.1	1	2026-08-26 14:08:07.192436+00
41	1	[::1]:36710	curl/8.14.1	1	2026-08-26 14:10:35.846703+00
42	5	127.0.0.1:45266	curl/8.14.1	1	2026-08-27 05:26:29.133068+00
43	4	127.0.0.1:44688	curl/8.14.1	1	2026-08-27 05:27:10.487262+00
44	5	127.0.0.1:46306	curl/8.14.1	1	2026-08-27 07:02:33.068379+00
45	5	127.0.0.1:51068	curl/8.14.1	1	2026-08-27 07:02:48.334688+00
46	4	127.0.0.1:35236	curl/8.14.1	1	2026-08-27 07:03:04.655581+00
47	6	127.0.0.1:35248	curl/8.14.1	1	2026-08-27 07:03:04.749592+00
48	4	127.0.0.1:36016	curl/8.14.1	1	2026-08-27 07:03:13.013007+00
49	4	127.0.0.1:36032	curl/8.14.1	1	2026-08-27 07:03:19.673401+00
50	4	127.0.0.1:59160	curl/8.14.1	1	2026-08-27 07:03:26.228495+00
51	4	127.0.0.1:39800	curl/8.14.1	1	2026-08-27 07:17:55.048707+00
52	5	127.0.0.1:39806	curl/8.14.1	1	2026-08-27 07:17:55.158778+00
53	6	127.0.0.1:39816	curl/8.14.1	1	2026-08-27 07:17:55.277427+00
54	6	127.0.0.1:40776	curl/8.14.1	1	2026-08-27 07:18:03.334083+00
55	5	172.18.0.1:58074	curl/8.14.1	1	2026-08-27 08:39:30.011491+00
56	5	172.18.0.1:43058	curl/8.14.1	1	2026-08-27 09:40:07.363159+00
57	5	172.18.0.1:56964	curl/8.14.1	1	2026-08-27 09:56:09.406735+00
58	5	172.18.0.1:51740	curl/8.14.1	1	2026-08-27 10:01:16.915494+00
59	5	172.18.0.1:48248	curl/8.14.1	1	2026-08-27 14:16:40.32934+00
60	5	10.42.0.1	curl/7.88.1	1	2026-08-28 06:52:11.730967+00
61	5	10.42.0.1	curl/7.88.1	1	2026-08-28 06:52:34.573679+00
62	5	10.42.0.1	curl/7.88.1	1	2026-08-28 07:07:30.240838+00
63	4	172.18.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36 Edg/150.0.0.0	1	2026-08-29 05:16:06.559982+00
64	5	172.18.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	1	2026-08-30 10:24:13.053183+00
\.


--
-- Data for Name: manuscript_collection_relations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscript_collection_relations (id, manuscript_id, collection_id, collection_order, created_at) FROM stdin;
1	12	3	0	2026-03-16 23:20:36
2	13	3	0	2026-03-16 23:23:05
1637826563	11	1444888585	0	2026-04-07 21:03:00
1637826564	27	3	3	2026-05-08 12:57:20
1637826565	10	1444888586	0	2026-05-09 13:19:44
1637826566	11	1444888586	1	2026-05-09 14:32:42
\.


--
-- Data for Name: manuscript_collections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscript_collections (id, title, description, cover_url, user_id, manuscript_count, view_count, status, created_at, updated_at) FROM stdin;
1444888585	人工智能		\N	4	1	\N	1	2026-04-07 21:03:00	2026-04-29 16:51:07
3	AI合集	AI合集	/uploads/manuscripts/27/cover.webp	5	3	0	1	2026-03-17 09:54:07	2026-05-08 13:34:01
1444888586	电子	烧录工具	/uploads/manuscripts/10/cover.webp	4	2	\N	1	2026-05-09 13:19:44	2026-05-09 14:32:42
\.


--
-- Data for Name: manuscript_daily_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscript_daily_metrics (metric_date, manuscript_id, user_id, view_count, like_count, coin_count, collect_count, share_count, comment_count, danmaku_count, created_at, updated_at) FROM stdin;
2026-08-18	29	5	1	0	0	0	0	0	0	2026-08-18 12:09:04.144392+00	2026-08-18 12:09:04.144392+00
2026-08-18	31	4	1	0	0	0	0	0	0	2026-08-18 12:22:04.37088+00	2026-08-18 12:22:04.37088+00
2026-08-18	14	5	1	0	0	0	0	0	0	2026-08-18 13:54:28.723578+00	2026-08-18 13:54:28.723578+00
2026-08-22	31	4	13	0	0	0	0	0	0	2026-08-22 02:31:20.029643+00	2026-08-22 08:46:54.179566+00
2026-08-27	48	126	2	0	0	0	0	0	0	2026-08-27 09:58:57.181911+00	2026-08-27 11:43:04.832264+00
2026-08-27	50	128	2	0	0	0	0	0	0	2026-08-27 03:44:06.870228+00	2026-08-27 11:43:13.832789+00
2026-08-19	31	4	1	0	0	0	0	0	0	2026-08-19 10:08:12.96872+00	2026-08-19 10:08:12.96872+00
2026-08-22	29	5	7	0	0	0	0	0	0	2026-08-22 05:10:45.704987+00	2026-08-22 09:31:03.786653+00
2026-08-19	29	5	3	0	0	0	0	0	0	2026-08-19 09:52:32.414992+00	2026-08-19 14:04:38.774564+00
2026-08-22	27	5	1	0	0	0	0	0	0	2026-08-22 12:57:18.640453+00	2026-08-22 12:57:18.640453+00
2026-08-28	35	115	1	0	0	0	0	0	0	2026-08-28 07:21:20.140136+00	2026-08-28 07:21:20.140136+00
2026-08-28	36	116	1	0	0	0	0	0	0	2026-08-28 08:55:30.620033+00	2026-08-28 08:55:30.620033+00
2026-08-22	10	4	5	0	0	0	0	0	0	2026-08-22 02:33:05.098158+00	2026-08-22 15:30:56.782053+00
2026-08-23	10	4	1	0	0	0	0	0	0	2026-08-23 07:38:44.370237+00	2026-08-23 07:38:44.370237+00
2026-08-23	29	5	1	0	0	0	0	0	0	2026-08-23 07:43:07.377673+00	2026-08-23 07:43:07.377673+00
2026-08-28	60	138	1	0	0	0	0	0	0	2026-08-28 08:55:55.647368+00	2026-08-28 08:55:55.647368+00
2026-08-23	13	5	1	0	0	0	0	0	0	2026-08-23 09:20:00.246951+00	2026-08-23 09:20:00.246951+00
2026-08-28	51	129	1	0	0	0	0	0	0	2026-08-28 08:56:18.829853+00	2026-08-28 08:56:18.829853+00
2026-08-26	11	4	28	0	2	-1	2	3	0	2026-08-26 06:05:37.820475+00	2026-08-26 14:03:34.615044+00
2026-08-23	31	4	7	0	0	0	0	0	0	2026-08-23 07:48:29.967251+00	2026-08-23 12:14:29.136426+00
2026-08-24	11	4	2	0	0	0	0	0	0	2026-08-24 13:09:11.892409+00	2026-08-24 13:58:16.95938+00
2026-08-24	13	5	1	0	0	0	0	0	0	2026-08-24 14:04:35.287156+00	2026-08-24 14:04:35.287156+00
2026-08-29	48	126	3	0	0	0	0	0	0	2026-08-29 05:35:14.694373+00	2026-08-29 07:53:18.922561+00
2026-08-26	13	5	9	0	0	0	0	0	0	2026-08-26 05:42:22.764406+00	2026-08-26 14:57:28.961415+00
2026-08-24	10	4	5	0	0	0	0	0	0	2026-08-24 13:21:06.986544+00	2026-08-24 14:11:09.59265+00
2026-08-24	29	5	1	0	0	0	0	0	0	2026-08-24 14:19:02.061205+00	2026-08-24 14:19:02.061205+00
2026-08-24	12	5	1	0	0	0	0	0	0	2026-08-24 14:21:30.179625+00	2026-08-24 14:21:30.179625+00
2026-08-19	14	5	2	0	0	0	0	0	0	2026-08-19 10:08:01.289246+00	2026-08-19 15:57:42.481341+00
2026-08-19	11	4	15	0	0	0	0	0	0	2026-08-19 10:08:58.922906+00	2026-08-19 15:58:36.991223+00
2026-08-25	29	5	1	0	0	0	0	0	0	2026-08-25 08:20:41.387208+00	2026-08-25 08:20:41.387208+00
2026-08-19	10	4	18	0	0	0	0	0	0	2026-08-19 04:15:57.742018+00	2026-08-19 16:10:18.9523+00
2026-08-20	14	5	1	0	0	0	0	0	0	2026-08-20 01:41:55.900148+00	2026-08-20 01:41:55.900148+00
2026-08-26	29	5	32	0	0	0	0	0	0	2026-08-26 04:57:08.554511+00	2026-08-26 15:20:29.796179+00
2026-08-20	10	4	4	0	0	0	0	0	0	2026-08-20 02:01:11.116437+00	2026-08-20 06:51:40.044402+00
2026-08-21	10	4	1	0	0	0	0	0	0	2026-08-21 07:31:42.649055+00	2026-08-21 07:31:42.649055+00
2026-08-21	31	4	1	0	0	0	0	0	0	2026-08-21 15:43:01.87287+00	2026-08-21 15:43:01.87287+00
2026-08-21	13	5	1	0	0	0	0	0	0	2026-08-21 15:43:24.159825+00	2026-08-21 15:43:24.159825+00
2026-08-26	31	4	19	0	0	0	0	0	0	2026-08-26 04:57:03.458342+00	2026-08-26 15:20:29.853596+00
2026-08-26	27	5	10	0	0	0	0	0	1	2026-08-26 05:42:15.133658+00	2026-08-26 15:20:34.505573+00
2026-08-30	48	126	1	0	0	0	0	0	0	2026-08-30 10:24:26.127035+00	2026-08-30 10:24:26.127035+00
2026-08-30	47	125	1	0	0	0	0	0	0	2026-08-30 10:25:08.323846+00	2026-08-30 10:25:08.323846+00
2026-08-26	14	5	10	0	0	0	0	0	0	2026-08-26 04:29:43.040352+00	2026-08-26 15:20:35.438117+00
2026-08-26	12	5	17	0	0	0	0	0	3	2026-08-26 02:35:07.2526+00	2026-08-26 15:20:45.187099+00
2026-08-26	10	4	10	0	0	0	0	3	4	2026-08-26 06:06:18.909396+00	2026-08-26 15:20:46.432552+00
2026-08-26	33	113	1	0	0	0	0	0	0	2026-08-26 16:32:31.349796+00	2026-08-26 16:32:31.349796+00
2026-08-25	14	5	3	0	0	0	0	0	0	2026-08-25 14:31:24.85852+00	2026-08-25 15:00:00.67504+00
2026-08-25	10	4	10	0	0	0	0	0	0	2026-08-25 07:19:31.639058+00	2026-08-25 15:13:25.620673+00
2026-08-22	14	5	4	0	0	0	0	0	0	2026-08-22 03:46:50.496879+00	2026-08-22 08:25:09.302871+00
2026-08-22	12	5	1	0	0	0	0	0	0	2026-08-22 08:25:11.90333+00	2026-08-22 08:25:11.90333+00
2026-08-22	13	5	1	0	0	0	0	0	0	2026-08-22 08:36:26.812994+00	2026-08-22 08:36:26.812994+00
2026-08-27	13	5	1	0	0	0	0	0	0	2026-08-27 03:55:39.147214+00	2026-08-27 03:55:39.147214+00
2026-08-27	43	121	1	0	0	0	0	0	0	2026-08-27 03:59:12.679657+00	2026-08-27 03:59:12.679657+00
2026-08-27	51	129	1	0	0	0	0	0	0	2026-08-27 03:59:23.019619+00	2026-08-27 03:59:23.019619+00
2026-08-27	37	117	1	0	0	0	0	0	0	2026-08-27 04:00:10.067072+00	2026-08-27 04:00:10.067072+00
2026-08-27	41	120	1	0	0	0	0	0	0	2026-08-27 04:00:17.292944+00	2026-08-27 04:00:17.292944+00
2026-08-26	32	4	1	0	0	0	0	0	0	2026-08-26 13:00:04.809233+00	2026-08-26 13:00:04.809233+00
2026-08-27	62	140	1	0	0	0	0	0	0	2026-08-27 04:01:14.845914+00	2026-08-27 04:01:14.845914+00
2026-08-27	10	4	1	0	0	0	0	0	0	2026-08-27 04:34:36.912983+00	2026-08-27 04:34:36.912983+00
2026-08-27	31	4	2	0	0	0	0	0	0	2026-08-27 04:34:36.946613+00	2026-08-27 04:34:47.797029+00
2026-08-27	36	116	4	0	0	0	0	0	0	2026-08-27 03:29:02.13611+00	2026-08-27 09:58:54.704827+00
2026-08-27	33	113	2	0	0	0	0	0	0	2026-08-27 04:34:36.983077+00	2026-08-27 09:59:02.557764+00
2026-08-27	47	125	1	0	0	0	0	0	0	2026-08-27 11:42:53.865092+00	2026-08-27 11:42:53.865092+00
\.


--
-- Data for Name: manuscript_edit_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscript_edit_versions (id, manuscript_id, user_id, before_snapshot, after_snapshot, changed_fields, status, reviewer_id, review_reason, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: manuscript_status_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscript_status_events (id, manuscript_id, user_id, from_status, to_status, action, operator_type, operator_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: manuscripts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manuscripts (id, title, description, cover_url, user_id, category_id, view_count, like_count, coin_count, collect_count, share_count, comment_count, danmaku_count, status, review_status, review_reason, review_time, reviewer_id, upload_time, updated_at, duration, duration_seconds, search_vector, source_type, bvid, origin_url) FROM stdin;
13	数学怎么提分	数学怎么提分#家长收藏孩子受益 #家长必读 #学习方法 #学霸秘籍	/uploads/manuscripts/13/cover.webp	5	3	43	2	0	1	0	1	0	3	0	\N	\N	\N	2026-03-16 23:23:05	2026-08-27 03:55:39.136719	1:11	71	'分':3,6 '受益':10 '学':14 '学习方法':13 '孩子':9 '家长':7,11 '必读':12 '提':2,5 '收藏':8 '数学':1,4 '秘籍':16 '霸':15	local		
61	以色列狠狠压力美国	本视频提及事件以及信息来源如下：\n《消息人士：美政府当前不希望以色列参与对伊战事》来自：央视新闻，2026-07-10 21:11发布\n《特朗普叫停以色列军事行动并怒斥内塔尼亚胡，后者回应：继续推进黎南部行动》来自：上观新闻，2026-06-02 18:40发布\n《以色列表面示好美国，短期难解战略分歧》来自：北晚在线，2026-07-05 18:19发布\n《深度｜罕见“硬刚”特朗普，称对最好朋友也不让步，内塔尼亚胡唱的是哪一出？》来自：上观新闻，2026-08-10 21:13发布\n《以色列和美国，“同床异梦”》来自：广州日报，2026-06-23 18:33发布\n《民调显示内塔尼亚胡支持率大跌》来自：新华网，2026-06-22 10:54:58发布\n《美国再次大变脸，今或与伊朗谈判；以色列自曝“被盟友抛弃”，正面临双重困局》来自：上观新闻，2026-08-03 07:59发布\n《一场密晤之后，特朗普会不会被内塔尼亚胡“拐跑”？》来自：新民晚报，2026-07-30 12:59发布\n《以高官称以高层从社交媒体才知道特朗普已取消对伊朗打击计划，感觉“他们（美方）把我们晾在一边”》来自：红星新闻，2026-08-03 07:14发布\n《内塔尼亚胡“硬刚”特朗普》来自：红星新闻，2026-08-11 07:53发布\n《内塔尼亚胡提出“终极条件”》来自：环球时报，2026-07-29 08:11发布\n《拒绝加沙和平方案，争取极右盟友支持，内塔尼亚胡“硬刚”特朗普》来自：中国青年网，2026-08-11 06:36发布\n《国际观察｜伊朗“放狠话”美伊谈判能否迈过这道坎》来自：新华网，2026-06/02 20:11:50发布	https://i2.hdslb.com/bfs/archive/e94d18fde833769809a2f7b7b843a26a60846e5b.jpg	139	12	2144407	118258	28181	18204	1618	4269	7667	3	1	\N	\N	\N	2026-08-24 03:50:00	2026-08-26 16:31:07.300394	21:45	1305	'02':45,218 '03':123,160 '05':61 '06':44,90,101,201,217 '07':24,60,124,137,161,172,181 '08':80,122,159,170,183,199 '10':25,81,103 '11':171,200,220 '12':139 '18':46,62,92 '20':219 '2026':23,43,59,79,89,100,121,136,158,169,180,198,216 '21':26,82 '22':102 '23':91 '29':182 '30':138 '54':104 '上':41,77,119 '不会':130 '中国青年':196 '争取':189 '事件':8 '人士':13 '以色列':1,17,30,48,84,112 '伊朗':110,149,205 '会':129 '信息':9 '内塔尼亚胡':34,72,95,131,163,174,192 '再次':107 '军事':31 '出':75 '分歧':55 '加沙':186 '压力':3 '参与':18 '发布':27,47,63,83,93,105,125,140,162,173,184,202,221 '取消':148 '变脸':109 '叫停':29 '同床异梦':86 '和平':187 '唱':73 '回应':35 '困局':117 '国际':203 '在线':58 '大':108 '大跌':97 '央视':21 '如下':11 '媒体':145 '密':126 '希望':16 '广州日报':88 '当前':15 '怒斥':33 '感觉':152 '战事':19 '战略':54 '打击':150 '抛弃':115 '拐':132 '拒绝':185 '推进':37 '提出':175 '提及':7 '支持':191 '支持率':96 '放':206 '新华网':99,215 '新民晚报':135 '新闻':22,42,78,120,157,168 '方案':188 '是':74 '显示':94 '晚':57 '晤':127 '晾':154 '曝':113 '最好':69 '朋友':70 '本':5 '条件':177 '来源':10 '来自':20,40,56,76,87,98,118,134,155,166,178,195,214 '消息':12 '深度':64 '特朗普':28,67,128,147,165,194 '狠狠':2 '环球时报':179 '盟友':114,190 '知道':146 '短期':52 '硬':66,164,193 '示好':50 '社交':144 '称':68,142 '红星':156,167 '终极':176 '继续':36 '网':197 '罕见':65 '美':208 '美国':4,51,85,106 '美政府':14 '美方':153 '能否':210 '行动':32,39 '表面':49 '观察':204 '视频':6 '计划':151 '让步':71 '话':207 '谈判':111,209 '跑':133 '过':212 '迈':211 '道坎':213 '难解':53 '面临':116 '高官':141 '高层':143 '黎':38	bilibili	BV1rg8Y6zET2	https://www.bilibili.com/video/BV1rg8Y6zET2
32	Skills	开源Skills	/uploads/manuscripts/32/cover.webp	4	1	1	0	0	0	0	0	0	-1	0	\N	\N	\N	2026-05-10 08:04:36	2026-08-26 13:00:04.806715	00:27	27	'skills':1,3 '开源':2	local		
27	投篮力线错误？这样改！	投篮力线错误？这样改！	/uploads/manuscripts/27/cover.webp	5	5	44	2	0	1	0	2	0	3	1	\N	\N	\N	2026-04-03 18:02:58	2026-08-26 15:20:34.503608	01:09	69	'力':2,7 '投篮':1,6 '改':5,10 '线':3,8 '错误':4,9	local		
31	github短视频生成工具	github短视频生成工具	/uploads/manuscripts/31/cover.webp	4	7	47	1	0	0	0	0	0	3	1	\N	\N	\N	2026-05-09 23:37:44	2026-08-27 04:34:47.787758	00:47	47	'github':1,6 '工具':5,10 '生成':4,9 '短':2,7 '视频':3,8	local		
33	王中王夺冠自战解说	-	https://i0.hdslb.com/bfs/archive/dff6e9ccc224bbf49cd62806dc620ae1e0b66014.jpg	113	11	4590823	502858	95719	79083	45797	24213	17409	3	1	\N	\N	\N	2026-08-24 11:33:14	2026-08-27 09:59:02.554244	45:46	2746	'夺冠':2 '战':3 '王中王':1 '解说':4	bilibili	BV1PEhP6vERe	https://www.bilibili.com/video/BV1PEhP6vERe
12	把 OpenClaw 翻译成“小龙虾”的，出来挨打！		/uploads/manuscripts/12/cover.webp	5	4	61	2	0	1	1	2	0	3	0	\N	\N	\N	2026-03-16 23:20:36	2026-08-26 15:20:45.178092	3:16	196	'openclaw':1 '出来':6 '小':4 '成':3 '挨打':7 '翻译':2 '龙虾':5	local		
35	贱谍过家家（8）	我会突破瓶颈，一定会努力做好未来的视频！感谢你一直的支持！\n\n希望观众朋友们可以喜欢这个系列！\n（希望你们喜欢，记得一键三连！）	https://i1.hdslb.com/bfs/archive/9bda56f1a45fd9ed421ea1c18451a962f8345029.jpg	115	11	4942114	450119	236833	148615	21296	12445	33892	3	1	\N	\N	\N	2026-08-24 16:00:00	2026-08-28 07:21:20.131746	26:06	1566	'一键':21 '三连':22 '会':6 '做好':8 '努力':7 '可以':16 '喜欢':17,19 '希望':13,18 '感谢':11 '支持':12 '朋友':15 '未来':9 '瓶颈':5 '突破':4 '观众':14 '视频':10 '记得':20 '谍':2 '贱':1 '过家家':3	bilibili	BV1gLhK6LEcb	https://www.bilibili.com/video/BV1gLhK6LEcb
29	少儿乒乓球训练	少儿乒乓球训练	/uploads/manuscripts/29/cover.webp	5	5	124	2	1	1	2	3	0	3	0	\N	\N	\N	2026-04-03 19:12:28	2026-08-26 15:20:29.792745	00:38	38	'乒乓球':2,5 '少儿':1,4 '训练':3,6	local		
14	每天学习一个电子知识，今天学习如何测电压		/uploads/manuscripts/14/cover.webp	5	2	216	3	0	2	0	1	0	3	0	\N	\N	\N	2026-03-16 23:28:29	2026-08-26 15:20:35.431197	0:26	26	'今天':4 '学习':1,5 '测':6 '电压':7 '电子':2 '知识':3	local		
62	我找了3000人进行高考生存挑战！	我找了3000人“关”起来挑战生存三年并参加高考！\n前半段是场游戏化的生存挑战，后半段是那些真正走过这段路的人的感想\n游戏可以读档重来，但青春没有攻略\n无论你正卡在哪一步，都希望这个视频能给你一点点往前走的力气~\n【时间轴】\n00:00 - 挑战开始\n01:20 - 等级三，压力来了\n02:50 - 好吧，我编不下去了\n04:10 - 听听他们怎么说\n06:30 - 敬每个勇往直前的你\n\n创意参考：@野兽先生MrBeast   @逗比的雀巢   @小宏不炸机  \n如果这个视频有打动你，欢迎一键三连，分享给那个你希望TA也能看到的朋友\n感谢 @sky @Alina @安风 和所有愿意分享故事的学长学姐。\n部分镜头由 Seedance 辅助生成，仅用于艺术表达。\n所有出镜人物均已获得本人同意，剧情演绎请勿模仿。\n本视频不代表任何立场。	https://i2.hdslb.com/bfs/archive/a1560f5435848c6bdf2738c64270ba07391af3c2.jpg	140	11	1790297	194842	22557	35857	8380	4643	1357	3	1	\N	\N	\N	2026-08-24 05:36:01	2026-08-27 04:01:14.836253	05:01	301	'00':50,51 '01':54 '02':60 '04':66 '06':70 '10':67 '20':55 '30':71 '3000':3,11 '50':61 'alina':99 'mrbeast':78 'seedance':111 'sky':98 'ta':93 '一点点':44 '一键':88 '三连':89 '下去':64 '了':2,10,59,65 '人':4,12,27 '人物':119 '代表':128 '先生':77 '关':13 '出镜':118 '分享':90,104 '创意':74 '剧情':122 '力气':47 '勇往直前':73 '卡':38 '压力':57 '参加':17 '参考':75 '可以':30 '同意':121 '后半段':23 '听听':68 '好':62 '姐':108 '学':107 '学长':106 '安':100 '宏':82 '小':81 '已获得':120 '希望':40,92 '开始':53 '往前':45 '感想':28 '感谢':97 '愿意':103 '所有':102,117 '打动':86 '找':1,9 '挑战':8,15,22,52 '攻略':37 '故事':105 '敬':72 '时间':48 '是':19,24 '有':85 '朋友':96 '本':126 '来':34,58 '档':32 '模仿':125 '欢迎':87 '步':39 '没有':36 '游戏':20,29 '演绎':123 '炸':83 '生存':7,16,21 '生成':113 '用于':114 '看到':95 '立场':129 '等级':56 '给':43,91 '编':63 '能':42,94 '艺术':115 '表达':116 '视频':41,84,127 '说':69 '请勿':124 '读':31 '走':46 '走过':25 '起来':14 '路':26 '轴':49 '辅助':112 '进行':5 '逗':79 '部分':109 '重':33 '野兽':76 '镜头':110 '雀巢':80 '青春':35 '风':101 '高考':6,18	bilibili	BV1Dz8v6tEMH	https://www.bilibili.com/video/BV1Dz8v6tEMH
11	AI Agent正在重走操作系统的老路	一个MCP工具号称能省98%的Context Token，社区瞬间炸锅。但深挖后我发现，这不是一个“省钱”的问题——AI Agent开发正在重演操作系统的进化史。Context就是新时代的内存，而我们还停留在手动管理阶段。一次工具调用吃掉50K token，3-4次就烧掉半个窗口。本期拆解“沙盒+索引+按需检索”架构，以及协议层的结构性缺陷。	/uploads/manuscripts/11/cover.webp	4	1	167	2	3	1	3	4	0	-1	0	\N	\N	\N	2026-03-16 22:51:00	2026-08-26 12:53:57.440235	4:31	271	'3':45 '4':46 '50k':43 '98%':13 'agent':2,26 'ai':1,25 'context':14,32 'mcp':8 'token':15,44 '停留':36 '内存':35 '协议':54 '发现':20 '号称':10 '吃掉':42 '就是':33 '层':55 '工具':9,40 '开发':27 '手动':37 '拆解':48 '操作系统':6,30 '新时代':34 '是':22 '架构':53 '检索':52 '正在':3,28 '沙':49 '深挖':19 '炸锅':18 '烧掉':47 '省':12 '省钱':23 '瞬间':17 '社区':16 '管理':38 '索引':50 '结构性':56 '缺陷':57 '老路':7 '能':11 '调用':41 '走':5 '这不':21 '进化史':31 '重':4 '重演':29 '问题':24 '阶段':39 '需':51	local		
38	谁能坚持到最后？		https://i1.hdslb.com/bfs/archive/178fb9a20436043e22baccc399fe10bf18c84b5d.jpg	118	11	3578795	410722	50094	88219	13531	11984	8748	3	1	\N	\N	\N	2026-08-24 08:59:41	2026-08-26 16:27:13.605911	01:22	82	'到':3 '坚持':2 '能':1	bilibili	BV18XhP6GExJ	https://www.bilibili.com/video/BV18XhP6GExJ
39	《海阔天空》一个人的乐队	-	https://i0.hdslb.com/bfs/archive/3a3b8e494c909dfdba62d24175746e1ecd41f052.jpg	119	11	2416659	421938	63451	37985	8960	5935	791	3	1	\N	\N	\N	2026-08-24 00:00:43	2026-08-26 16:27:13.894519	01:30	90	'个人':2 '乐队':3 '海阔天空':1	bilibili	BV1or8e6TEte	https://www.bilibili.com/video/BV1or8e6TEte
10	无限零成本token，我给OpenClaw换了个永动机芯！【小白安装教程】	本视频为无限token版本的openclaw安装教程\\r\\n任意Windows电脑均可安装 无需付费 无需高配电脑\\r\\n如果觉得视频对你有帮助 请一键三连加关注 随时关注主播最新教程\\r\\n如有问题可评论区留言或私信 随缘解答 无套路。小龙虾	/uploads/manuscripts/10/cover.webp	4	1	376	3	1	3	0	5	0	3	0	\N	\N	\N	2026-03-15 11:01:33	2026-08-27 04:34:36.903408	6:24	384	'n':23,35,51 'openclaw':5,19 'r':22,34,50 'token':3,17 'windows':24 '一键':41 '三连':42 '为':15 '主':46 '了':7 '付费':29 '关注':44,45 '加':43 '区':57 '可':26,55 '套路':64 '如':52 '安装':11,20,27 '小':65 '小白':10 '帮助':39 '成本':2 '换':6 '播':47 '教程':12,21,49 '无':63 '无限':1,16 '无需':28,30 '最新':48 '有':38,53 '本':13 '机芯':9 '永动':8 '版本':18 '电脑':25 '留言':58 '私信':59 '给':4 '缘':61 '脑':33 '视频':14,37 '觉得':36 '解答':62 '评论':56 '请':40 '配电':32 '问题':54 '随':60 '高':31 '龙虾':66	local		
40	护理：一把斩向死亡的温柔刀	从暗室孤灯到无影灯，不变的是为医学守灯的人。 两百年前，她提一盏灯走进战地炼狱，千年暗室，一灯即明；两百年后，他们守着无影灯与ICU，数着毫厘，调着微克，寸步不让。医生负责创造奇迹，而他们，负责让奇迹活下去。\n参考文献：\n[1]TURKOWSKI Y, TURKOWSKI V. Florence Nightingale (1820-1910): The Founder of Modern Nursing[J/OL]. Cureus, 2024. \n[2]PATTISON N, DEATON C, MCCABE C, et al. Florence Nightingale’s legacy for clinical academics: A framework analysis of a clinical professorial network and a model for clinical academia[J]. Journal of Clinical Nursing, 2021, 31(3-4): 353-361.\n[3]GILBERT H A. Florence Nightingale’s Environmental Theory and its influence on contemporary infection control[J]. Collegian, 2020, 27(6): 626-633.\n[4]STOLLINGS J L, KOTFIS K, CHANQUES G, et al. Delirium in critical illness: clinical manifestations, outcomes, and management[J]. Intensive Care Medicine, 2021, 47(10): 1089-1103.\n[5]Maldonado, J. R. (2017). Delirium pathophysiology: An updated hypothesis of the etiology of acute brain failure. International Journal of Geriatric Psychiatry, 33(11), 1428–1457. \n[6]MART M F, WILLIAMS ROBERSON S, SALAS B, et al. Prevention and Management of Delirium in the Intensive Care Unit[J]. Seminars in Respiratory and Critical Care Medicine, 2020, 42(01): 112-126.	https://i0.hdslb.com/bfs/archive/727eb69bd061ea85e3d174395cae41df0d0132a7.jpg	120	11	4653019	449801	27278	57769	7055	7054	6677	3	1	\N	\N	\N	2026-08-23 00:38:45	2026-08-26 16:27:14.223399	07:01	421	'01':216 '1':49 '10':156 '1089':157 '11':182 '1103':158 '112':217 '126':218 '1428':183 '1457':184 '1820':56 '1910':57 '2':67 '2017':163 '2020':126,214 '2021':102,154 '2024':66 '27':127 '3':104,108 '31':103 '33':181 '353':106 '361':107 '4':105,131 '42':215 '47':155 '5':159 '6':128,185 '626':129 '633':130 'a':83,87,92 'a.':111 'academia':96 'academics':82 'acute':173 'al':75,140,195 'an':166 'analysis':85 'and':91,117,148,197,210 'b':193 'brain':174 'c':71,73 'care':152,204,212 'chanques':137 'clinical':81,88,95,100,145 'collegian':125 'contemporary':121 'control':123 'critical':143,211 'cureus':65 'deaton':70 'delirium':141,164,200 'environmental':115 'et':74,139,194 'etiology':171 'f':188 'failure':175 'florence':54,76,112 'for':80,94 'founder':59 'framework':84 'g':138 'geriatric':179 'gilbert':109 'h':110 'hypothesis':168 'icu':32 'illness':144 'in':142,201,208 'infection':122 'influence':119 'intensive':151,203 'international':176 'its':118 'j':63,97,124,133,150,206 'j.':161 'journal':98,177 'k':136 'kotfis':135 'l':134 'legacy':79 'm':187 'maldonado':160 'management':149,198 'manifestations':146 'mart':186 'mccabe':72 'medicine':153,213 'model':93 'modern':61 'n':69 'network':90 'nightingale':55,77,113 'nursing':62,101 'of':60,86,99,169,172,178,199 'ol':64 'on':120 'outcomes':147 'pathophysiology':165 'pattison':68 'prevention':196 'professorial':89 'psychiatry':180 'r.':162 'respiratory':209 'roberson':190 's':78,114,191 'salas':192 'seminars':207 'stollings':132 'the':58,170,202 'theory':116 'turkowski':50,52 'unit':205 'updated':167 'v.':53 'williams':189 'y':51 '一灯':25 '下去':47 '不变':10 '为':12 '人':16 '刀':5 '创造':41 '到':8 '医学':13 '医生':39 '千年':23 '即':26 '参考文献':48 '奇迹':42,45 '孤灯':7 '守':14,29 '寸步不让':38 '年前':17 '年后':28 '战地':21 '护理':1 '提':18 '数':33 '斩':2 '无影灯':9,31 '明':27 '是':11 '暗室':6,24 '死亡':3 '毫厘':35 '活':46 '温柔':4 '灯':15,19 '炼狱':22 '着':30,34,37 '让':44 '调':36 '负责':40,43 '走进':20	bilibili	BV1Jv8p6kEJw	https://www.bilibili.com/video/BV1Jv8p6kEJw
45	#新概念英语	-	https://i0.hdslb.com/bfs/archive/8e37aaa3a900fe8e09cec576982f2355a764c33e.jpg	123	4	3762460	377570	2832	28801	11243	2511	6046	3	1	\N	\N	\N	2026-08-24 03:30:00	2026-08-26 16:31:07.29	00:49	49	'新概念':1 '英语':2	bilibili	BV1or8e6TEfL	https://www.bilibili.com/video/BV1or8e6TEfL
43	在凤凰古城碰到一位无臂骑手，白天跑外卖，晚上写字谋生，给经历磨难却依旧坚毅的向阳点个赞		https://i0.hdslb.com/bfs/archive/b1514b044304c6d5e35b24d1beb6a5c91eef8d46.jpg	121	11	1926236	240111	98642	14804	4317	7089	4873	3	1	\N	\N	\N	2026-08-25 09:00:00	2026-08-27 03:59:12.668465	10:41	641	'写字':10 '凤凰古城':1 '向阳':16 '坚毅':15 '外卖':8 '无':3 '晚上':9 '点':17 '白天':6 '碰到':2 '磨难':14 '经历':13 '给':12 '臂':4 '谋生':11 '赞':18 '跑':7 '骑手':5	bilibili	BV16sh36yEHP	https://www.bilibili.com/video/BV16sh36yEHP
37	源初之结首曝PV「诸神入刃，斩尽死结」	创世的神明缄默，只余破碎的秩序丝缕飘散天际。为寻劫难之源，神塑造了「织者」——却未及启迪，便坠落人间。\n你便是那迷失的“织者”。\n行走于神话尚未写就的蛮荒时代，探索诡谲奇观，结识各路英杰，对抗凶神恶兽。在诸神陨落的余晖下，追寻真相，拼凑破碎真我，直至揭开那被遗忘的秘密。\n \n本预告片包含实机演示与引擎内过场动画混合画面，均使用Unreal Engine 5 录制。\n该作品目前仍处于开发阶段，所展示的内容不代表游戏最终形态。\n\n后续更多信息，欢迎大家关注各平台游戏官方账号：@源初之结	https://i1.hdslb.com/bfs/archive/47d0bde2d984a86a369032ed8fbe8feea51d67ed.jpg	117	11	3454202	191375	100414	43287	182193	45660	20919	3	1	\N	\N	\N	2026-08-25 19:30:22	2026-08-27 04:00:10.064395	05:47	347	'5':73 'engine':72 'pv':4 'unreal':71 '下':51 '丝':15 '为':18 '之源':21 '了':24 '人间':29 '代表':84 '余晖':50 '作品':76 '使用':70 '便是':30 '信息':89 '入':6 '关注':91 '兽':47 '内容':83 '写就':36 '凶神':45 '刃':7 '动画':67 '劫难':20 '包含':62 '后续':87 '启迪':27 '坠落':28 '塑造':23 '处于':78 '天际':17 '奇观':41 '官方':94 '实':63 '对抗':44 '寻':19 '尚未':35 '尽':9 '展示':82 '平台':92 '开发':79 '引擎':65 '录制':74 '形态':86 '恶':46 '所':81 '拼凑':54 '探索':39 '揭开':57 '斩':8 '时代':38 '曝':3 '更多':88 '未及':26 '本':60 '欢迎':90 '死结':10 '混合':68 '游戏':85,93 '源':1,96 '演示':64 '画面':69 '目前':77 '直至':56 '真相':53 '破碎':13,55 '神':5,22,48 '神明':11 '神话':34 '秘密':59 '秩序':14 '织':25,32 '结':2,97 '结识':42 '缄默':12 '英杰':43 '蛮荒':37 '行走':33 '诡谲':40 '该':75 '账号':95 '过场':66 '迷失':31 '追寻':52 '遗忘':58 '阶段':80 '陨落':49 '预告片':61 '飘散':16	bilibili	BV1erhL6EE6k	https://www.bilibili.com/video/BV1erhL6EE6k
41	DNA：童年创伤，竟然真的能锁在基因里？	基因写下的，或许只是生命的初稿，而经历仍在字里行间不断批注——压力、营养，乃至童年被拥抱与安抚的方式，都可能借由甲基化，在DNA上留下细微的印记，影响基因何时沉默、何时发声。既然生命始终在被经历续写，又怎会有一种预言，能精准推断一个人的命运？\n参考文献：\n[1]EKUNDAYO B, BLEICHERT F. Origins of DNA replication[J]. PLOS Genetics, 2019, 15(9): e1008320.\n[2]Ferry, G. (2019). The structure of DNA. Nature, 575(7781), 35–36. \n[3]BĘBENEK A, ZIUZIA-GRACZYK I. Fidelity of DNA replication—a matter of proofreading[J]. Current Genetics, 2018, 64(5): 985-996.\n[4]LIU D, FREDERIKSEN J H, LIBERTI S E, et al. Human DNA polymerase delta double-mutant D316A;E318A interferes with DNA mismatch repair in vitro[J]. Nucleic Acids Research, 2017, 45(16): 9427-9440.\n[5]KRIEGER L M, ILIAKIS G. Wenn Stränge reißen – Wege der DNA-Doppelstrangbruch-Reparatur[J]. BIOspektrum, 2017, 23(5): 502-505.\n[6]STRAUSS B S. Why Is DNA Double Stranded? The Discovery of DNA Excision Repair Mechanisms[J]. Genetics, 2018, 209(2): 357-366.	https://i1.hdslb.com/bfs/archive/0607ac1cdd04f4a56ab3cf4966bc33c33fc714aa.jpg	120	11	1034980	101096	2453	15940	1741	862	1658	3	1	\N	\N	\N	2026-08-25 09:01:28	2026-08-27 04:00:17.290678	07:29	449	'1':46 '1008320':62 '15':59 '16':132 '2':63,176 '2017':130,151 '2018':92,174 '2019':58,66 '209':175 '23':152 '3':75 '316':114 '318':117 '357':177 '36':74 '366':178 '4':97 '45':131 '5':94,135,153 '502':154 '505':155 '575':72 '6':156 '64':93 '7781':73 '9':60 '9427':133 '9440':134 '985':95 '996':96 'a':78,85,115,118 'acids':128 'al':107 'b':48,76,158 'benek':77 'biospektrum':150 'bleichert':49 'current':90 'd':99,113 'delta':111 'der':147 'discovery':166 'dna':1,25,53,70,83,109,121,162,168 'dna-doppelstrangbruch-reparatur':148 'double':163 'double-mutant':112 'e':61,105,116 'ekundayo':47 'en':145 'et':106 'excision':169 'f.':50 'ferry':64 'fidelity':81 'frederiksen':100 'g.':65,140 'genetics':57,91,173 'h':102 'human':108 'i.':80 'iliakis':139 'in':124 'interferes':119 'is':161 'j':55,89,101,126,149,172 'krieger':136 'l':137 'liberti':103 'liu':98 'm':138 'matter':86 'mechanisms':171 'mismatch':122 'nature':71 'nge':143 'nucleic':127 'of':52,69,82,87,167 'origins':51 'plos':56 'polymerase':110 'proofreading':88 'rei':144 'repair':123,170 'replication':54,84 'research':129 's':104 's.':159 'str':142 'stranded':164 'strauss':157 'structure':68 'the':67,165 'vitro':125 'wege':146 'wenn':141 'why':160 'with':120 'ziuzia-graczyk':79 '上':26 '不断':14 '个人':43 '会':37 '借':23 '写下':8 '创伤':3 '初稿':11 '印记':29 '压力':16 '参考文献':45 '发声':33 '只是':9 '可能':22 '命运':44 '基因':6,7,31 '字里行间':13 '安抚':20 '影响':30 '批注':15 '拥抱':19 '推断':42 '方式':21 '有':38 '沉默':32 '生命':10,34 '甲基':24 '留下':27 '童年':2,18 '精准':41 '细微':28 '经历':12,35 '续写':36 '能':4,40 '营养':17 '锁':5 '预言':39	bilibili	BV1L9hG6CEau	https://www.bilibili.com/video/BV1L9hG6CEau
53	Attention 注意别喝多	喝东西要注意attention。别贪杯	https://i2.hdslb.com/bfs/archive/67855a089007289064ff2e952c3972d51492b17e.jpg	131	11	2399848	332730	51895	40333	8592	3206	2355	3	1	\N	\N	\N	2026-08-22 13:21:21	2026-08-26 16:27:18.106387	01:10	70	'attention':1,8 '东西':5 '喝':3,4 '注意':2,7 '要':6 '贪杯':9	bilibili	BV11S826nE2Z	https://www.bilibili.com/video/BV11S826nE2Z
51	【苏新皓｜4K直拍】Abracadabra 直拍｜重·二周年演唱会	#苏新皓 个人舞台 Abracadabra 两日合集｜重·二周年演唱会	https://i2.hdslb.com/bfs/archive/0236dffe4c84770c5ae60b5612088ff9e296ca7b.jpg	129	11	172886	49842	38371	31137	12532	59298	70856	3	1	\N	\N	\N	2026-08-26 05:01:35	2026-08-28 08:56:18.817633	05:14	314	'4k':3 'abracadabra':5,13 '个人':11 '合集':14 '新':2,10 '演唱会':8,16 '直拍':4,6 '舞台':12 '苏':1,9 '重':7,15	bilibili	BV1VJ8Q6jEgv	https://www.bilibili.com/video/BV1VJ8Q6jEgv
56	放弃一切，只为等你		https://i1.hdslb.com/bfs/archive/5626a802f321c6cb4add2957b1be973e17f3f189.jpg	134	11	4506257	209297	5617	13964	6615	2381	2093	3	1	\N	\N	\N	2026-08-23 10:57:11	2026-08-26 16:27:18.993953	02:04	124	'为':2 '放弃':1 '等':3	bilibili	BV1f38b6pE5x	https://www.bilibili.com/video/BV1f38b6pE5x
57	老吃家是怎么吃泡面的？	素材@风味杂谈	https://i0.hdslb.com/bfs/archive/a3ed5fffcfb27bb60b2590c3d02686a04bdcc608.jpg	135	11	1861846	164061	4710	101545	7130	3190	1137	3	1	\N	\N	\N	2026-08-23 14:58:36	2026-08-26 16:27:19.343013	02:14	134	'吃':2,5 '家':3 '是':4 '杂谈':9 '泡面':6 '素材':7 '老':1 '风味':8	bilibili	BV18b8h6UEAF	https://www.bilibili.com/video/BV18b8h6UEAF
47	严肃观看儿子的历史记录	没有不老的人生，只有不老的心态\n谢谢大家收看我的互联网教程【花】【花】【花】\n我正在学习奶狗音 期待实现在互联网上减龄的效果\n下期分享【合掌】【抱抱】\n【合掌】【合掌】【合掌】【合掌】\n感谢各位学员的支持！	https://i2.hdslb.com/bfs/archive/28c24920d68bd97718f88201f7fdbc401b7506a4.jpg	125	13	5518081	573198	255653	123431	50794	18944	12478	3	1	\N	\N	\N	2026-08-22 08:16:02	2026-08-30 10:25:08.316145	06:34	394	'下期':29 '严肃':1 '互联':26 '互联网':14 '人生':8 '儿子':3 '减':27 '分享':30 '历史':4 '只有':9 '合掌':31,33,34,35,36 '奶':21 '学习':20 '学员':38 '实现':25 '心态':11 '感谢':37 '抱抱':32 '支持':39 '收看':13 '效果':28 '教程':15 '期待':24 '正在':19 '没有':6 '狗':22 '老':7,10 '花':16,17,18 '观看':2 '记录':5 '谢谢':12 '音':23	bilibili	BV1Vy8r6JE9z	https://www.bilibili.com/video/BV1Vy8r6JE9z
34	《崩坏：星穹铁道》知更鸟•晴歌角色PV——「追赶风的方向」	风将吹向何方，谁也捉摸不透。\n气球又会系着我去哪漫游？\n \n中文CV：\n知更鸟•晴歌——钱琛 / 歌：Chevy\n男开拓者——秦且歌\n三月七——诺亚\n ‌\n日文CV：\n知更鸟•晴歌——名冢佳织 / 歌：Chevy\n男开拓者——榎木淳弥\n三月七——小仓唯\n ‌\n英文CV：\n知更鸟•晴歌——Alice Himora / Song vocals: Chevy\n男开拓者——Shaun Mendum\n三月七——Skyler Davenport\n ‌\n韩文CV：\n知更鸟•晴歌——신온유/ 노래: Chevy\n男开拓者——김명준\n三月七——정혜원	https://i0.hdslb.com/bfs/archive/6d5295b8b4cbc526259ce1454a53761857a5f49b.jpg	114	11	3438119	396622	175772	111019	44807	22802	23110	3	1	\N	\N	\N	2026-08-25 04:04:33	2026-08-26 16:27:12.408691	08:49	529	'alice':57 'chevy':30,45,61,74 'cv':24,38,53,70 'davenport':68 'himora':58 'mendum':65 'pv':8 'shaun':64 'skyler':67 'song':59 'vocals':60 '三月':35,50,66,77 '中文':23 '会':18 '何方':14 '佳':42 '去':21 '吹':13 '小仓':51 '崩坏':1 '开拓者':32,47,63,76 '捉摸':15 '方向':11 '日文':37 '星':2 '晴':5,26,40,55,72 '木':48 '歌':6,27,29,34,41,44,56,73 '气球':17 '淳':49 '漫游':22 '男':31,46,62,75 '着':20 '知更鸟':4,25,39,54,71 '秦':33 '系':19 '织':43 '英文':52 '角色':7 '诺亚':36 '追赶':9 '透':16 '钱':28 '铁道':3 '韩文':69 '风':10,12	bilibili	BV1oyhM6AETw	https://www.bilibili.com/video/BV1oyhM6AETw
42	理想型：你真的知道自己会喜欢谁吗？	为什么你想谈恋爱，但又常年单身？\n参考文献\n[1]  孙沛东. 谁来娶我的女儿[M/OL]. 中国社会科学出版社, 2012.\n[2]  EASTWICK P W, JOEL S. How Do People Feel About Mates?[J]. Annual Review of Psychology, 2025, 76: 385-412.\n[3]  EASTWICK P W, FINKEL E J. Sex differences in mate preferences revisited: do people know what they initially desire in a romantic partner?[J]. Journal of Personality and Social Psychology, 2008, 94(2): 245-264.\n[4]  LI N P, YONG J C, TOV W, et al., Mate preferences do predict attraction and choices in the early stages of mate selection[J]. Journal of Personality and Social Psychology, 2013, 105(5): 757-776.\n[5]  EASTWICK P W, SPARKS J, FINKEL E J, et al., A Worldwide Test of the Predictive Validity of Ideal Partner Preference-Matching[J]. Journal of personality and social psychology, 2025, 128(1): 123-146.\n[6]  JOEL S, EASTWICK P W, FINKEL E J. Is Romantic Desire Predictable? Machine Learning Applied to Initial Romantic Attraction[J]. Psychological Science, 2017, 28(10): 1478-1489.\n[7]  MATZ S C, PETERS H, CERF M, et al., Large language models can detect verbal indicators of romantic attraction[J]. Scientific Reports, 2026, 16(1): 21441.\n[8]  PROCHAZKOVA E, SJAK-SHIE E, BEHRENS F, et al., Physiological synchrony is associated with attraction in a blind date setting[J]. Nature Human Behaviour, 2022, 6(2): 269-278.\n[9]  DA SILVA FROST A, EASTWICK P W. Experimental Tests of the Role of Ideal Partner Preferences in Relationships[J]. Personality and Social Psychology Bulletin, 2026, 52(8): 2348-2363.\n[10] ZHANG J, SUN P. WHEN ARE YOU GOING TO GET MARRIED? Parental Matchmaking and Middle-Class Women in Contemporary Urban China[M]//DAVIS D S, FRIEDMAN S L. Wives, Husbands, and Lovers. Stanford: Stanford University Press, 2014: 118-144.\n[11] 杨青, 王诗勇, 徐俊杰, 等. 房子还是学历？——房价上涨与女性择偶的学历偏好[J]. 财经研究, 2021, 47(06): 154-168.\n（字数所限，未展示全部参考文献）	https://i2.hdslb.com/bfs/archive/b5a9b2255906be80a43f8c7b766fce5fb4fb344b.jpg	120	11	1160599	84088	4509	15337	4705	3042	1679	3	1	\N	\N	\N	2026-08-24 09:00:33	2026-08-26 16:27:14.787462	07:36	456	'06':323 '1':10,145,201 '10':173,262 '105':110 '11':301 '118':299 '123':146 '128':144 '144':300 '146':147 '1478':174 '1489':175 '154':324 '16':200 '168':325 '2':20,74,229 '2008':72 '2012':19 '2013':109 '2014':298 '2017':171 '2021':321 '2022':227 '2025':37,143 '2026':199,257 '21441':202 '2348':260 '2363':261 '245':75 '264':76 '269':230 '278':231 '28':172 '3':41 '385':39 '4':77 '412':40 '47':322 '5':111,114 '52':258 '6':148,228 '7':176 '757':112 '76':38 '776':113 '8':203,259 '9':232 '94':73 'a':62,125,219,236 'about':30 'al':87,124,185,211 'and':69,93,106,140,253,276,292 'annual':33 'applied':163 'are':268 'associated':215 'attraction':92,167,195,217 'behaviour':226 'behrens':208 'blind':220 'bulletin':256 'c':83,179 'can':189 'cerf':182 'china':282 'choices':94 'contemporary':280 'd':285 'da':233 'date':221 'davis':284 'desire':60,159 'detect':190 'differences':49 'do':27,54,90 'e':46,121,155,205,207 'early':97 'eastwick':21,42,115,151,237 'et':86,123,184,210 'experimental':240 'f':209 'feel':29 'finkel':45,120,154 'friedman':287 'frost':235 'get':272 'going':270 'h':181 'how':26 'human':225 'husbands':291 'ideal':133,246 'in':50,61,95,218,249,279 'indicators':192 'initial':165 'initially':59 'is':157,214 'j':32,65,82,102,119,122,136,168,196,223,251,264,318 'j.':47,156 'joel':24,149 'journal':66,103,137 'know':56 'l.':289 'language':187 'large':186 'learning':162 'li':78 'lovers':293 'm':16,183,283 'machine':161 'married':273 'matchmaking':275 'mate':51,88,100 'mates':31 'matz':177 'middle-class':277 'models':188 'n':79 'nature':224 'of':35,67,99,104,128,132,138,193,242,245 'ol':17 'p':22,43,80,116,152,238 'p.':266 'parental':274 'partner':64,134,247 'people':28,55 'personality':68,105,139,252 'peters':180 'physiological':212 'predict':91 'predictable':160 'predictive':130 'preference-matching':135 'preferences':52,89,248 'press':297 'prochazkova':204 'psychological':169 'psychology':36,71,108,142,255 'relationships':250 'reports':198 'review':34 'revisited':53 'role':244 'romantic':63,158,166,194 's':150,178,286,288 's.':25 'science':170 'scientific':197 'selection':101 'setting':222 'sex':48 'silva':234 'sjak-shie':206 'social':70,107,141,254 'sparks':118 'stages':98 'stanford':294,295 'sun':265 'synchrony':213 'test':127 'tests':241 'the':96,129,243 'they':58 'to':164,271 'tov':84 'university':296 'urban':281 'validity':131 'verbal':191 'w':23,44,85,117,153 'w.':239 'what':57 'when':267 'with':216 'wives':290 'women':278 'worldwide':126 'yong':81 'you':269 'zhang':263 '上涨':313 '中国社会科学出版社':18 '会':3 '俊杰':307 '偏好':317 '勇':305 '单身':8 '参考文献':9,330 '喜欢':4 '女儿':15 '女性':314 '娶':14 '字数':326 '孙':11 '学历':311,316 '展示':329 '常年':7 '徐':306 '想':5 '房价':312 '房子':309 '所':327 '择偶':315 '来':13 '杨青':302 '沛':12 '王':303 '理想':1 '知道':2 '研究':320 '等':308 '诗':304 '谈恋爱':6 '财经':319 '还是':310 '限':328	bilibili	BV1MXhP6GEoE	https://www.bilibili.com/video/BV1MXhP6GEoE
44	小米玄戒O3芯片前瞻上手：外星科技！	又一年新机潮开始了，这次登场的首个旗舰手机芯片是小米的玄戒O3！它的表现到底有多强？一起来看看吧……	https://i1.hdslb.com/bfs/archive/b78896f946b651f83cd437d55ccdbb945a1f3531.jpg	122	2	2049978	112902	70859	24282	30558	36662	21939	3	1	\N	\N	\N	2026-08-24 09:49:03	2026-08-26 16:31:07.288125	16:18	978	'上手':6 '了':12 '到底':22 '前瞻':5 '外星':7 '小米':1,18 '开始':11 '强':24 '戒':3,20 '手机':15 '新机':9 '旗舰':14 '是':17 '有':23 '潮':10 '玄':2,19 '登场':13 '看吧':25 '科技':8 '芯片':4,16 '表现':21	bilibili	BV1fhhP6xEMp	https://www.bilibili.com/video/BV1fhhP6xEMp
46	那个被当成毛泽东的人，日本人认错了他，但我们应该认识他！		https://i1.hdslb.com/bfs/archive/85a0487dcbb5d8edaecebf4991210482d58e99ea.jpg	124	13	3085834	210250	4091	22271	2407	998	2979	3	1	\N	\N	\N	2026-08-24 08:58:11	2026-08-26 16:31:07.291493	02:59	179	'了':7 '人':3,5 '应该':8 '当成':1 '日本':4 '毛泽东':2 '认识':9 '认错':6	bilibili	BV1S9hP66EK1	https://www.bilibili.com/video/BV1S9hP66EK1
49	搞笑疯人院：满级病友竟是大佬！大家都有病的时候，楚闻野张口闭口就喊桑九舅舅，桑九也觉得楚闻野是个好孩子，就是脑子不太好。	标题：搞笑疯人院：满级病友竟是大佬\n\n简介：\n大家都有病的时候，楚闻野张口闭口就喊桑九舅舅，桑九也觉得楚闻野是个好孩子，就是脑子不太好。直到有一天桑九当着楚闻野的面，把几个渣渣打的满地找牙。桑九骗楚闻野“我其实是个隐世高人，身负光复武林和发扬武林绝学的重任，我只告诉了你，你别告诉别人。”楚闻野嘴角一抽“你当我瞎？”说着就要扑倒桑九，桑九迅速躲远，总有刁民想泡朕！	https://i0.hdslb.com/bfs/archive/22adb8b0da98dee24b9da4dd29d8cc74ebea6bec.jpg	127	11	2992219	193715	29216	105978	24100	9577	12368	3	1	\N	\N	\N	2026-08-22 00:00:00	2026-08-26 16:27:16.91219	2:36:43	9403	'了':88 '倒':100 '光复':81 '刁民':108 '发扬':83 '告诉':87,89 '喊':16,46 '嘴角':93 '大佬':7,36 '天':61 '好':28,58 '好孩子':25,55 '就是':26,56 '张口':14,44 '当':95 '总':106 '想':109 '扑':99 '打的':69 '找':70 '抽':94 '搞笑':1,30 '时候':10,40 '是':24,54,77 '有':8,38,60,107 '标题':29 '桑':17,19,47,49,62,72,101,102 '楚':11,21,41,51,63,74,90 '武林':82,84 '泡':110 '渣':67,68 '满':3,32 '牙':71 '疯人院':2,31 '病':9,39 '病友':5,34 '直到':59 '着':98 '瞎':96 '竟是':6,35 '简介':37 '级':4,33 '绝学':85 '脑子':27,57 '舅舅':18,48 '觉得':20,50 '说':97 '身负':80 '躲':104 '迅速':103 '远':105 '重任':86 '野':13,23,43,53,65,76,92 '闭口':15,45 '闻':12,22,42,52,64,75,91 '隐':78 '面':66 '骗':73 '高人':79	bilibili	BV1j38B65Eyw	https://www.bilibili.com/video/BV1j38B65Eyw
48	经历四世轮回，只为回到你的身边		https://i1.hdslb.com/bfs/archive/65a0830a7e91ca31383430f7b8a87b4e33ee0322.jpg	126	11	6011089	179759	45318	41338	2926	1640	2376	3	1	\N	\N	\N	2026-08-24 09:03:16	2026-08-30 10:24:26.123536	33:51	2031	'为':4 '四世':2 '回到':5 '经历':1 '轮回':3	bilibili	BV16uhN68EUC	https://www.bilibili.com/video/BV16uhN68EUC
52	员工要陪老板演戏吗？我真去影视飓风上班了...	影视飓风是如今最顶流的自媒体频道，但近两年也面临着各种传言和质疑。这期视频记录了我8.13~15号以员工视角在这里的经历，时长很长承载了超多一手信息，各位看完或许可以自行评判一下：影视飓风到底是个怎样的公司？\n\n*本视频不含广告，除了一些敏感信息打码外完全真实呈现，甚至Tim在发布前都没有看过样片，各位可放心观看！\n\nBGM：\nAudiomachine - Conundrum\n李化禹 - 29号引力\nJannik - Vignette\nVeezy - Unreal\nGlacier - drifting through\nam0400 - Last Memory Before Shutdown\nMax Emanuel - Aquatic Ambience\nYouzee Music - 地球漫游指南\nUgress - Eruptive Volcano Erupts\nKKK - Moonslice（Sped Version）\nClear Sky - Only U\n凌晨一点的莱茵猫 - AURORA\nVeezy - Unreal\nI Don't Like Mondays - LEMONADE	https://i1.hdslb.com/bfs/archive/9e6d32b6503e232f780affb4efd30ca77437521c.jpg	130	11	3097134	141047	79209	48293	11029	8117	19921	3	1	\N	\N	\N	2026-08-25 04:00:00	2026-08-26 16:27:17.814049	59:09	3549	'0400':83 '15':28 '8.13':27 'am':82 'ambience':91 'aquatic':90 'audiomachine':69 'aurora':113 'before':86 'bgm':68 'clear':105 'conundrum':70 'don''t':117 'drifting':80 'emanuel':89 'eruptive':98 'erupts':100 'glacier':79 'i':116 'jannik':75 'kkk':101 'last':84 'lemonade':120 'like':118 'max':88 'memory':85 'mondays':119 'moonslice':102 'music':93 'only':107 'shutdown':87 'sky':106 'sped':103 'through':81 'tim':60 'u':108 'ugress':97 'unreal':78,115 'veezy':77,114 'version':104 'vignette':76 'volcano':99 'youzee':92 '一手':38 '上班':9 '了':10,26,36 '传言':22 '信息':39,54 '公司':48 '凌晨':109 '到底':46 '去':6 '发布':61 '可':65 '可以':42 '号':29,73 '含':51 '呈现':59 '员工':1,30 '地球':94 '如今':14 '媒体':17 '完':41 '完全':57 '广告':52 '引力':74 '影视':7,11,44 '打':55 '承载':35 '指南':96 '放心':66 '敏感':53 '时长':33 '是':13,47 '本':49 '李':71 '样片':64 '没有':62 '流':16 '演戏':5 '漫游':95 '点':110 '猫':112 '看':40 '看过':63 '真实':58 '着':21 '码':56 '禹':72 '经历':32 '老板':4 '莱茵':111 '要':2 '观看':67 '视角':31 '视频':24,50 '记录':25 '评判':43 '质疑':23 '超':37 '近':19 '长':34 '陪':3 '面临':20 '顶':15 '频道':18 '飓风':8,12,45	bilibili	BV1AxhK6BE2j	https://www.bilibili.com/video/BV1AxhK6BE2j
54	【逆天中配】超神人辉夜姬 完整版大电影	终于弄好了完整版，前八集没有的内容都加进去了。\n排除新内容之后整体来看，前面两集重新配的内容多一些，后面六集就很少了\n得下罪己诏了，本来答应大家把不好配的都配了，结果发现完整版也攻克不了，有看过直播的XD应该懂，怎么抽都抽不出来满意的。\n但辉夜姬的主线故事确实告一段落了（如果能过审的话），今后辉夜姬就会以小剧场为主（已经出了一期了）\n另外，新番也已经启航制作啦！	https://i2.hdslb.com/bfs/archive/908f0ea2477390a66da500f4d0a8c4333547ccd7.jpg	132	11	983501	84421	29731	67128	28007	4100	5916	3	1	\N	\N	\N	2026-08-24 10:57:31	2026-08-26 16:27:18.410519	2:18:02	8282	'xd':44 '一期':70 '不了':40 '不好':31 '为主':67 '主线':53 '了':13,20,26,29,34,57,69,71 '今后':62 '会':65 '内容':17,25 '出':68 '出来':49 '制作':74 '加':18 '发现':36 '启航':73 '告一段落':56 '大':10 '天':2 '姬':7,52,64 '完':8,14,37 '审':60 '小剧场':66 '应该':45 '弄好':12 '得下':27 '懂':46 '抽':47,48 '排除':21 '攻克':39 '故事':54 '整体':23 '整版':9,15,38 '新':72 '新内容':22 '有':41 '没':16 '满意':50 '电影':11 '直播':43 '看过':42 '确实':55 '神人':5 '答应':30 '结果':35 '罪':28 '能':58 '话':61 '超':4 '辉':6,51,63 '过':59 '进去':19 '逆':1 '配':3,24,32,33	bilibili	BV1v6hP6nE8e	https://www.bilibili.com/video/BV1v6hP6nE8e
55	第四集 | 🐧雷斯：“我变成御姐了？！”🐧	‼️禁止其他人转载到其他平台，发现请向UP主举报‼️\n————STAFF————\n监制：徐Toso\n动画导演：巴巴Boyei\nAIGC生成师：旁可PANKO\n编剧：皓天斯威特\n——————————\n本视频由Ai平台OiiOii制作\n体验链接：www.oiioii.ai\n注册时填写UP主的邀请码：MIVJ41DIATMSNAT\n可以获得额外的积分奖励哦！	https://i2.hdslb.com/bfs/archive/926853b2c153d31aa702090f5eca6d7f2420096f.jpg	133	11	1918015	125783	6591	34668	4596	1998	3461	3	1	\N	\N	\N	2026-08-24 09:23:17	2026-08-26 16:27:18.735234	05:10	310	'41':49 'ai':33,41 'aigc':23 'boyei':22 'diatmsnat':50 'mivj':48 'oiioii':35,40 'panko':27 'staff':15 'toso':18 'up':12,44 'www':39 '主':13,45 '举报':14 '了':5 '体验':37 '到':8 '制作':36 '动画':19 '发现':10 '变成':2 '可':26 '可以':51 '哦':55 '填写':43 '奖励':54 '姐':4 '导演':20 '巴巴':21 '师':25 '平台':9,34 '徐':17 '御':3 '斯威特':30 '本':31 '注册':42 '生成':24 '皓天':29 '监制':16 '码':47 '禁止':6 '积分':53 '编剧':28 '获得':52 '视频':32 '请':11 '转载':7 '邀请':46 '链接':38 '雷斯':1	bilibili	BV11whN6NEW1	https://www.bilibili.com/video/BV11whN6NEW1
58	325	我也不知道在燃什么\n图片素材均来自网友分享\n视频素材来自百度和b站\n剪了很久，视频制作不易，求各位多多点赞转发!\n本来想着明年3月25日再发的，但估计那个时候黄花菜都凉了，就提前发了	https://i1.hdslb.com/bfs/archive/088a4f7229aba6b980bf7adea44ea961a3737a0a.jpg	136	11	1292736	145258	10480	25179	15843	7526	1058	3	1	\N	\N	\N	2026-08-23 07:25:00	2026-08-26 16:27:19.605445	03:25	205	'325':1 'b':11 '不易':17 '久':15 '了':14,30,33 '估计':26 '凉':29 '分享':7 '剪':13 '发':25,32 '图片素材':4 '想着':22 '提前':31 '时候':27 '明年':23 '月':24 '来自':5,10 '求':18 '点':19 '燃':3 '知道':2 '站':12 '素材':9 '网友':6 '视频':8 '视频制作':16 '赞':20 '转发':21 '黄花菜':28	bilibili	BV1Wq846oExx	https://www.bilibili.com/video/BV1Wq846oExx
59	《新数码宝贝 · 全面战争》【8分钟管饱】	烧5000r，让我回回血，帮我推给你的朋友~\n希望大家喜欢我的作品~\n\n8月24日00:30分 视频源已更换，增加了15秒。	https://i0.hdslb.com/bfs/archive/afebb29008be9cc7acb6001e4cc58c6b1ccab697.jpg	137	11	1760040	86090	94396	33574	15766	4122	4596	3	1	\N	\N	\N	2026-08-23 06:13:59	2026-08-26 16:27:19.903143	08:34	514	'00':20 '5000r':8 '了':26 '全面战争':4 '分':21 '喜欢':17 '回回':10 '增加':25 '宝贝':3 '希望':16 '帮':12 '我的作品':18 '推':13 '数码':2 '新':1 '更换':24 '月':19 '朋友':15 '源':23 '烧':7 '管':5 '给':14 '血':11 '视频':22 '让':9 '饱':6	bilibili	BV1hN8t6BEMs	https://www.bilibili.com/video/BV1hN8t6BEMs
60	发给你不回消息的朋友来看	BGM:Spencer Hill Cool (feat. Dj Aaron Remix)	https://i0.hdslb.com/bfs/archive/ad4456972e99ea4ec781b4b3e447321d53b26ded.jpg	138	11	2800542	180692	11205	59534	72754	11779	733	3	1	\N	\N	\N	2026-08-24 06:01:45	2026-08-28 08:55:55.634089	01:05	65	'aaron':11 'bgm':5 'cool':8 'dj':10 'feat':9 'hill':7 'remix':12 'spencer':6 '发给':1 '回':2 '朋友':4 '消息':3	bilibili	BV1xU8v6HEr9	https://www.bilibili.com/video/BV1xU8v6HEr9
36	《无限大》定档预告丨27年1月15日全球上线	《无限大》的故事将在新启、重霄的凌云两个地方开展，你将组建属于你自己的队伍，在不同的城市之间经历冒险，最终找到故事背后的真相。游戏并不止于此，你也将自由体验不同角色的人生，不同城市的风貌与生活。#无限大定档# \n\n更多关于《无限大》的资讯请关注＞＞https://www.biligame.com/detail/?id=110895	https://i2.hdslb.com/bfs/archive/c6f6c0e1ee112630a5c97b7937648838d7128c07.jpg	116	11	8944376	297381	121608	100891	127053	52261	21195	3	1	\N	\N	\N	2026-08-25 18:26:11	2026-08-28 08:55:30.595694	12:16	736	'110895':54 'biligame':50 'com':51 'detail':52 'https':48 'id':53 'www':49 '上线':7 '不同':20,33,36 '不止':30 '两个':14 '之间':22 '人生':35 '体验':32 '全球':6 '关注':47 '冒险':24 '凌云':13 '启':11 '地方':15 '城市':21,37 '大定':41 '定':2 '属于':18 '开展':16 '找到':25 '故事':9,26 '新':10 '无限':40 '无限大':1,8,44 '更多':43 '月':5 '档':3,42 '游戏':29 '生活':39 '真相':28 '组建':17 '经历':23 '背后':27 '自由':31 '角色':34 '请':46 '资讯':45 '重霄':12 '队伍':19 '预告':4 '风貌':38	bilibili	BV15EhG6qEAg	https://www.bilibili.com/video/BV15EhG6qEAg
50	世界伊始——《伊莫》全球上线定档：PC端9月16日 移动端9月23日！	《伊莫》全球上线定档：PC端9月16日，移动端9月23日！\n广袤的天地，神奇的生物，奇妙的旅途。\n和伊莫联结合体，用全新的视角开启你的冒险之旅吧！\n\n伊莫最大的心愿就是和你一起冒险！\n现在预约《伊莫》，公测上线即可免费领取自选虹光伊莫、多套外观、稀有伊莫蛋等丰厚福利\n期待和你在艾德尔大陆相见ฅ(๑˙o˙๑)ฅ	https://i0.hdslb.com/bfs/archive/f48b84c29f43159caa84b40d2ee65dda06dee6ba.jpg	128	11	2477613	120268	43291	68771	34427	2964	831	3	1	\N	\N	\N	2026-08-26 00:00:00	2026-08-27 11:43:13.828959	07:06	426	'o':67 'pc':8,19 '上线':5,16,48 '世界':1 '丰厚':61 '之旅':38 '伊始':2 '伊莫':3,14,30,39,46,54,58 '免费':50 '全新':34 '全球':4,15 '公测':47 '冒险':37,43 '即可':49 '合体':32 '外观':56 '多套':55 '大陆':65 '天地':25 '奇妙':28 '定':6,17 '就是':42 '开启':36 '心愿':41 '旅途':29 '最大':40 '月':10,13,21,24 '期待':63 '档':7,18 '现在':44 '生物':27 '用':33 '相见':66 '神奇':26 '福利':62 '移动':11,22 '稀有':57 '端':9,12,20,23 '等':60 '联结':31 '自选':52 '艾德尔':64 '虹光':53 '蛋':59 '视角':35 '预约':45 '领取':51	bilibili	BV1wwhG6JEnc	https://www.bilibili.com/video/BV1wwhG6JEnc
\.


--
-- Data for Name: meeting_participant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meeting_participant (id, room_id, user_id, user_name, user_avatar, role, audio_enabled, video_enabled, screen_share_enabled, join_time, leave_time) FROM stdin;
\.


--
-- Data for Name: meeting_room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meeting_room (id, room_name, room_code, creator_id, creator_name, max_participants, status, start_time, end_time, scheduled_start, scheduled_end, scheduled_reason, create_time, update_time) FROM stdin;
\.


--
-- Data for Name: message_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_settings (id, user_id, private_message_notification, reply_notification, at_notification, like_notification, system_notification, created_at, updated_at) FROM stdin;
1	5	1	1	1	1	1	2026-03-27 21:00:02	2026-03-27 21:00:02
2	4	1	1	1	1	1	2026-04-10 09:45:42	2026-05-09 13:10:00
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, sender_id, receiver_id, content, is_read, created_at, updated_at, message_type, target_id, media_url, conversation_id, comment_id) FROM stdin;
11	5	4	你好	1	2026-03-17 10:39:14	2026-03-17 12:18:29	1	\N	\N	7	\N
12	5	4	你好	1	2026-03-17 10:42:41	2026-03-17 12:18:29	1	\N	\N	7	\N
13	5	6	你好兄弟	1	2026-03-17 12:25:40	2026-03-17 12:26:04	1	\N	\N	9	\N
14	6	5	你好朋友	1	2026-03-17 12:26:19	2026-03-17 12:26:31	1	\N	\N	10	\N
15	6	4	你好	1	2026-03-20 11:48:21	2026-03-28 14:22:31	1	\N	\N	11	\N
83	4	6	你好，请问找我有什么事吗	0	2026-04-10 21:00:05	2026-04-10 21:00:05	1	\N	\N	12	\N
84	4	5	你好，找我有什么事吗？	1	2026-04-12 14:47:27	2026-05-04 22:26:47	1	\N	\N	8	\N
90	5	4	在吗	1	2026-05-09 19:41:23	2026-05-16 20:35:47	1	\N	\N	7	\N
91	5	6	在吗在吗	0	2026-05-09 19:41:37	2026-05-09 19:41:37	1	\N	\N	9	\N
96	8	6	hello from testuser	0	2026-08-19 07:43:28.576126	2026-08-19 07:43:28.576126	1	\N	\N	24	\N
77	6	4	回复了你的评论：你们好😄	1	2026-04-08 12:15:00	2026-04-10 16:19:01	2	1	\N	\N	\N
78	5	4	回复了你的评论：你好	1	2026-03-30 22:10:00	2026-04-10 16:19:01	2	1	\N	\N	\N
94	5	4	回复了你：@测试用户：交流电 直流电🤨	1	2026-05-09 19:42:10	2026-05-16 20:35:54	2	14	\N	\N	7
81	4	5	您的稿件《每天学习一个电子知识，今天学习如何测电压》已通过审核并成功上架啦！	1	2026-03-18 15:00:00	2026-05-04 22:26:45	5	\N	\N	\N	\N
82	6	5	您的稿件《投篮发力差的共性和修改思路》已通过审核并成功上架啦！	1	2026-04-05 09:00:00	2026-05-04 22:26:45	5	\N	\N	\N	\N
79	5	4	您的稿件《无限零成本token，我给OpenClaw换了个永动机芯！》已通过审核并成功上架啦！	1	2026-03-15 10:00:00	2026-04-10 16:19:16	5	\N	\N	\N	\N
80	6	4	您的稿件《AI Agent正在重走操作系统的老路》已通过审核并成功上架啦！	1	2026-03-16 20:00:00	2026-04-10 16:19:16	5	\N	\N	\N	\N
42	5	4	赞了你的视频《无限零成本token，我给OpenClaw换了个永动机芯！【小白安装教程】》	1	2026-03-20 11:53:38	2026-03-28 14:22:29	4	25	\N	\N	\N
43	5	4	赞了你的视频《AI Agent正在重走操作系统的老路》	1	2026-03-16 23:19:34	2026-03-28 14:22:29	4	26	\N	\N	\N
73	5	4	赞了你的视频《无限零成本token，我给OpenClaw换了个永动机芯！【小白安装教程】	1	2026-03-20 11:53:38	2026-04-10 16:19:03	4	25	\N	\N	\N
74	5	4	赞了你的视频《AI Agent正在重走操作系统的老路》	1	2026-03-16 23:19:34	2026-04-10 16:19:03	4	26	\N	\N	\N
76	5	4	赞了你的视频《周鸿祎建议大家别只把AI当搜索引擎用》	1	2026-04-01 10:00:00	2026-04-10 16:19:03	4	27	\N	\N	\N
85	5	4	赞了你的评论\\"怎么说\\"	1	2026-05-09 14:41:56	2026-05-09 14:41:56	6	\N	\N	\N	13
86	5	4	赞了你的评论\\"crawfish\\"	1	2026-05-09 15:48:54	2026-05-09 15:48:54	6	\N	\N	\N	16
87	5	4	赞了你的评论\\"乒乓球怎么打？\\"	1	2026-05-09 17:41:06	2026-05-09 17:41:06	6	\N	\N	\N	13
89	5	4	赞了你的评论\\"你好\\"	1	2026-05-09 19:07:31	2026-05-09 19:07:31	6	\N	\N	\N	15
88	5	4	赞了你的评论\\"我会打乒乓球\\"	1	2026-05-09 17:41:09	2026-05-09 17:41:09	6	\N	\N	\N	12
92	5	4	赞了你的评论\\"哈哈哈\\"	1	2026-05-09 19:41:59	2026-05-09 19:41:59	6	\N	\N	\N	7
93	5	4	赞了你的评论\\"交流电压跟直流电压有什么区别呀？😁\\"	1	2026-05-09 19:41:59	2026-05-09 19:41:59	6	\N	\N	\N	7
95	5	4	赞了你的评论\\"crawfish\\"	1	2026-05-09 22:50:52	2026-05-09 22:50:52	6	\N	\N	\N	16
98	4	4	liked your manuscript	1	2026-08-26 13:22:40.817177	2026-08-26 13:22:40.817177	4	\N	\N	26	\N
100	4	4	liked your manuscript	1	2026-08-26 14:03:34.623904	2026-08-26 14:03:34.623904	4	\N	\N	26	\N
97	5	4	liked your comment	1	2026-08-26 06:50:18.797072	2026-08-26 06:50:18.797072	6	\N	\N	7	\N
101	5	6	测试红点	0	2026-08-27 05:26:57.453492	2026-08-27 05:26:57.453492	1	\N	\N	9	\N
99	4	5	测试私信	1	2026-08-26 13:47:55.656855	2026-08-26 13:47:55.656855	1	\N	\N	8	\N
102	4	5	来自string的消息	1	2026-08-27 05:27:10.522742	2026-08-27 05:27:10.522742	1	\N	\N	8	\N
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, type, title, content, from_user_id, target_id, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: operation_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operation_tasks (id, task_key, task_type, task_name, target_type, target_id, status, progress, stage, message, error_message, operator_id, operator_name, started_at, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, name, code, url, method, parent_id, description, create_time, update_time) FROM stdin;
12	会议管理	meeting:manage	/meeting	GET	\N	会议室管理权限	2026-05-31 00:00:00	2026-05-31 00:00:00
4	分类管理	category:manage	/categories	GET	\N	增删改视频分类	2026-03-06 20:47:32	2026-03-06 20:47:32
5	标签管理	tag:manage	/tags	GET	\N	增删改标签	2026-03-06 20:47:32	2026-03-06 20:47:32
6	内容审核	review:manage	/review	GET	\N	审核稿件/评论/举报	2026-03-06 20:47:32	2026-03-06 20:47:32
7	统计查看	statistics:manage	/statistics	GET	\N	查看仪表盘统计	2026-03-06 20:47:32	2026-03-06 20:47:32
8	角色管理	role:manage	/roles	GET	\N	增删改角色/岗位模板	2026-03-06 20:47:32	2026-03-06 20:47:32
9	管理员管理	admin:manage	/admin	GET	\N	增删改管理员/分配角色	2026-05-31 00:00:00	2026-05-31 00:00:00
10	安全设置	security:manage	/security-settings	GET	\N	修改安全策略/登录日志	2026-05-31 00:00:00	2026-05-31 00:00:00
11	直播管理	live:manage	/live	GET	\N	管理直播间/强制下播	2026-05-31 00:00:00	2026-05-31 00:00:00
13	存储管理	storage:manage	/storage	POST	\N	触发存储迁移	2026-05-31 00:00:00	2026-05-31 00:00:00
14	轮播图管理	banner:manage	/banner-images	GET	\N	增删改轮播图/背景图	2026-05-31 00:00:00	2026-05-31 00:00:00
15	搜索管理	search:manage	/search/admin/index	GET	\N	管理搜索索引/推荐配置	2026-05-31 00:00:00	2026-05-31 00:00:00
16	AI 管理	ai:manage	/ai	GET	\N	管理 AI 渠道/技能/用量	2026-05-31 00:00:00	2026-05-31 00:00:00
17	消息管理	message:manage	/message	POST	\N	发送系统通知/公告	2026-05-31 00:00:00	2026-05-31 00:00:00
18	审计日志	audit:manage	/audit-logs	GET	\N	查看审计日志	2026-05-31 00:00:00	2026-05-31 00:00:00
19	运营任务	operation:manage	/operation-tasks	GET	\N	查看/管理运营任务	2026-05-31 00:00:00	2026-05-31 00:00:00
38	定时任务	scheduled:manage	\N	\N	\N	管理定时任务	2026-08-25 09:11:35.353052	2026-08-25 09:11:35.353052
39	转码配置	transcode:manage	\N	\N	\N	修改转码编码器配置	2026-08-25 09:11:35.354827	2026-08-25 09:11:35.354827
40	字幕管理	subtitle:manage	\N	\N	\N	管理字幕上传/审核	2026-08-25 09:11:35.356493	2026-08-25 09:11:35.356493
1	用户管理	user:manage	/users	GET	\N	查询/禁用/重置密码用户	2026-03-06 20:47:32	2026-03-06 20:47:32
2	稿件管理	video:manage	/videos	GET	\N	查询/审核/发布/下架稿件	2026-03-06 20:47:32	2026-03-06 20:47:32
3	评论管理	comment:manage	/comments	GET	\N	删除/审核评论	2026-03-06 20:47:32	2026-03-06 20:47:32
\.


--
-- Data for Name: prohibited_word; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prohibited_word (id, word, match_type, category, is_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: prohibited_words; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prohibited_words (id, word, match_type, category, is_enabled, created_at, updated_at) FROM stdin;
1	骗子	CONTAINS	FRAUD	1	2026-04-24 15:08:49	2026-04-24 15:08:49
2	傻子	EXACT	OTHER	1	2026-04-24 15:08:49	2026-04-24 15:08:49
3	广告	CONTAINS	AD	1	2026-04-24 15:08:49	2026-04-24 15:08:49
4	政治敏感	CONTAINS	POLITICS	1	2026-04-24 15:08:49	2026-04-24 15:08:49
5	测试违禁词	CONTAINS	TEST	0	2026-04-24 15:08:49	2026-04-24 15:08:49
\.


--
-- Data for Name: recommend_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recommend_configs (id, config_key, config_json, updated_by, created_at, updated_at) FROM stdin;
1	default	{"refresh_interval":300,"for_you_size":20,"related_size":10,"hot_size":10,"personalized":true}	admin	2026-08-18 10:05:30.223553+00	2026-08-18 10:05:30.223553+00
\.


--
-- Data for Name: replies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.replies (id, comment_id, user_id, content, like_count, created_at, updated_at, reply_to_user_id, status) FROM stdin;
2	3	4	@string：你好	0	2026-03-15 14:23:40	2026-03-15 14:23:40	4	NORMAL
3	6	4	测试	0	2026-03-16 21:56:39	2026-03-16 21:56:39	\N	NORMAL
4	6	4	@string：@string 测试	0	2026-03-16 22:13:13	2026-03-16 22:13:13	4	NORMAL
5	6	4	@string：测试	0	2026-03-16 22:19:09	2026-03-16 22:19:09	4	NORMAL
6	3	5	你好	0	2026-03-22 20:30:08	2026-03-22 20:30:08	\N	NORMAL
7	7	4	哈哈哈	1	2026-04-10 17:53:39	2026-05-09 19:41:59	\N	NORMAL
8	9	4	数学如何快速提分？	1	2026-04-10 18:06:33	2026-04-10 18:25:29	\N	NORMAL
9	9	4	数学如何快速提分？	0	2026-04-10 18:06:52	2026-04-10 18:06:52	\N	NORMAL
10	9	4	大家是怎么学数学的?	0	2026-04-10 18:16:28	2026-04-10 18:16:28	\N	NORMAL
11	13	4	怎么说	1	2026-05-02 14:18:26	2026-05-09 14:41:56	\N	NORMAL
12	15	5	😗😗😗	1	2026-05-09 19:07:41	2026-05-09 19:07:46	\N	NORMAL
13	7	5	@测试用户：交流电 直流电🤨	0	2026-05-09 19:42:10	2026-05-09 19:42:10	4	NORMAL
16	3	4	测试回复扫描	0	2026-08-26 13:27:13.764631	2026-08-26 13:27:13.764631	\N	NORMAL
17	3	4	测试回复时间	0	2026-08-26 13:32:26.200681	2026-08-26 13:32:26.200681	\N	NORMAL
1	3	4	你好	2	2026-03-15 14:23:33	2026-03-15 14:23:33	\N	NORMAL
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (id, reporter_id, target_type, target_id, manuscript_id, reason, description, status, admin_remark, created_at, processed_at, ai_review_status, ai_verdict, ai_risk_level, ai_reviewed_at) FROM stdin;
1	5	MANUSCRIPT	27	27	欺诈诈骗	引战	PENDING	\N	2026-05-09 19:31:22	\N	PENDING	\N	\N	\N
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
1	1
2	1
1	2
2	2
1	3
2	3
1	4
1	5
1	6
2	6
1	7
2	7
1	8
1	9
1	10
1	11
2	11
1	12
2	12
1	13
1	14
1	15
1	16
2	16
1	17
1	18
2	18
1	19
2	19
1	38
1	39
1	40
4	6
4	3
7	9
7	8
7	10
3	2
3	4
3	11
3	14
3	15
3	19
3	38
3	40
8	1
8	17
8	19
9	7
9	18
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, create_time, update_time) FROM stdin;
1	超级管理员	拥有所有权限	2026-03-06 20:46:56	2026-03-06 20:46:56
2	普通管理员	拥有基本管理权限	2026-03-06 20:46:56	2026-03-06 20:46:56
3	平台运营	平台运营 岗位	2026-08-25 09:35:03.367744	2026-08-25 09:35:03.367744
4	内容审核	内容审核 岗位	2026-08-25 09:35:03.390962	2026-08-25 09:35:03.390962
7	系统管理	系统管理 岗位	2026-08-25 09:35:03.457905	2026-08-25 09:35:03.457905
8	客服专员	处理工单、客服会话与系统通知	2026-08-25 13:15:37.347367	2026-08-25 13:15:37.347367
9	数据分析员	只读查看统计数据与审计日志	2026-08-25 13:15:37.347367	2026-08-25 13:15:37.347367
\.


--
-- Data for Name: scheduled_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scheduled_tasks (id, task_key, task_name, description, cron_expr, task_type, task_config, enabled, last_run_at, last_run_result, last_run_message, next_run_at, run_count, max_retries, retry_count, timeout_seconds, created_at, updated_at) FROM stdin;
1	hot_search_cleanup	热搜清理	清理过期热搜数据，保留前100条	0 0 3 * * ?	hot_search_cleanup		1	2026-08-30 10:22:42.704301+00	success	hot search expired entries cleaned	2026-08-31 03:00:00+00	11	3	0	30	2026-08-24 15:48:18.090116+00	2026-08-30 10:22:42.704301+00
\.


--
-- Data for Name: shares; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shares (id, user_id, manuscript_id, channel, ip_address, create_time) FROM stdin;
1	4	29	unknown	\N	2026-05-01 13:29:26
2	4	29	unknown	\N	2026-05-02 14:17:56
3	4	29	unknown	\N	2026-05-02 14:18:01
4	4	29	unknown	\N	2026-05-02 14:20:44
5	4	29	unknown	\N	2026-05-02 14:20:51
6	4	11	unknown	\N	2026-05-08 15:05:53
7	5	29	unknown	\N	2026-05-09 14:45:17
8	5	29	unknown	\N	2026-05-09 14:45:30
9	5	12	unknown	\N	2026-05-09 15:48:49
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, ticket_no, user_id, session_id, source, category, priority, status, title, content, entry_reply, admin_reply, assignee_admin_id, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_configs (config_key, config_value, updated_at, updated_by) FROM stdin;
transcode_encoder	auto	2026-08-26 13:36:33.770475	1
security_settings	{"login_policy":{"ip_whitelist_enabled":false,"lockout_minutes":30,"max_attempts":5,"session_timeout_min":480,"two_factor_required":false},"password_policy":{"max_age_days":90,"min_length":8,"require_digit":true,"require_lower":true,"require_special":false,"require_upper":true}}	2026-08-26 14:10:35.959609	1
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, name, created_at, updated_at) FROM stdin;
-2111918079	AI	2026-05-09 23:38:34	2026-05-09 23:38:34
-2044809214	github	2026-05-09 23:38:34	2026-05-09 23:38:34
-1650552831	训练	2026-04-03 19:12:28	2026-04-03 19:12:28
-1587638271	乒乓球	2026-04-03 19:12:28	2026-04-03 19:12:28
-161566718	线性代数	2026-05-09 22:54:22	2026-05-09 22:54:22
-161566717	线代	2026-05-09 22:54:22	2026-05-09 22:54:22
-98652158	高数	2026-05-09 22:54:22	2026-05-09 22:54:22
-98652157	数学	2026-05-09 22:54:22	2026-05-09 22:54:22
1	原神	2026-03-02 18:28:07	2026-03-02 18:28:07
2	我的世界	2026-03-02 18:28:07	2026-03-02 18:28:07
3	英雄联盟	2026-03-02 18:28:07	2026-03-02 18:28:07
4	鬼畜视频	2026-03-02 18:28:07	2026-03-02 18:28:07
5	美食制作	2026-03-02 18:28:07	2026-03-02 18:28:07
6	动漫推荐	2026-03-02 18:28:07	2026-03-02 18:28:07
7	游戏攻略	2026-03-02 18:28:07	2026-03-02 18:28:07
8	音乐MV	2026-03-02 18:28:07	2026-03-02 18:28:07
9	舞蹈教学	2026-03-02 18:28:07	2026-03-02 18:28:07
10	科技测评	2026-03-02 18:28:07	2026-03-02 18:28:07
11	生活日常	2026-03-02 18:28:07	2026-03-02 18:28:07
12	旅行	2026-03-02 18:28:07	2026-03-02 18:28:07
13	健身	2026-03-02 18:28:07	2026-03-02 18:28:07
14	学习	2026-03-02 18:28:07	2026-03-02 18:28:07
15	职场	2026-03-02 18:28:07	2026-03-02 18:28:07
16	string	2026-03-04 00:02:23	2026-03-04 00:02:23
17	11	2026-03-09 14:43:26	2026-03-09 14:43:26
18	123	2026-03-09 15:52:29	2026-03-09 15:52:29
19	uioi	2026-03-09 15:53:37	2026-03-09 15:53:37
20	111	2026-03-09 17:30:02	2026-03-09 17:30:02
21	9999	2026-03-09 17:31:01	2026-03-09 17:31:01
22	999	2026-03-09 17:31:01	2026-03-09 17:31:01
23	5555	2026-03-11 12:46:05	2026-03-11 12:46:05
24	555	2026-03-11 15:35:16	2026-03-11 15:35:16
25	1	2026-03-14 22:36:01	2026-03-14 22:36:01
26	篮球	2026-03-20 20:12:18	2026-03-20 20:12:18
27	投篮	2026-03-20 20:12:18	2026-03-20 20:12:18
28	运动	2026-03-20 20:12:18	2026-03-20 20:12:18
29	体育	2026-03-20 20:12:18	2026-03-20 20:12:18
400424961	人工智能	2026-05-10 08:05:27	2026-05-10 08:05:27
438173698	开源	2026-05-10 08:05:27	2026-05-10 08:05:27
2120134657	软件	2026-05-09 23:38:34	2026-05-09 23:38:34
\.


--
-- Data for Name: upload_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.upload_sessions (id, user_id, title, description, category_id, tags, videos, uploaded_chunks, total_chunks, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_dynamics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_dynamics (id, user_id, content, dynamic_type, image_url, ref_manuscript_id, like_count, comment_count, share_count, created_at, status) FROM stdin;
2	6	大家好	0	\N	\N	1	1	0	2026-03-20 11:52:09	0
1520365569	5	海思芯片	1	/uploads/manuscripts/10/cover.webp	\N	1	0	0	2026-05-05 22:24:51	0
3	5	😀😀😀AI agent	2	/uploads/images/20260320152632_cc7c57ed-539c-4e58-a15c-211b194cacc8.webp	12	3	5	3	2026-03-20 15:26:33	0
-576823294	4	hermes agent	1	\N	\N	6	0	0	2026-05-09 23:32:37	0
1	4	6666	0	\N	\N	4	6	1	2026-03-07 12:15:24	0
\.


--
-- Data for Name: user_interactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_interactions (id, user_id, target_type, target_id, interaction_type, created_at) FROM stdin;
15	4	MANUSCRIPT	10	LIKE	2026-03-16 17:15:11
29	4	DYNAMIC	1	LIKE	2026-03-16 21:27:11
31	5	MANUSCRIPT	11	LIKE	2026-03-16 23:19:34
32	5	MANUSCRIPT	12	LIKE	2026-03-17 11:57:40
35	4	COMMENT	6	LIKE	2026-03-19 20:32:07
36	5	MANUSCRIPT	14	LIKE	2026-03-19 21:48:30
37	4	MANUSCRIPT	14	LIKE	2026-03-20 11:15:41
39	6	USER	5	FOLLOW	2026-03-20 11:47:54
40	6	USER	4	FOLLOW	2026-03-20 11:47:59
42	5	MANUSCRIPT	10	COLLECT	2026-03-20 12:00:48
43	5	MANUSCRIPT	12	COLLECT	2026-03-20 12:00:57
44	5	MANUSCRIPT	13	COLLECT	2026-03-20 12:01:05
45	5	MANUSCRIPT	13	LIKE	2026-03-20 12:01:06
46	5	MANUSCRIPT	14	COLLECT	2026-03-20 14:03:20
48	5	MANUSCRIPT	11	COLLECT	2026-03-20 20:30:38
2037433097214943234	1	MANUSCRIPT	10	LIKE	2026-03-27 15:34:38
2037435642637352962	1	MANUSCRIPT	10	COLLECT	2026-03-27 15:44:45
2037533243521048577	5	MANUSCRIPT	10	LIKE	2026-03-27 22:12:35
2037777389754122242	4	MANUSCRIPT	13	LIKE	2026-03-28 14:22:44
2037778383862890497	4	MANUSCRIPT	14	COLLECT	2026-03-28 14:26:41
2038926608628125698	5	COMMENT	3	LIKE	2026-03-31 18:29:19
2041375449751134209	4	DYNAMIC_COMMENT	2	LIKE	2026-04-07 12:40:08
2041505816273395714	4	DYNAMIC_COMMENT	1	LIKE	2026-04-07 21:18:10
2042129247121657857	4	MANUSCRIPT	12	LIKE	2026-04-09 14:35:28
2042544719495352322	4	COMMENT	9	LIKE	2026-04-10 18:06:24
2042549522392862721	4	REPLY	8	LIKE	2026-04-10 18:25:29
2042550318928941058	4	MANUSCRIPT	10	COIN	2026-04-10 18:28:39
2042820136252936194	4	MANUSCRIPT	11	COIN	2026-04-11 12:20:48
2049405363599355905	4	COMMENT	16	LIKE	2026-04-29 16:28:09
2049423707421470722	5	MANUSCRIPT	29	LIKE	2026-04-29 17:41:02
2049503931651805185	4	MANUSCRIPT	27	LIKE	2026-04-29 22:59:49
2049727135955755010	4	DYNAMIC_COMMENT	10	LIKE	2026-04-30 13:46:45
2049727211285454849	4	DYNAMIC_COMMENT	11	LIKE	2026-04-30 13:47:03
2049861294334361602	4	MANUSCRIPT	29	COIN	2026-04-30 22:39:51
2049861351209123842	4	MANUSCRIPT	29	COLLECT	2026-04-30 22:40:05
2049861654306308098	4	COMMENT	12	LIKE	2026-04-30 22:41:17
2049865328583720962	4	COMMENT	13	LIKE	2026-04-30 22:55:53
2050085165146738689	4	MANUSCRIPT	29	SHARE	2026-05-01 13:29:26
2050460485855141890	4	MANUSCRIPT	29	LIKE	2026-05-02 14:20:50
2050590400021749761	4	DYNAMIC_COMMENT	16	LIKE	2026-05-02 22:57:04
2052037123977973762	5	user	4	follow	2026-05-06 22:45:50
2052053913630101506	5	COMMENT	10	LIKE	2026-05-06 23:52:33
2052646150667677698	4	MANUSCRIPT	11	SHARE	2026-05-08 15:05:53
2052979238669025282	4	user	5	follow	2026-05-09 13:09:27
2053002510399918081	5	REPLY	11	LIKE	2026-05-09 14:41:56
2053003356332314625	5	MANUSCRIPT	29	SHARE	2026-05-09 14:45:17
2053019345874800642	5	MANUSCRIPT	12	SHARE	2026-05-09 15:48:49
2053019363348271105	5	COMMENT	16	LIKE	2026-05-09 15:48:54
2053035215422390274	5	MANUSCRIPT	27	LIKE	2026-05-09 16:51:53
2053035313002872833	5	MANUSCRIPT	27	COLLECT	2026-05-09 16:52:16
2053047614149943297	5	COMMENT	12	LIKE	2026-05-09 17:41:09
2053069347250688001	5	COMMENT	15	LIKE	2026-05-09 19:07:31
2053069412103016449	5	REPLY	12	LIKE	2026-05-09 19:07:46
2053078020538646529	5	REPLY	7	LIKE	2026-05-09 19:41:59
2053078023940227073	5	COMMENT	7	LIKE	2026-05-09 19:41:59
2053116048023904258	-69271551	MANUSCRIPT	14	LIKE	2026-05-09 22:13:05
2053116721885020162	-69271551	user	5	follow	2026-05-09 22:15:46
2053143553313259522	4	MANUSCRIPT	31	LIKE	2026-05-10 00:02:23
2053143553313259537	4	REPLY	1	LIKE	2026-08-26 08:45:12.268988
2053143553313259541	4	DYNAMIC_COMMENT	9	LIKE	2026-08-26 09:23:50.913021
2053143553313259550	4	COMMENT	999999	LIKE	2026-08-26 13:27:13.85743
2053143553313259551	4	MANUSCRIPT	11	LIKE	2026-08-26 14:03:34.61053
2053143553313259552	4	COMMENT	7	LIKE	2026-08-26 14:09:59.783096
\.


--
-- Data for Name: user_privacy_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_privacy_settings (id, user_id, public_collection, public_birthday_tags, public_coin_videos, public_like_videos, public_following_list, public_followers_list, created_at, updated_at) FROM stdin;
-2145452031	-1767964670	1	0	0	0	0	0	2026-05-20 22:45:34	2026-05-20 22:45:34
-2019622911	-69271551	1	0	0	0	0	0	2026-05-09 22:12:46	2026-05-09 22:12:46
-1906376703	4	1	0	0	0	0	0	2026-05-02 17:55:22	2026-05-02 17:55:22
-1713426431	5	1	0	0	0	0	0	2026-05-04 22:26:50	2026-05-04 22:26:50
\.


--
-- Data for Name: user_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_tags (id, user_id, tag_name, created_at) FROM stdin;
-1629548543	5	全栈工程师	2026-05-06 22:45:16
-731967487	5	前端开发者	2026-05-06 22:45:09
752762881	4	程序员	2026-05-03 23:07:56
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, nickname, avatar, email, phone, gender, signature, birthdate, level, following_count, follower_count, manuscript_count, liked_count, coin_count, created_at, updated_at, status, pinned_video_id, experience, bio, announcement) FROM stdin;
113	up_525952604	4b5672f5bb247c330566711716a5f61567c75cdde7e4a3f27d715d310797d830	柯洁	https://i2.hdslb.com/bfs/face/7c2103f936383451c15866bf4097d62c045845ce.jpg	up_525952604@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:12.080344	2026-08-26 16:27:12.080344	1	\N	0	\N	\N
114	up_1340190821	17a78e244c17752a02003b55c7bef866ef87c084afaea9735c3ab1cd234ea13b	崩坏星穹铁道	https://i2.hdslb.com/bfs/face/1336282f4138c9fd870fe75281de1441125a64c9.jpg	up_1340190821@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:12.399364	2026-08-26 16:27:12.399364	1	\N	0	\N	\N
115	up_5970160	a7d265689bf1e52f099f86bda14f55c0becc7ba60a447063b45ebe76a1bf6fb6	小潮院长	https://i1.hdslb.com/bfs/face/16420925b50153f99935c5415bddb2acecfea877.jpg	up_5970160@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:12.68499	2026-08-26 16:27:12.68499	1	\N	0	\N	\N
116	up_3494379073309365	5d4596476d7b6c290a952f2982e8ddc4939b2cd2249100f19c4b1d5b41d887f9	无限大	https://i0.hdslb.com/bfs/face/354f81e2d54c7ff3481727244f71989db225d23e.jpg	up_3494379073309365@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:12.989104	2026-08-26 16:27:12.989104	1	\N	0	\N	\N
117	up_3706979079949044	aa362b039d599d8904263df679e76a133d0c50456842c80ec39f2ce2088f37dc	源初之结	https://i0.hdslb.com/bfs/face/acf39beb56780b7ee96ca9b60674343672e48bd3.jpg	up_3706979079949044@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:13.301142	2026-08-26 16:27:13.301142	1	\N	0	\N	\N
118	up_27501480	593a2dbea1100ebfe515701722da721ff485760790c6ddab16457986483547d4	怠惰的一休	https://i0.hdslb.com/bfs/face/542bff8a6d26dbf1ff8fe2cb4856a124bfafebd2.jpg	up_27501480@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:13.596715	2026-08-26 16:27:13.596715	1	\N	0	\N	\N
119	up_3461573630757421	fd1c9c02769f9463eb64ce599a14d1d30d197ccc7f29e88b958c7eea211f61b5	罗应星一个人的乐队	https://i1.hdslb.com/bfs/face/72cd6928757cde14fd7c9a2f642a00e2a7426081.jpg	up_3461573630757421@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:13.885024	2026-08-26 16:27:13.885024	1	\N	0	\N	\N
120	up_1208823126	2ab685b51f2449070ebac20404f14ce523784ef965a2079cae9b83e667d89692	大圆镜科普	https://i0.hdslb.com/bfs/face/9c34ee4b8041dd6f2139c52287c8d34a0a42f230.jpg	up_1208823126@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:14.21433	2026-08-26 16:27:14.21433	1	\N	0	\N	\N
121	up_3493260093819171	b143e920260dc1b29b3cf3b5cd7699d0d4191b986c331ed100a97d479c7ae6b7	李维刚的日常	https://i0.hdslb.com/bfs/face/4917c09bdfd5e72f08a04d2c752de48a848a1318.jpg	up_3493260093819171@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:15.085852	2026-08-26 16:27:15.085852	1	\N	0	\N	\N
122	up_25876945	fda7d52e1f1fe8f00937c5fa04c216bdf92623c72787134273ee2218fd610e48	极客湾Geekerwan	http://i1.hdslb.com/bfs/face/d0f7a7ee34a4a45c8390eb3a07e4d7f2d70bae91.jpg	up_25876945@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:15.391222	2026-08-26 16:27:15.391222	1	\N	0	\N	\N
123	up_2085146802	96402090c9740eb084c8eacecad3f506b85aeb33301710ef194f196f732edc85	阿战吃不饱	https://i0.hdslb.com/bfs/face/c22636df38734f802edaaa2004d412bc3b734e33.jpg	up_2085146802@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:15.708005	2026-08-26 16:27:15.708005	1	\N	0	\N	\N
124	up_404194769	8b17079da30c812a8e6ea794b71a6165fd4fe4bec1ca8bc8921a5336f5688d05	了不起De中国人	https://i2.hdslb.com/bfs/face/1b1f8ef7427502ead39a9af2498c9616c6c164ff.jpg	up_404194769@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:15.995341	2026-08-26 16:27:15.995341	1	\N	0	\N	\N
125	up_5294454	d39ec38db1822cb703102793aaf6ea1dc5b8df06b457da0b3c3c223937cbaf8d	逗比的雀巢	https://i0.hdslb.com/bfs/face/e56d8c14d3b74b4e32fbaf2ac4af119328c56c93.jpg	up_5294454@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:16.370321	2026-08-26 16:27:16.370321	1	\N	0	\N	\N
126	up_3546722569553936	ef6b898b2bcc9f7ec66e5e6610715f436a9430302170da4231fe3a59030be258	赏月电影	https://i2.hdslb.com/bfs/face/b405590639146b00af60d5762b344c73d5899b03.jpg	up_3546722569553936@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:16.592976	2026-08-26 16:27:16.592976	1	\N	0	\N	\N
127	up_3706945844283495	4722e464f5978c0ed7ea0a8d957182152fb52631451b5e39a2c69d2603434872	修仙摆烂王	https://i0.hdslb.com/bfs/face/ad602522f84e1fe9c112ff640983ecbbd72e010f.jpg	up_3706945844283495@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:16.902965	2026-08-26 16:27:16.902965	1	\N	0	\N	\N
7	stringstring	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	字符串用户	/uploads/avatars/7/avatar.webp	stringstring@example.com	\N	0		\N	1	0	0	0	0	0	2026-05-20 23:34:50	2026-08-22 10:35:36.366142	1	\N	0		\N
128	up_3546868241926891	4103c693ab6b73b75ea472090e62737701f97027c46f07fdd76d6cd7cde0083b	伊莫	https://i1.hdslb.com/bfs/face/9ca04892baae8d140181a03f86850e7f4f63612f.jpg	up_3546868241926891@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:17.201837	2026-08-26 16:27:17.201837	1	\N	0	\N	\N
6	admin	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	管理员	/uploads/avatars/6/avatar.webp	admin@example.com	11111111111	\N		2026-03-19	1	0	0	0	0	211	2026-03-17 09:00:05	2026-08-22 10:35:36.366142	1	\N	0		\N
129	up_3546749647980910	1d11792e4953698282eaec3223b8316a04b7fb05809f2ee5e6f0e96da28a6ce6	JUSTSU_苏新皓	https://i1.hdslb.com/bfs/face/94189b31cd41413e7d92b8ea11ff95460b3dc28c.jpg	up_3546749647980910@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:17.601759	2026-08-26 16:27:17.601759	1	\N	0	\N	\N
8	testuser	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	测试账号	\N		\N	0		\N	1	0	0	0	0	0	2026-08-19 04:39:19.173099	2026-08-22 10:35:36.366142	0	\N	0	\N	\N
130	up_125526	978c7e602f484c0010b3694f9e984d4a024e8251d84fdce479bc55dd3b89293d	-LKs-	https://i0.hdslb.com/bfs/baselabs/36b604fe51629dd111d129fa4e7d95937e72442e.jpg	up_125526@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:17.804761	2026-08-26 16:27:17.804761	1	\N	0	\N	\N
131	up_165835953	22e522928723b1fd1461f6c9013ee602b9886b545c93d36ee95f40dfc57469b5	莫梓艺大笑	https://i0.hdslb.com/bfs/face/e9a44a4e646a734c8bba031afaa06e557dfbdee6.jpg	up_165835953@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:18.097019	2026-08-26 16:27:18.097019	1	\N	0	\N	\N
132	up_3691000713185700	ec7b8a50783d44d755ab1f6817e65dce969c16ca447ff4dc5e051afa6e646236	咖啡大慕斯	https://i0.hdslb.com/bfs/face/5e156ed2935bde433e9f607aff418ec8833abeaa.jpg	up_3691000713185700@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:18.401025	2026-08-26 16:27:18.401025	1	\N	0	\N	\N
133	up_2175690	0b9e2a2a08691d5fba154feadd6e220afb70f2b468461089868ee2c0b22426d9	徐Toso	https://i0.hdslb.com/bfs/face/5779df7e2182bba5160fd813e4cba02b8e13e9d4.jpg	up_2175690@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:18.725928	2026-08-26 16:27:18.725928	1	\N	0	\N	\N
134	up_624708064	9d9368b8f9fb041e7303313d852b14cf4d7b3ee6450eb04ad378159dabba1b13	三金啊GC	https://i1.hdslb.com/bfs/face/3d38f73e6a5e1fa2681a969e52f0925241514925.jpg	up_624708064@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:18.990549	2026-08-26 16:27:18.990549	1	\N	0	\N	\N
135	up_3707029503871721	0a2d4c5c9948c1107285a561a363cc968efef2fbac64bb4d6d7f10dc2eb76b40	华南有志弹涂鱼	https://i2.hdslb.com/bfs/face/6bd1fa8944dc1c5f0d61fe53410e819f9ce21731.jpg	up_3707029503871721@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:19.333764	2026-08-26 16:27:19.333764	1	\N	0	\N	\N
4	string	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	小明	/uploads/avatars/4/avatar.webp	string@example.com	13011011111	2	你好朋友们6666	2026-03-17	1	0	1	0	11	207	2026-03-02 22:31:41	2026-08-26 13:32:26.219025	1	27	78		999
136	up_385304483	c4bb79079bf7d413ad458e59a5bef0fcfe41165e4bb89a4e9ddedb4db0638413	我才不是嘉年	https://i2.hdslb.com/bfs/face/b1ee55b8764de3cd73b184424fee2168ff5a37a8.jpg	up_385304483@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:19.596177	2026-08-26 16:27:19.596177	1	\N	0	\N	\N
137	up_38802989	a07db6501fc6193dbe5d18f2544568bef9ff6691726710be32e7b5ddc2ccd6f8	不睡的彻	https://i2.hdslb.com/bfs/face/53d7403d313d3cf674677e9e8df48c9e5ce1259c.jpg	up_38802989@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:19.893994	2026-08-26 16:27:19.893994	1	\N	0	\N	\N
138	up_6054967	e55210e4bccef6fa3f52e5c5c1d2ebc77aeb46c81f8d0d87fcaae8ee2348924f	茶咩cc	https://i1.hdslb.com/bfs/face/f3f9a5df359070704faa1b068f4679c0c10398c4.jpg	up_6054967@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:20.215559	2026-08-26 16:27:20.215559	1	\N	0	\N	\N
139	up_430426421	ccb26cb0295a5d381bd225e3ac4efa1110c6d811839275c674eae4f4fb20ea35	燕三嘤嘤嘤	https://i2.hdslb.com/bfs/face/dc4d4dee16c8f19340ec3d880b456c8677c7ff09.jpg	up_430426421@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:20.492846	2026-08-26 16:27:20.492846	1	\N	0	\N	\N
140	up_1648293359	31befbc22b60cce473b28f94f111c30069ca2210f46d8d8ba8459fa49760fb67	不是闲的	https://i2.hdslb.com/bfs/face/682a980acc95c366f98b7d04f3f0f85cac99d730.jpg	up_1648293359@up.local	\N	0		\N	1	0	0	0	0	0	2026-08-26 16:27:20.872853	2026-08-26 16:27:20.872853	1	\N	0	\N	\N
5	test	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	test666	/uploads/avatars/5/avatar.webp	test@example.com	17733311111	1	这是测试签名	2026-03-09	1	1	0	0	13	213	2026-03-04 20:48:47	2026-08-26 14:17:44.631075	1	14	14	666	这是测试公告
\.


--
-- Data for Name: verification_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_codes (id, identifier, code_type, code_value, expires_at, used, created_at) FROM stdin;
1	1787056859298244533	captcha	34	2026-08-18 12:45:59.299328+00	0	2026-08-18 12:40:59.299328+00
2	1787114458544023727	captcha	68	2026-08-19 04:45:58.54535+00	0	2026-08-19 04:40:58.54535+00
3	1787674908039828739	captcha	63	2026-08-25 16:26:48.040781+00	0	2026-08-25 16:21:48.040781+00
4	1787714152228133034	captcha	40	2026-08-26 03:20:52.229138+00	1	2026-08-26 03:15:52.229138+00
5	1787714247240142542	captcha	64	2026-08-26 03:22:27.24109+00	0	2026-08-26 03:17:27.24109+00
6	1787714254348294291	captcha	29	2026-08-26 03:22:34.349042+00	1	2026-08-26 03:17:34.349042+00
7	1787714388455632896	captcha	28	2026-08-26 03:24:48.45642+00	0	2026-08-26 03:19:48.45642+00
8	1787714391657167864	captcha	19	2026-08-26 03:24:51.657786+00	1	2026-08-26 03:19:51.657786+00
9	1787723881589511163	captcha	47	2026-08-26 06:03:01.590399+00	1	2026-08-26 05:58:01.590399+00
10	1787749894307136328	captcha	38	2026-08-26 13:16:34.307899+00	1	2026-08-26 13:11:34.307899+00
11	1787980561208871254	captcha	29	2026-08-29 05:21:01.217359+00	1	2026-08-29 05:16:01.217359+00
12	1788085446469188704	captcha	89	2026-08-30 10:29:06.470006+00	1	2026-08-30 10:24:06.470006+00
\.


--
-- Data for Name: video_process_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.video_process_events (id, video_id, manuscript_id, from_status, to_status, stage, progress, error_message, operator_type, operator_id, created_at) FROM stdin;
\.


--
-- Data for Name: video_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.video_tags (id, video_id, tag_id, created_at) FROM stdin;
1	29	20	2026-03-16 23:20:36
2	30	20	2026-03-16 23:23:05
3	31	20	2026-03-16 23:28:28
9	34	26	2026-04-03 18:02:58
10	36	-1650552831	2026-04-03 19:12:28
11	36	-1587638271	2026-04-03 19:12:28
16	38	2120134657	2026-05-09 23:38:34
17	38	-2111918079	2026-05-09 23:38:34
18	38	-2044809214	2026-05-09 23:38:34
19	39	400424961	2026-05-10 08:05:27
20	39	2120134657	2026-05-10 08:05:27
21	39	438173698	2026-05-10 08:05:27
\.


--
-- Data for Name: videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.videos (id, manuscript_id, video_order, title, play_url_hd, play_url_sd, play_url_ld, upload_time, updated_at, process_progress, process_stage, has_subtitle, has_summary, process_status, process_error, source_video_url, duration_seconds, is_vertical, cid) FROM stdin;
25	10	0	无限零成本token，我给OpenClaw换了个永动机芯！【小白安装教程】	/uploads/manuscripts/10/videos/25/transcoded/1080p/playlist.m3u8	/uploads/manuscripts/10/videos/25/transcoded/720p/playlist.m3u8	/uploads/manuscripts/10/videos/25/transcoded/480p/playlist.m3u8	2026-03-15 11:01:32	2026-08-27 15:24:35.829977	100	done	1	1	5		/uploads/manuscripts/10/videos/25/source/video.mp4	384	0	0
39	32	0	开源Skills	/uploads/manuscripts/32/videos/39/transcoded/1080p/playlist.m3u8	/uploads/manuscripts/32/videos/39/transcoded/720p/playlist.m3u8	/uploads/manuscripts/32/videos/39/transcoded/1080p/playlist.m3u8	2026-05-10 08:05:28	2026-08-27 04:32:22.689233	100	done	1	1	5	\N	file:///tmp/work-test/source.mp4	27	0	0
34	27	0	投篮力线错误？这样改！	/uploads/manuscripts/27/videos/34/transcoded/720p/playlist.m3u8	/uploads/manuscripts/27/videos/34/transcoded/720p/playlist.m3u8	/uploads/manuscripts/27/videos/34/transcoded/720p/playlist.m3u8	2026-04-03 18:02:58	2026-08-27 04:32:22.689233	100	AI_SUCCESS	1	1	5	\N	/uploads/manuscripts/27/videos/34/source/video.mp4	69	1	0
36	29	0	9	/uploads/manuscripts/29/videos/36/transcoded/720p/playlist.m3u8	/uploads/manuscripts/29/videos/36/transcoded/720p/playlist.m3u8	/uploads/manuscripts/29/videos/36/transcoded/720p/playlist.m3u8	2026-04-03 19:12:28	2026-08-27 04:32:22.689233	100	AI_SUCCESS	1	1	5	\N	/uploads/manuscripts/29/videos/36/source/video.mp4	38	1	0
27	11	1	谁在给AI投毒？GEO灰产是如何割韭菜的？	/uploads/manuscripts/11/videos/27/transcoded/720p/playlist.m3u8	/uploads/manuscripts/11/videos/27/transcoded/720p/playlist.m3u8	/uploads/manuscripts/11/videos/27/transcoded/720p/playlist.m3u8	2026-03-16 22:50:59	2026-08-27 04:32:22.689233	0	\N	0	1	5	\N	/uploads/manuscripts/11/videos/27/source/video.mp4	230	0	0
26	11	0	AI Agent正在重走操作系统的老路	/uploads/manuscripts/11/videos/26/transcoded/720p/playlist.m3u8	/uploads/manuscripts/11/videos/26/transcoded/720p/playlist.m3u8	/uploads/manuscripts/11/videos/26/transcoded/720p/playlist.m3u8	2026-03-16 22:50:59	2026-08-27 04:32:22.689233	0	\N	0	1	5	\N	/uploads/manuscripts/11/videos/26/source/video.mp4	271	0	0
62	55	0	第四集 | 🐧雷斯：“我变成御姐了？！”🐧	/api/v1/bili/stream/62?qn=80	/api/v1/bili/stream/62?qn=64	/api/v1/bili/stream/62?qn=32	2026-08-26 16:27:18.737561	2026-08-26 16:27:18.737561	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV11whN6NEW1	310	0	41218869662
63	56	0	放弃一切，只为等你	/api/v1/bili/stream/63?qn=80	/api/v1/bili/stream/63?qn=64	/api/v1/bili/stream/63?qn=32	2026-08-26 16:27:18.996122	2026-08-26 16:27:18.996122	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1f38b6pE5x	124	0	41189575833
64	57	0	老吃家是怎么吃泡面的？	/api/v1/bili/stream/64?qn=80	/api/v1/bili/stream/64?qn=64	/api/v1/bili/stream/64?qn=32	2026-08-26 16:27:19.345119	2026-08-26 16:27:19.345119	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV18b8h6UEAF	134	0	41075605760
65	58	0	325	/api/v1/bili/stream/65?qn=80	/api/v1/bili/stream/65?qn=64	/api/v1/bili/stream/65?qn=32	2026-08-26 16:27:19.607551	2026-08-26 16:27:19.607551	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1Wq846oExx	205	0	41184659681
38	31	0	github短视频生成工具	/uploads/manuscripts/31/videos/38/transcoded/720p/playlist.m3u8	/uploads/manuscripts/31/videos/38/transcoded/720p/playlist.m3u8	\N	2026-05-09 23:38:34	2026-05-09 23:54:47	0	AI_SUCCESS	1	1	5	\N	/uploads/manuscripts/31/videos/38/source/video.mp4	47	0	0
30	13	0	数学怎么提分	/uploads/manuscripts/13/videos/30/transcoded/720p/playlist.m3u8	/uploads/manuscripts/13/videos/30/transcoded/720p/playlist.m3u8	/uploads/manuscripts/13/videos/30/transcoded/720p/playlist.m3u8	2026-03-16 23:23:05	2026-08-27 04:32:22.689233	0	\N	0	1	5	\N	/uploads/manuscripts/13/videos/30/source/video.mp4	71	1	0
29	12	0	把 OpenClaw 翻译成“小龙虾”的，出来挨打！	/uploads/manuscripts/12/videos/29/transcoded/720p/playlist.m3u8	/uploads/manuscripts/12/videos/29/transcoded/720p/playlist.m3u8	/uploads/manuscripts/12/videos/29/transcoded/720p/playlist.m3u8	2026-03-16 23:20:36	2026-08-27 04:32:22.689233	0	\N	0	1	5	\N	/uploads/manuscripts/12/videos/29/source/video.mp4	196	0	0
31	14	0	每天学习一个电子知识，今天学习如何测电压	/uploads/manuscripts/14/videos/31/transcoded/720p/playlist.m3u8	/uploads/manuscripts/14/videos/31/transcoded/720p/playlist.m3u8	/uploads/manuscripts/14/videos/31/transcoded/720p/playlist.m3u8	2026-03-16 23:28:28	2026-08-27 04:32:22.689233	0	\N	1	1	5	\N	/uploads/manuscripts/14/videos/31/source/video.mp4	26	0	0
28	11	2	周鸿祎建议大家别只把AI当搜索引擎用	/uploads/manuscripts/11/videos/28/transcoded/720p/playlist.m3u8	/uploads/manuscripts/11/videos/28/transcoded/720p/playlist.m3u8	/uploads/manuscripts/11/videos/28/transcoded/720p/playlist.m3u8	2026-03-16 22:50:59	2026-08-27 04:32:22.689233	0	\N	1	1	5	\N	/uploads/manuscripts/11/videos/28/source/video.mp4	155	1	0
40	33	0	王中王夺冠自战解说	/api/v1/bili/stream/40?qn=80	/api/v1/bili/stream/40?qn=64	/api/v1/bili/stream/40?qn=32	2026-08-26 16:27:12.104143	2026-08-26 16:27:12.104143	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1PEhP6vERe	2746	0	41221752321
66	59	0	《新数码宝贝 · 全面战争》【8分钟管饱】	/api/v1/bili/stream/66?qn=80	/api/v1/bili/stream/66?qn=64	/api/v1/bili/stream/66?qn=32	2026-08-26 16:27:19.905757	2026-08-26 16:27:19.905757	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1hN8t6BEMs	514	0	41198485543
67	60	0	发给你不回消息的朋友来看	/api/v1/bili/stream/67?qn=80	/api/v1/bili/stream/67?qn=64	/api/v1/bili/stream/67?qn=32	2026-08-26 16:27:20.227381	2026-08-26 16:27:20.227381	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1xU8v6HEr9	65	0	41212381037
68	61	0	以色列狠狠压力美国	/api/v1/bili/stream/68?qn=80	/api/v1/bili/stream/68?qn=64	/api/v1/bili/stream/68?qn=32	2026-08-26 16:27:20.506281	2026-08-26 16:27:20.506281	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1rg8Y6zET2	1305	0	41207728211
42	35	0	贱谍过家家（8）	/api/v1/bili/stream/42?qn=80	/api/v1/bili/stream/42?qn=64	/api/v1/bili/stream/42?qn=32	2026-08-26 16:27:12.699837	2026-08-26 16:27:12.699837	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1gLhK6LEcb	1566	0	41227780241
69	62	0	我找了3000人进行高考生存挑战！	/api/v1/bili/stream/69?qn=80	/api/v1/bili/stream/69?qn=64	/api/v1/bili/stream/69?qn=32	2026-08-26 16:27:20.888337	2026-08-26 16:27:20.888337	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1Dz8v6tEMH	301	0	41211268620
41	34	0	《崩坏：星穹铁道》知更鸟•晴歌角色PV——「追赶风的方向」	/api/v1/bili/stream/41?qn=80	/api/v1/bili/stream/41?qn=64	/api/v1/bili/stream/41?qn=32	2026-08-26 16:27:12.43668	2026-08-26 16:27:12.43668	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1oyhM6AETw	529	0	41238137532
43	36	0	《无限大》定档预告丨27年1月15日全球上线	/api/v1/bili/stream/43?qn=80	/api/v1/bili/stream/43?qn=64	/api/v1/bili/stream/43?qn=32	2026-08-26 16:27:12.996298	2026-08-26 16:27:12.996298	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV15EhG6qEAg	736	0	41250393999
44	37	0	源初之结首曝PV「诸神入刃，斩尽死结」	/api/v1/bili/stream/44?qn=80	/api/v1/bili/stream/44?qn=64	/api/v1/bili/stream/44?qn=32	2026-08-26 16:27:13.316118	2026-08-26 16:27:13.316118	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1erhL6EE6k	347	0	41265598212
45	38	0	谁能坚持到最后？	/api/v1/bili/stream/45?qn=80	/api/v1/bili/stream/45?qn=64	/api/v1/bili/stream/45?qn=32	2026-08-26 16:27:13.608059	2026-08-26 16:27:13.608059	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV18XhP6GExJ	82	0	41218214400
46	39	0	《海阔天空》一个人的乐队	/api/v1/bili/stream/46?qn=80	/api/v1/bili/stream/46?qn=64	/api/v1/bili/stream/46?qn=32	2026-08-26 16:27:13.896594	2026-08-26 16:27:13.896594	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1or8e6TEte	90	0	41203991774
47	40	0	护理：一把斩向死亡的温柔刀	/api/v1/bili/stream/47?qn=80	/api/v1/bili/stream/47?qn=64	/api/v1/bili/stream/47?qn=32	2026-08-26 16:27:14.227659	2026-08-26 16:27:14.227659	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1Jv8p6kEJw	421	0	41175154836
48	41	0	DNA：童年创伤，竟然真的能锁在基因里？	/api/v1/bili/stream/48?qn=80	/api/v1/bili/stream/48?qn=64	/api/v1/bili/stream/48?qn=32	2026-08-26 16:27:14.502437	2026-08-26 16:27:14.502437	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1L9hG6CEau	449	0	41249737643
49	42	0	理想型：你真的知道自己会喜欢谁吗？	/api/v1/bili/stream/49?qn=80	/api/v1/bili/stream/49?qn=64	/api/v1/bili/stream/49?qn=32	2026-08-26 16:27:14.798545	2026-08-26 16:27:14.798545	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1MXhP6GEoE	456	0	41217953286
50	43	0	在凤凰古城碰到一位无臂骑手，白天跑外卖，晚上写字谋生，给经历磨难却依旧坚毅的向阳点个赞	/api/v1/bili/stream/50?qn=80	/api/v1/bili/stream/50?qn=64	/api/v1/bili/stream/50?qn=32	2026-08-26 16:27:15.097693	2026-08-26 16:27:15.097693	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV16sh36yEHP	641	0	41238660256
51	44	0	小米玄戒O3芯片前瞻上手：外星科技！	/api/v1/bili/stream/51?qn=80	/api/v1/bili/stream/51?qn=64	/api/v1/bili/stream/51?qn=32	2026-08-26 16:27:15.395027	2026-08-26 16:27:15.395027	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1fhhP6xEMp	978	0	41223195265
52	45	0	#新概念英语	/api/v1/bili/stream/52?qn=80	/api/v1/bili/stream/52?qn=64	/api/v1/bili/stream/52?qn=32	2026-08-26 16:27:15.719082	2026-08-26 16:27:15.719082	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1or8e6TEfL	49	0	41204057594
53	46	0	那个被当成毛泽东的人，日本人认错了他，但我们应该认识他！	/api/v1/bili/stream/53?qn=80	/api/v1/bili/stream/53?qn=64	/api/v1/bili/stream/53?qn=32	2026-08-26 16:27:16.007091	2026-08-26 16:27:16.007091	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1S9hP66EK1	179	0	41218082864
54	47	0	严肃观看儿子的历史记录	/api/v1/bili/stream/54?qn=80	/api/v1/bili/stream/54?qn=64	/api/v1/bili/stream/54?qn=32	2026-08-26 16:27:16.382898	2026-08-26 16:27:16.382898	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1Vy8r6JE9z	394	0	41155759236
55	48	0	经历四世轮回，只为回到你的身边	/api/v1/bili/stream/55?qn=80	/api/v1/bili/stream/55?qn=64	/api/v1/bili/stream/55?qn=32	2026-08-26 16:27:16.604205	2026-08-26 16:27:16.604205	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV16uhN68EUC	2031	0	41218147117
56	49	0	搞笑疯人院：满级病友竟是大佬！大家都有病的时候，楚闻野张口闭口就喊桑九舅舅，桑九也觉得楚闻野是个好孩子，就是脑子不太好。	/api/v1/bili/stream/56?qn=80	/api/v1/bili/stream/56?qn=64	/api/v1/bili/stream/56?qn=32	2026-08-26 16:27:16.915179	2026-08-26 16:27:16.915179	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1j38B65Eyw	9403	0	41137472268
57	50	0	世界伊始——《伊莫》全球上线定档：PC端9月16日 移动端9月23日！	/api/v1/bili/stream/57?qn=80	/api/v1/bili/stream/57?qn=64	/api/v1/bili/stream/57?qn=32	2026-08-26 16:27:17.206209	2026-08-26 16:27:17.206209	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1wwhG6JEnc	426	0	41266184941
58	51	0	【苏新皓｜4K直拍】Abracadabra 直拍｜重·二周年演唱会	/api/v1/bili/stream/58?qn=80	/api/v1/bili/stream/58?qn=64	/api/v1/bili/stream/58?qn=32	2026-08-26 16:27:17.613067	2026-08-26 16:27:17.613067	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1VJ8Q6jEgv	314	0	41274180287
59	52	0	员工要陪老板演戏吗？我真去影视飓风上班了...	/api/v1/bili/stream/59?qn=80	/api/v1/bili/stream/59?qn=64	/api/v1/bili/stream/59?qn=32	2026-08-26 16:27:17.816863	2026-08-26 16:27:17.816863	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1AxhK6BE2j	3549	0	41227062041
60	53	0	Attention 注意别喝多	/api/v1/bili/stream/60?qn=80	/api/v1/bili/stream/60?qn=64	/api/v1/bili/stream/60?qn=32	2026-08-26 16:27:18.108355	2026-08-26 16:27:18.108355	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV11S826nE2Z	70	0	41164212683
61	54	0	【逆天中配】超神人辉夜姬 完整版大电影	/api/v1/bili/stream/61?qn=80	/api/v1/bili/stream/61?qn=64	/api/v1/bili/stream/61?qn=32	2026-08-26 16:27:18.413554	2026-08-26 16:27:18.413554	0	\N	0	0	5	\N	https://www.bilibili.com/video/BV1v6hP6nE8e	8282	0	41219261585
\.


--
-- Data for Name: watch_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.watch_history (id, user_id, manuscript_id, progress_seconds, watched_at) FROM stdin;
59	4	40	0	2026-08-27 09:59:03.3324+00
54	4	43	0	2026-08-27 09:59:45.968778+00
62	4	54	0	2026-08-27 11:43:03.05129+00
58	4	55	0	2026-08-27 11:43:13.221825+00
65	4	57	0	2026-08-27 11:43:42.523349+00
66	5	55	13	2026-08-30 10:24:55.676054+00
67	5	54	156	2026-08-30 10:25:12.450453+00
26	5	31	0	2026-08-25 14:44:47.778923+00
28	5	29	11	2026-08-26 02:36:19.997475+00
24	4	31	0	2026-08-26 04:47:44.33324+00
22	4	29	89	2026-08-26 12:37:49.414353+00
\.


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 8, true);


--
-- Name: ai_api_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_api_configs_id_seq', 1, false);


--
-- Name: ai_bindings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_bindings_id_seq', 1, false);


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_chat_messages_id_seq', 1, false);


--
-- Name: ai_conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_conversations_id_seq', 1, false);


--
-- Name: ai_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_sessions_id_seq', 1, false);


--
-- Name: ai_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_skills_id_seq', 1, false);


--
-- Name: ai_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_usage_logs_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 3, true);


--
-- Name: banner_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.banner_images_id_seq', 6, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 23, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_id_seq', 21, true);


--
-- Name: content_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.content_reviews_id_seq', 4, true);


--
-- Name: conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.conversations_id_seq', 30, true);


--
-- Name: creator_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.creator_settings_id_seq', 2, true);


--
-- Name: danmaku_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.danmaku_id_seq', 27, true);


--
-- Name: dynamic_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamic_comments_id_seq', 19, true);


--
-- Name: dynamic_likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dynamic_likes_id_seq', 12, true);


--
-- Name: favorite_folder_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_folder_videos_id_seq', 17, true);


--
-- Name: favorite_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_folders_id_seq', 16, true);


--
-- Name: favorite_manuscripts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.favorite_manuscripts_id_seq', 35, true);


--
-- Name: follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.follows_id_seq', 7, true);


--
-- Name: live_linkmic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.live_linkmic_id_seq', 1, false);


--
-- Name: live_rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.live_rooms_id_seq', 2, true);


--
-- Name: live_seats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.live_seats_id_seq', 1, false);


--
-- Name: login_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.login_logs_id_seq', 64, true);


--
-- Name: manuscript_collection_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manuscript_collection_relations_id_seq', 1637826567, true);


--
-- Name: manuscript_collections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manuscript_collections_id_seq', 1444888590, true);


--
-- Name: manuscript_edit_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manuscript_edit_versions_id_seq', 1, false);


--
-- Name: manuscript_status_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manuscript_status_events_id_seq', 1, false);


--
-- Name: manuscripts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manuscripts_id_seq', 62, true);


--
-- Name: meeting_participant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meeting_participant_id_seq', 1, false);


--
-- Name: meeting_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meeting_room_id_seq', 1, false);


--
-- Name: message_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.message_settings_id_seq', 2, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.messages_id_seq', 102, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: operation_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.operation_tasks_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.permissions_id_seq', 2056, true);


--
-- Name: prohibited_word_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prohibited_word_id_seq', 1, false);


--
-- Name: prohibited_words_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.prohibited_words_id_seq', 8, true);


--
-- Name: recommend_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recommend_configs_id_seq', 2, true);


--
-- Name: replies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.replies_id_seq', 17, true);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 10, true);


--
-- Name: scheduled_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scheduled_tasks_id_seq', 1, true);


--
-- Name: shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shares_id_seq', 9, true);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 2, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tags_id_seq', 2120134657, true);


--
-- Name: user_dynamics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_dynamics_id_seq', 1520365570, true);


--
-- Name: user_interactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_interactions_id_seq', 2053143553313259552, true);


--
-- Name: user_privacy_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_privacy_settings_id_seq', 1, true);


--
-- Name: user_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_tags_id_seq', 752762881, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 140, true);


--
-- Name: verification_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.verification_codes_id_seq', 12, true);


--
-- Name: video_process_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.video_process_events_id_seq', 1, false);


--
-- Name: video_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.video_tags_id_seq', 21, true);


--
-- Name: videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.videos_id_seq', 69, true);


--
-- Name: watch_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.watch_history_id_seq', 67, true);


--
-- Name: admin_user_roles admin_user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_user_roles
    ADD CONSTRAINT admin_user_roles_pkey PRIMARY KEY (admin_user_id, role_id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_username UNIQUE (username);


--
-- Name: ai_api_configs ai_api_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_api_configs
    ADD CONSTRAINT ai_api_configs_pkey PRIMARY KEY (id);


--
-- Name: ai_bindings ai_bindings_feature_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_bindings
    ADD CONSTRAINT ai_bindings_feature_key UNIQUE (feature);


--
-- Name: ai_bindings ai_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_bindings
    ADD CONSTRAINT ai_bindings_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_conversations ai_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_conversations
    ADD CONSTRAINT ai_conversations_pkey PRIMARY KEY (id);


--
-- Name: ai_sessions ai_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_sessions
    ADD CONSTRAINT ai_sessions_pkey PRIMARY KEY (id);


--
-- Name: ai_skills ai_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_skills
    ADD CONSTRAINT ai_skills_pkey PRIMARY KEY (id);


--
-- Name: ai_usage_logs ai_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_usage_logs
    ADD CONSTRAINT ai_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: banner_images banner_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.banner_images
    ADD CONSTRAINT banner_images_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: content_reviews content_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.content_reviews
    ADD CONSTRAINT content_reviews_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_uk_user_target; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_uk_user_target UNIQUE (user_id, target_user_id);


--
-- Name: creator_settings creator_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creator_settings
    ADD CONSTRAINT creator_settings_pkey PRIMARY KEY (id);


--
-- Name: creator_settings creator_settings_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creator_settings
    ADD CONSTRAINT creator_settings_user_id UNIQUE (user_id);


--
-- Name: danmaku danmaku_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.danmaku
    ADD CONSTRAINT danmaku_pkey PRIMARY KEY (id);


--
-- Name: dynamic_comments dynamic_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_comments
    ADD CONSTRAINT dynamic_comments_pkey PRIMARY KEY (id);


--
-- Name: dynamic_likes dynamic_likes_dynamic_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_likes
    ADD CONSTRAINT dynamic_likes_dynamic_id_user_id_key UNIQUE (dynamic_id, user_id);


--
-- Name: dynamic_likes dynamic_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_likes
    ADD CONSTRAINT dynamic_likes_pkey PRIMARY KEY (id);


--
-- Name: favorite_folder_videos favorite_folder_videos_folder_id_manuscript_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folder_videos
    ADD CONSTRAINT favorite_folder_videos_folder_id_manuscript_id_key UNIQUE (folder_id, manuscript_id);


--
-- Name: favorite_folder_videos favorite_folder_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folder_videos
    ADD CONSTRAINT favorite_folder_videos_pkey PRIMARY KEY (id);


--
-- Name: favorite_folders favorite_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folders
    ADD CONSTRAINT favorite_folders_pkey PRIMARY KEY (id);


--
-- Name: favorite_folders favorite_folders_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folders
    ADD CONSTRAINT favorite_folders_user_id UNIQUE (user_id, name);


--
-- Name: favorite_manuscripts favorite_manuscripts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_manuscripts
    ADD CONSTRAINT favorite_manuscripts_pkey PRIMARY KEY (id);


--
-- Name: favorite_manuscripts favorite_manuscripts_uk_folder_manuscript; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_manuscripts
    ADD CONSTRAINT favorite_manuscripts_uk_folder_manuscript UNIQUE (folder_id, manuscript_id);


--
-- Name: follows follows_follower_id_following_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_following_id_key UNIQUE (follower_id, following_id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: jsonb_documents jsonb_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jsonb_documents
    ADD CONSTRAINT jsonb_documents_pkey PRIMARY KEY (collection_name, id);


--
-- Name: live_linkmic live_linkmic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_linkmic
    ADD CONSTRAINT live_linkmic_pkey PRIMARY KEY (id);


--
-- Name: live_rooms live_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_rooms
    ADD CONSTRAINT live_rooms_pkey PRIMARY KEY (id);


--
-- Name: live_rooms live_rooms_uk_stream_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_rooms
    ADD CONSTRAINT live_rooms_uk_stream_key UNIQUE (stream_key);


--
-- Name: live_seats live_seats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_seats
    ADD CONSTRAINT live_seats_pkey PRIMARY KEY (id);


--
-- Name: live_seats live_seats_room_id_seat_index_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_seats
    ADD CONSTRAINT live_seats_room_id_seat_index_key UNIQUE (room_id, seat_index);


--
-- Name: login_logs login_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_logs
    ADD CONSTRAINT login_logs_pkey PRIMARY KEY (id);


--
-- Name: manuscript_collection_relations manuscript_collection_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_collection_relations
    ADD CONSTRAINT manuscript_collection_relations_pkey PRIMARY KEY (id);


--
-- Name: manuscript_collection_relations manuscript_collection_relations_uk_manuscript_collection; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_collection_relations
    ADD CONSTRAINT manuscript_collection_relations_uk_manuscript_collection UNIQUE (manuscript_id, collection_id);


--
-- Name: manuscript_collections manuscript_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_collections
    ADD CONSTRAINT manuscript_collections_pkey PRIMARY KEY (id);


--
-- Name: manuscript_daily_metrics manuscript_daily_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_daily_metrics
    ADD CONSTRAINT manuscript_daily_metrics_pkey PRIMARY KEY (metric_date, manuscript_id);


--
-- Name: manuscript_edit_versions manuscript_edit_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_edit_versions
    ADD CONSTRAINT manuscript_edit_versions_pkey PRIMARY KEY (id);


--
-- Name: manuscript_status_events manuscript_status_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_status_events
    ADD CONSTRAINT manuscript_status_events_pkey PRIMARY KEY (id);


--
-- Name: manuscripts manuscripts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscripts
    ADD CONSTRAINT manuscripts_pkey PRIMARY KEY (id);


--
-- Name: meeting_participant meeting_participant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meeting_participant
    ADD CONSTRAINT meeting_participant_pkey PRIMARY KEY (id);


--
-- Name: meeting_room meeting_room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meeting_room
    ADD CONSTRAINT meeting_room_pkey PRIMARY KEY (id);


--
-- Name: meeting_room meeting_room_room_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meeting_room
    ADD CONSTRAINT meeting_room_room_code UNIQUE (room_code);


--
-- Name: message_settings message_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_settings
    ADD CONSTRAINT message_settings_pkey PRIMARY KEY (id);


--
-- Name: message_settings message_settings_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_settings
    ADD CONSTRAINT message_settings_user_id UNIQUE (user_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: operation_tasks operation_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_tasks
    ADD CONSTRAINT operation_tasks_pkey PRIMARY KEY (id);


--
-- Name: operation_tasks operation_tasks_uk_operation_task_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operation_tasks
    ADD CONSTRAINT operation_tasks_uk_operation_task_key UNIQUE (task_key);


--
-- Name: permissions permissions_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code UNIQUE (code);


--
-- Name: permissions permissions_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: prohibited_word prohibited_word_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prohibited_word
    ADD CONSTRAINT prohibited_word_pkey PRIMARY KEY (id);


--
-- Name: prohibited_word prohibited_word_uk_word; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prohibited_word
    ADD CONSTRAINT prohibited_word_uk_word UNIQUE (word);


--
-- Name: prohibited_words prohibited_words_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prohibited_words
    ADD CONSTRAINT prohibited_words_pkey PRIMARY KEY (id);


--
-- Name: recommend_configs recommend_configs_config_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommend_configs
    ADD CONSTRAINT recommend_configs_config_key_key UNIQUE (config_key);


--
-- Name: recommend_configs recommend_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recommend_configs
    ADD CONSTRAINT recommend_configs_pkey PRIMARY KEY (id);


--
-- Name: replies replies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scheduled_tasks scheduled_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_tasks
    ADD CONSTRAINT scheduled_tasks_pkey PRIMARY KEY (id);


--
-- Name: scheduled_tasks scheduled_tasks_task_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scheduled_tasks
    ADD CONSTRAINT scheduled_tasks_task_key_key UNIQUE (task_key);


--
-- Name: shares shares_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shares
    ADD CONSTRAINT shares_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_no_key UNIQUE (ticket_no);


--
-- Name: system_configs system_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_configs
    ADD CONSTRAINT system_configs_pkey PRIMARY KEY (config_key);


--
-- Name: tags tags_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: upload_sessions upload_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.upload_sessions
    ADD CONSTRAINT upload_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_dynamics user_dynamics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dynamics
    ADD CONSTRAINT user_dynamics_pkey PRIMARY KEY (id);


--
-- Name: user_interactions user_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_interactions
    ADD CONSTRAINT user_interactions_pkey PRIMARY KEY (id);


--
-- Name: user_interactions user_interactions_uk_user_interaction; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_interactions
    ADD CONSTRAINT user_interactions_uk_user_interaction UNIQUE (user_id, target_type, target_id, interaction_type);


--
-- Name: user_privacy_settings user_privacy_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_privacy_settings
    ADD CONSTRAINT user_privacy_settings_pkey PRIMARY KEY (id);


--
-- Name: user_privacy_settings user_privacy_settings_uk_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_privacy_settings
    ADD CONSTRAINT user_privacy_settings_uk_user_id UNIQUE (user_id);


--
-- Name: user_tags user_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tags
    ADD CONSTRAINT user_tags_pkey PRIMARY KEY (id);


--
-- Name: user_tags user_tags_uk_user_tag; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tags
    ADD CONSTRAINT user_tags_uk_user_tag UNIQUE (user_id, tag_name);


--
-- Name: users users_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email UNIQUE (email);


--
-- Name: users users_phone; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username UNIQUE (username);


--
-- Name: verification_codes verification_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_codes
    ADD CONSTRAINT verification_codes_pkey PRIMARY KEY (id);


--
-- Name: video_process_events video_process_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_process_events
    ADD CONSTRAINT video_process_events_pkey PRIMARY KEY (id);


--
-- Name: video_tags video_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_tags
    ADD CONSTRAINT video_tags_pkey PRIMARY KEY (id);


--
-- Name: video_tags video_tags_uk_video_tag; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_tags
    ADD CONSTRAINT video_tags_uk_video_tag UNIQUE (video_id, tag_id);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- Name: watch_history watch_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch_history
    ADD CONSTRAINT watch_history_pkey PRIMARY KEY (id);


--
-- Name: watch_history watch_history_user_id_manuscript_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch_history
    ADD CONSTRAINT watch_history_user_id_manuscript_id_key UNIQUE (user_id, manuscript_id);


--
-- Name: admin_user_roles_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX admin_user_roles_role_id ON public.admin_user_roles USING btree (role_id);


--
-- Name: ai_chat_messages_idx_conversation_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ai_chat_messages_idx_conversation_id ON public.ai_chat_messages USING btree (conversation_id);


--
-- Name: ai_conversations_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ai_conversations_idx_user_id ON public.ai_conversations USING btree (user_id);


--
-- Name: audit_logs_idx_audit_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_idx_audit_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_idx_audit_module_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_idx_audit_module_action ON public.audit_logs USING btree (module, action);


--
-- Name: audit_logs_idx_audit_operator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_idx_audit_operator ON public.audit_logs USING btree (operator_id);


--
-- Name: audit_logs_idx_audit_result; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_idx_audit_result ON public.audit_logs USING btree (result);


--
-- Name: audit_logs_idx_audit_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_logs_idx_audit_target ON public.audit_logs USING btree (target_type, target_id);


--
-- Name: banner_images_idx_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banner_images_idx_category_id ON public.banner_images USING btree (category_id);


--
-- Name: banner_images_idx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banner_images_idx_status ON public.banner_images USING btree (status);


--
-- Name: banner_images_idx_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX banner_images_idx_type ON public.banner_images USING btree (type);


--
-- Name: comments_idx_comments_video_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comments_idx_comments_video_id ON public.comments USING btree (manuscript_id);


--
-- Name: comments_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comments_user_id ON public.comments USING btree (user_id);


--
-- Name: conversations_idx_last_message_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX conversations_idx_last_message_time ON public.conversations USING btree (last_message_time);


--
-- Name: conversations_idx_target_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX conversations_idx_target_user_id ON public.conversations USING btree (target_user_id);


--
-- Name: conversations_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX conversations_idx_user_id ON public.conversations USING btree (user_id);


--
-- Name: creator_settings_idx_default_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX creator_settings_idx_default_category_id ON public.creator_settings USING btree (default_category_id);


--
-- Name: creator_settings_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX creator_settings_idx_user_id ON public.creator_settings USING btree (user_id);


--
-- Name: dynamic_comments_idx_dynamic_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dynamic_comments_idx_dynamic_id ON public.dynamic_comments USING btree (dynamic_id);


--
-- Name: dynamic_comments_idx_parent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dynamic_comments_idx_parent_id ON public.dynamic_comments USING btree (parent_id);


--
-- Name: dynamic_comments_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dynamic_comments_idx_user_id ON public.dynamic_comments USING btree (user_id);


--
-- Name: favorite_manuscripts_fk_favorite_manuscripts_manuscript; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX favorite_manuscripts_fk_favorite_manuscripts_manuscript ON public.favorite_manuscripts USING btree (manuscript_id);


--
-- Name: idx_ai_sessions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ai_sessions_user ON public.ai_sessions USING btree (user_id, type);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_module; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_module ON public.audit_logs USING btree (module, action);


--
-- Name: idx_audit_logs_operator; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_logs_operator ON public.audit_logs USING btree (operator_id);


--
-- Name: idx_banners_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_banners_status ON public.banner_images USING btree (status);


--
-- Name: idx_banners_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_banners_type ON public.banner_images USING btree (type);


--
-- Name: idx_collection_relations_coll; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_collection_relations_coll ON public.manuscript_collection_relations USING btree (collection_id, collection_order);


--
-- Name: idx_collections_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_collections_status ON public.manuscript_collections USING btree (status);


--
-- Name: idx_collections_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_collections_user ON public.manuscript_collections USING btree (user_id);


--
-- Name: idx_comments_manuscript_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_comments_manuscript_id ON public.comments USING btree (manuscript_id);


--
-- Name: idx_comments_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_comments_user_id ON public.comments USING btree (user_id);


--
-- Name: idx_content_reviews_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_content_reviews_type ON public.content_reviews USING btree (type);


--
-- Name: idx_daily_metrics_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_daily_metrics_user ON public.manuscript_daily_metrics USING btree (user_id, metric_date);


--
-- Name: idx_danmaku_video; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_danmaku_video ON public.danmaku USING btree (video_id, "time");


--
-- Name: idx_dynamic_comments_dyn; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_comments_dyn ON public.dynamic_comments USING btree (dynamic_id);


--
-- Name: idx_dynamic_comments_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_comments_parent ON public.dynamic_comments USING btree (parent_id);


--
-- Name: idx_dynamic_likes_dynamic; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamic_likes_dynamic ON public.dynamic_likes USING btree (dynamic_id);


--
-- Name: idx_dynamics_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dynamics_user ON public.user_dynamics USING btree (user_id, created_at DESC);


--
-- Name: idx_edit_versions_ms; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_edit_versions_ms ON public.manuscript_edit_versions USING btree (manuscript_id);


--
-- Name: idx_edit_versions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_edit_versions_status ON public.manuscript_edit_versions USING btree (status);


--
-- Name: idx_fav_folder_videos_folder; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fav_folder_videos_folder ON public.favorite_folder_videos USING btree (folder_id);


--
-- Name: idx_fav_folder_videos_manuscript; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fav_folder_videos_manuscript ON public.favorite_folder_videos USING btree (manuscript_id);


--
-- Name: idx_favorite_folders_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorite_folders_user ON public.favorite_folders USING btree (user_id);


--
-- Name: idx_follows_follower; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_follows_follower ON public.follows USING btree (follower_id);


--
-- Name: idx_follows_following; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_follows_following ON public.follows USING btree (following_id);


--
-- Name: idx_jsonb_documents_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jsonb_documents_gin ON public.jsonb_documents USING gin (doc_json);


--
-- Name: idx_live_linkmic_room; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_live_linkmic_room ON public.live_linkmic USING btree (room_id, status);


--
-- Name: idx_live_linkmic_viewer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_live_linkmic_viewer ON public.live_linkmic USING btree (viewer_id);


--
-- Name: idx_live_rooms_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_live_rooms_status ON public.live_rooms USING btree (status, viewer_count DESC);


--
-- Name: idx_live_rooms_stream_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_live_rooms_stream_key ON public.live_rooms USING btree (stream_key);


--
-- Name: idx_live_seats_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_live_seats_user ON public.live_seats USING btree (user_id);


--
-- Name: idx_login_logs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_login_logs_user ON public.login_logs USING btree (user_id, login_time DESC);


--
-- Name: idx_manuscripts_bvid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_manuscripts_bvid ON public.manuscripts USING btree (bvid) WHERE ((bvid)::text <> ''::text);


--
-- Name: idx_manuscripts_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manuscripts_category_id ON public.manuscripts USING btree (category_id);


--
-- Name: idx_manuscripts_search; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manuscripts_search ON public.manuscripts USING gin (search_vector);


--
-- Name: idx_manuscripts_source_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manuscripts_source_type ON public.manuscripts USING btree (source_type);


--
-- Name: idx_manuscripts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manuscripts_status ON public.manuscripts USING btree (status);


--
-- Name: idx_manuscripts_upload_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manuscripts_upload_time ON public.manuscripts USING btree (upload_time DESC);


--
-- Name: idx_manuscripts_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_manuscripts_user_id ON public.manuscripts USING btree (user_id);


--
-- Name: idx_messages_conversation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_conversation ON public.messages USING btree (conversation_id, created_at);


--
-- Name: idx_messages_receiver; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_receiver ON public.messages USING btree (receiver_id);


--
-- Name: idx_messages_sender; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_messages_sender ON public.messages USING btree (sender_id);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_op_tasks_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_op_tasks_status ON public.operation_tasks USING btree (status);


--
-- Name: idx_op_tasks_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_op_tasks_type ON public.operation_tasks USING btree (task_type);


--
-- Name: idx_process_events_video; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_process_events_video ON public.video_process_events USING btree (video_id, created_at);


--
-- Name: idx_prohibited_words_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prohibited_words_category ON public.prohibited_words USING btree (category);


--
-- Name: idx_prohibited_words_word; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_prohibited_words_word ON public.prohibited_words USING btree (word);


--
-- Name: idx_replies_comment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_replies_comment_id ON public.replies USING btree (comment_id);


--
-- Name: idx_replies_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_replies_user_id ON public.replies USING btree (user_id);


--
-- Name: idx_reports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_status ON public.reports USING btree (status);


--
-- Name: idx_reports_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reports_target ON public.reports USING btree (target_type, target_id);


--
-- Name: idx_scheduled_tasks_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scheduled_tasks_enabled ON public.scheduled_tasks USING btree (enabled);


--
-- Name: idx_shares_manuscript; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_shares_manuscript ON public.shares USING btree (manuscript_id);


--
-- Name: idx_status_events_ms; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_status_events_ms ON public.manuscript_status_events USING btree (manuscript_id, created_at);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_tickets_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tickets_user ON public.support_tickets USING btree (user_id);


--
-- Name: idx_usage_logs_feature; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usage_logs_feature ON public.ai_usage_logs USING btree (feature, created_at);


--
-- Name: idx_user_interactions_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_interactions_target ON public.user_interactions USING btree (target_type, target_id, interaction_type);


--
-- Name: idx_user_interactions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_interactions_user ON public.user_interactions USING btree (user_id, interaction_type, created_at);


--
-- Name: idx_user_tags_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_tags_user ON public.user_tags USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_nickname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_nickname ON public.users USING btree (nickname) WHERE ((nickname)::text <> ''::text);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_verification_codes_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_verification_codes_lookup ON public.verification_codes USING btree (identifier, code_type, expires_at DESC);


--
-- Name: idx_videos_manuscript_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_videos_manuscript_id ON public.videos USING btree (manuscript_id);


--
-- Name: idx_videos_upload_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_videos_upload_time ON public.videos USING btree (upload_time DESC);


--
-- Name: idx_watch_history_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_watch_history_user ON public.watch_history USING btree (user_id, watched_at DESC);


--
-- Name: live_linkmic_idx_room_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX live_linkmic_idx_room_id ON public.live_linkmic USING btree (room_id);


--
-- Name: live_linkmic_idx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX live_linkmic_idx_status ON public.live_linkmic USING btree (status);


--
-- Name: live_linkmic_idx_viewer_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX live_linkmic_idx_viewer_id ON public.live_linkmic USING btree (viewer_id);


--
-- Name: live_rooms_idx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX live_rooms_idx_status ON public.live_rooms USING btree (status);


--
-- Name: live_rooms_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX live_rooms_idx_user_id ON public.live_rooms USING btree (user_id);


--
-- Name: manuscript_collection_relations_idx_collection_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_collection_relations_idx_collection_id ON public.manuscript_collection_relations USING btree (collection_id);


--
-- Name: manuscript_collection_relations_idx_collection_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_collection_relations_idx_collection_order ON public.manuscript_collection_relations USING btree (collection_id, collection_order);


--
-- Name: manuscript_collections_idx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_collections_idx_status ON public.manuscript_collections USING btree (status);


--
-- Name: manuscript_collections_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscript_collections_idx_user_id ON public.manuscript_collections USING btree (user_id);


--
-- Name: manuscripts_idx_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscripts_idx_category_id ON public.manuscripts USING btree (category_id);


--
-- Name: manuscripts_idx_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscripts_idx_status ON public.manuscripts USING btree (status);


--
-- Name: manuscripts_idx_upload_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscripts_idx_upload_time ON public.manuscripts USING btree (upload_time);


--
-- Name: manuscripts_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX manuscripts_idx_user_id ON public.manuscripts USING btree (user_id);


--
-- Name: meeting_participant_idx_room_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX meeting_participant_idx_room_id ON public.meeting_participant USING btree (room_id);


--
-- Name: meeting_participant_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX meeting_participant_idx_user_id ON public.meeting_participant USING btree (user_id);


--
-- Name: meeting_room_idx_creator_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX meeting_room_idx_creator_id ON public.meeting_room USING btree (creator_id);


--
-- Name: meeting_room_idx_room_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX meeting_room_idx_room_code ON public.meeting_room USING btree (room_code);


--
-- Name: message_settings_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX message_settings_idx_user_id ON public.message_settings USING btree (user_id);


--
-- Name: messages_receiver_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_receiver_id ON public.messages USING btree (receiver_id);


--
-- Name: messages_sender_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_sender_id ON public.messages USING btree (sender_id);


--
-- Name: operation_tasks_idx_operation_task_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX operation_tasks_idx_operation_task_created_at ON public.operation_tasks USING btree (created_at);


--
-- Name: operation_tasks_idx_operation_task_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX operation_tasks_idx_operation_task_status ON public.operation_tasks USING btree (status);


--
-- Name: operation_tasks_idx_operation_task_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX operation_tasks_idx_operation_task_target ON public.operation_tasks USING btree (target_type, target_id);


--
-- Name: operation_tasks_idx_operation_task_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX operation_tasks_idx_operation_task_type ON public.operation_tasks USING btree (task_type);


--
-- Name: permissions_parent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX permissions_parent_id ON public.permissions USING btree (parent_id);


--
-- Name: prohibited_words_idx_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX prohibited_words_idx_category ON public.prohibited_words USING btree (category);


--
-- Name: prohibited_words_idx_is_enabled; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX prohibited_words_idx_is_enabled ON public.prohibited_words USING btree (is_enabled);


--
-- Name: prohibited_words_idx_word; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX prohibited_words_idx_word ON public.prohibited_words USING btree (word);


--
-- Name: replies_idx_replies_comment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX replies_idx_replies_comment_id ON public.replies USING btree (comment_id);


--
-- Name: replies_reply_to_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX replies_reply_to_user_id ON public.replies USING btree (reply_to_user_id);


--
-- Name: replies_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX replies_user_id ON public.replies USING btree (user_id);


--
-- Name: role_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX role_permissions_permission_id ON public.role_permissions USING btree (permission_id);


--
-- Name: shares_idx_manuscript_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shares_idx_manuscript_id ON public.shares USING btree (manuscript_id);


--
-- Name: user_dynamics_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_dynamics_user_id ON public.user_dynamics USING btree (user_id);


--
-- Name: user_interactions_idx_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_interactions_idx_target ON public.user_interactions USING btree (target_type, target_id, interaction_type);


--
-- Name: user_interactions_idx_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_interactions_idx_user ON public.user_interactions USING btree (user_id, interaction_type, created_at);


--
-- Name: user_interactions_idx_user_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_interactions_idx_user_target ON public.user_interactions USING btree (user_id, target_type, target_id);


--
-- Name: user_tags_idx_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_tags_idx_user_id ON public.user_tags USING btree (user_id);


--
-- Name: users_idx_users_pinned_video_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_idx_users_pinned_video_id ON public.users USING btree (pinned_video_id);


--
-- Name: video_tags_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX video_tags_tag_id ON public.video_tags USING btree (tag_id);


--
-- Name: videos_idx_manuscript_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX videos_idx_manuscript_id ON public.videos USING btree (manuscript_id);


--
-- Name: videos_idx_videos_upload_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX videos_idx_videos_upload_time ON public.videos USING btree (upload_time);


--
-- Name: manuscripts trg_manuscript_search_vector; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_manuscript_search_vector BEFORE INSERT OR UPDATE OF title, description ON public.manuscripts FOR EACH ROW EXECUTE FUNCTION public.update_manuscript_search_vector();


--
-- Name: admin_user_roles admin_user_roles_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_user_roles
    ADD CONSTRAINT admin_user_roles_ibfk_1 FOREIGN KEY (admin_user_id) REFERENCES public.admin_users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: admin_user_roles admin_user_roles_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_user_roles
    ADD CONSTRAINT admin_user_roles_ibfk_2 FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ai_bindings ai_bindings_api_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_bindings
    ADD CONSTRAINT ai_bindings_api_config_id_fkey FOREIGN KEY (api_config_id) REFERENCES public.ai_api_configs(id) ON DELETE CASCADE;


--
-- Name: comments comments_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_ibfk_2 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: conversations conversations_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: conversations conversations_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_ibfk_2 FOREIGN KEY (target_user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: creator_settings creator_settings_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creator_settings
    ADD CONSTRAINT creator_settings_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: creator_settings creator_settings_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.creator_settings
    ADD CONSTRAINT creator_settings_ibfk_2 FOREIGN KEY (default_category_id) REFERENCES public.categories(id) ON UPDATE RESTRICT ON DELETE SET NULL;


--
-- Name: danmaku danmaku_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.danmaku
    ADD CONSTRAINT danmaku_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dynamic_likes dynamic_likes_dynamic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_likes
    ADD CONSTRAINT dynamic_likes_dynamic_id_fkey FOREIGN KEY (dynamic_id) REFERENCES public.user_dynamics(id) ON DELETE CASCADE;


--
-- Name: dynamic_likes dynamic_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_likes
    ADD CONSTRAINT dynamic_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorite_folder_videos favorite_folder_videos_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folder_videos
    ADD CONSTRAINT favorite_folder_videos_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.favorite_folders(id) ON DELETE CASCADE;


--
-- Name: favorite_folder_videos favorite_folder_videos_manuscript_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folder_videos
    ADD CONSTRAINT favorite_folder_videos_manuscript_id_fkey FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON DELETE CASCADE;


--
-- Name: favorite_folders favorite_folders_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_folders
    ADD CONSTRAINT favorite_folders_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: ai_chat_messages fk_ai_msg_conversation; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT fk_ai_msg_conversation FOREIGN KEY (conversation_id) REFERENCES public.ai_conversations(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: comments fk_comments_manuscript; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT fk_comments_manuscript FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: favorite_manuscripts fk_favorite_manuscripts_folder; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_manuscripts
    ADD CONSTRAINT fk_favorite_manuscripts_folder FOREIGN KEY (folder_id) REFERENCES public.favorite_folders(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: favorite_manuscripts fk_favorite_manuscripts_manuscript; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.favorite_manuscripts
    ADD CONSTRAINT fk_favorite_manuscripts_manuscript FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: manuscripts fk_manuscripts_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscripts
    ADD CONSTRAINT fk_manuscripts_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: videos fk_videos_manuscript; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT fk_videos_manuscript FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: follows follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: follows follows_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: live_seats live_seats_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_seats
    ADD CONSTRAINT live_seats_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.live_rooms(id) ON DELETE CASCADE;


--
-- Name: live_seats live_seats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_seats
    ADD CONSTRAINT live_seats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: manuscript_collection_relations manuscript_collection_relations_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_collection_relations
    ADD CONSTRAINT manuscript_collection_relations_ibfk_1 FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: manuscript_collection_relations manuscript_collection_relations_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_collection_relations
    ADD CONSTRAINT manuscript_collection_relations_ibfk_2 FOREIGN KEY (collection_id) REFERENCES public.manuscript_collections(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: manuscript_collections manuscript_collections_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_collections
    ADD CONSTRAINT manuscript_collections_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: manuscript_daily_metrics manuscript_daily_metrics_manuscript_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_daily_metrics
    ADD CONSTRAINT manuscript_daily_metrics_manuscript_id_fkey FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON DELETE CASCADE;


--
-- Name: manuscript_edit_versions manuscript_edit_versions_manuscript_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_edit_versions
    ADD CONSTRAINT manuscript_edit_versions_manuscript_id_fkey FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON DELETE CASCADE;


--
-- Name: manuscript_edit_versions manuscript_edit_versions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_edit_versions
    ADD CONSTRAINT manuscript_edit_versions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: manuscript_status_events manuscript_status_events_manuscript_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manuscript_status_events
    ADD CONSTRAINT manuscript_status_events_manuscript_id_fkey FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON DELETE CASCADE;


--
-- Name: message_settings message_settings_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_settings
    ADD CONSTRAINT message_settings_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: messages messages_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_ibfk_1 FOREIGN KEY (sender_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: messages messages_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_ibfk_2 FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: permissions permissions_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_ibfk_1 FOREIGN KEY (parent_id) REFERENCES public.permissions(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: replies replies_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_ibfk_1 FOREIGN KEY (comment_id) REFERENCES public.comments(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: replies replies_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_ibfk_2 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: replies replies_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_ibfk_3 FOREIGN KEY (reply_to_user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: role_permissions role_permissions_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_ibfk_1 FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: role_permissions role_permissions_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_ibfk_2 FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: user_dynamics user_dynamics_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dynamics
    ADD CONSTRAINT user_dynamics_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: video_process_events video_process_events_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_process_events
    ADD CONSTRAINT video_process_events_video_id_fkey FOREIGN KEY (video_id) REFERENCES public.videos(id) ON DELETE CASCADE;


--
-- Name: video_tags video_tags_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_tags
    ADD CONSTRAINT video_tags_ibfk_1 FOREIGN KEY (video_id) REFERENCES public.videos(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: video_tags video_tags_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.video_tags
    ADD CONSTRAINT video_tags_ibfk_2 FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- Name: watch_history watch_history_manuscript_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch_history
    ADD CONSTRAINT watch_history_manuscript_id_fkey FOREIGN KEY (manuscript_id) REFERENCES public.manuscripts(id) ON DELETE CASCADE;


--
-- Name: watch_history watch_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watch_history
    ADD CONSTRAINT watch_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict bEtX5NbUpRpszTBtGS4CCG9rY9ylYXd8U5hDu2ocpuTqfCOQl8bJB0q8G9gsD1w

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict aXsv9i8D4g0skpwqRZReAkiDR8OUH4pCrW0FPljx50quTMJF98hmUhYPAoc3Tq1

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict aXsv9i8D4g0skpwqRZReAkiDR8OUH4pCrW0FPljx50quTMJF98hmUhYPAoc3Tq1

--
-- PostgreSQL database cluster dump complete
--

